<?php
/**
 * Admin bootstrap — registers the top-level menu, sub-menus, and admin assets.
 *
 * @package WP_Career_Board
 * @since   1.0.0
 */

declare( strict_types=1 );

namespace WCB\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Boots the admin interface: menus, settings, and asset enqueuing.
 *
 * @since 1.0.0
 */
class Admin {


	/**
	 * Boot the admin module.
	 *
	 * @since  1.0.0
	 * @return void
	 */
	public function boot(): void {
		add_action( 'admin_menu', array( $this, 'register_menus' ) );
		add_action( 'admin_menu', array( $this, 'register_settings_submenu' ), 25 );
		add_action( 'admin_menu', array( $this, 'register_emails_submenu' ), 20 );
		add_filter( 'parent_file', array( $this, 'highlight_parent_for_taxonomies' ) );
		add_filter( 'submenu_file', array( $this, 'highlight_submenu_for_taxonomies' ), 10, 2 );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		// WooCommerce locks down /wp-admin/ for any user that lacks edit_posts,
		// manage_woocommerce, or view_admin_dashboard. Board Moderators carry
		// none of those, so on stores running WC they get bounced to
		// /my-account/ before ever reaching the Jobs queue. Let them through
		// when they hold the moderation cap.
		add_filter( 'woocommerce_prevent_admin_access', array( $this, 'allow_moderator_admin_access' ) );
		// Send Job Moderators to the Jobs queue on admin_init (before any output)
		// so the redirect is silent — the old in-render redirect fired after
		// output had begun and threw "headers already sent".
		add_action( 'admin_init', array( $this, 'redirect_moderator_to_queue' ) );
		( new EmailSettings() )->boot();

		// Boot settings so its admin_init hook fires.
		( new AdminSettings() )->boot();

		// Boot meta boxes for the wcb_job CPT.
		( new AdminMetaBoxes() )->boot();

		// Replace the default WP editor on the wcb_job edit screen with our
		// Editor.js surface — matches the simplified admin pattern from Learnomy.
		( new AdminJobEditor() )->boot();
	}

	/**
	 * Register the top-level Career Board menu and its sub-menus.
	 *
	 * @since  1.0.0
	 * @return void
	 */
	public function register_menus(): void {
		add_menu_page(
			__( 'WP Career Board', 'wp-career-board' ),
			__( 'Career Board', 'wp-career-board' ),
			'wcb_access_admin_jobs',
			'wp-career-board',
			array( $this, 'render_dashboard' ),
			'dashicons-portfolio',
			25
		);

		$admin_jobs = new AdminJobs();
		$jobs_hook  = add_submenu_page(
			'wp-career-board',
			__( 'Jobs', 'wp-career-board' ),
			__( 'Jobs', 'wp-career-board' ),
			'wcb_access_admin_jobs',
			'wcb-jobs',
			array( $admin_jobs, 'render' )
		);
		add_action( 'load-' . $jobs_hook, array( $admin_jobs, 'process_bulk_action' ) );

		$admin_apps = new AdminApplications();
		$apps_hook  = add_submenu_page(
			'wp-career-board',
			__( 'Applications', 'wp-career-board' ),
			__( 'Applications', 'wp-career-board' ),
			'wcb_manage_settings',
			'wcb-applications',
			array( $admin_apps, 'render' )
		);
		add_action( 'load-' . $apps_hook, array( $admin_apps, 'process_bulk_action' ) );

		add_submenu_page(
			'wp-career-board',
			__( 'Candidates', 'wp-career-board' ),
			__( 'Candidates', 'wp-career-board' ),
			'wcb_manage_settings',
			'wcb-candidates',
			array( new AdminCandidates(), 'render' )
		);

		add_submenu_page(
			'wp-career-board',
			__( 'Companies', 'wp-career-board' ),
			__( 'Companies', 'wp-career-board' ),
			'wcb_manage_settings',
			'wcb-companies',
			array( new AdminCompanies(), 'render' )
		);

		$admin_employers = new AdminEmployers();
		$employers_hook  = add_submenu_page(
			'wp-career-board',
			__( 'Employers', 'wp-career-board' ),
			__( 'Employers', 'wp-career-board' ),
			'wcb_manage_settings',
			'wcb-employers',
			array( $admin_employers, 'render' )
		);
		add_action( 'load-' . $employers_hook, array( $admin_employers, 'process_bulk_action' ) );

		// Taxonomy submenu items — point at the stock WP edit-tags screens so
		// admins can create/edit job categories, types, locations, etc. without
		// having to know the post-type-aware URL by hand. Filled into the
		// $submenu global directly because add_submenu_page() rewrites slugs
		// into admin.php?page=…, which doesn't apply here.
		global $submenu;
		$wcb_tax_links = array(
			'wcb_category'   => __( 'Job Categories', 'wp-career-board' ),
			'wcb_job_type'   => __( 'Job Types', 'wp-career-board' ),
			'wcb_location'   => __( 'Job Locations', 'wp-career-board' ),
			'wcb_experience' => __( 'Experience Levels', 'wp-career-board' ),
			'wcb_tag'        => __( 'Job Tags', 'wp-career-board' ),
		);
		foreach ( $wcb_tax_links as $wcb_tax => $wcb_label ) {
			// phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- documented WP idiom for appending taxonomy edit links to a custom top-level menu.
			$submenu['wp-career-board'][] = array(
				$wcb_label,
				'wcb_manage_settings',
				'edit-tags.php?taxonomy=' . $wcb_tax . '&post_type=wcb_job',
			);
		}
	}

	/**
	 * Keep the Career Board top-level menu highlighted while admins are on the
	 * taxonomy admin pages registered as cross-links above. Without this filter
	 * WP can't tell the edit-tags.php?taxonomy=wcb_… screens belong to our menu
	 * and falls back to highlighting "Posts" or nothing.
	 *
	 * @since 1.1.1
	 *
	 * @param  string $parent_file The parent menu file currently set.
	 * @return string
	 */
	public function highlight_parent_for_taxonomies( string $parent_file ): string {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- read-only screen routing.
		if ( isset( $_GET['post_type'] ) && 'wcb_job' === sanitize_key( (string) $_GET['post_type'] )
			&& isset( $_GET['taxonomy'] )
			&& in_array(
				sanitize_key( (string) $_GET['taxonomy'] ),
				array( 'wcb_category', 'wcb_job_type', 'wcb_location', 'wcb_experience', 'wcb_tag' ),
				true
			)
		) {
			return 'wp-career-board';
		}
		// phpcs:enable WordPress.Security.NonceVerification.Recommended
		return $parent_file;
	}

	/**
	 * Highlight the matching submenu item (Job Categories / Job Types / etc.)
	 * while on its corresponding edit-tags.php screen.
	 *
	 * @since 1.1.1
	 *
	 * @param  string|null $submenu_file Currently highlighted submenu file.
	 * @param  string      $parent_file  Currently highlighted parent file.
	 * @return string|null
	 */
	public function highlight_submenu_for_taxonomies( $submenu_file, $parent_file ) {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- read-only screen routing.
		if ( 'wp-career-board' !== $parent_file ) {
			return $submenu_file;
		}
		if ( ! isset( $_GET['taxonomy'] ) ) {
			return $submenu_file;
		}
		$wcb_tax = sanitize_key( (string) $_GET['taxonomy'] );
		if ( ! in_array( $wcb_tax, array( 'wcb_category', 'wcb_job_type', 'wcb_location', 'wcb_experience', 'wcb_tag' ), true ) ) {
			return $submenu_file;
		}
		// phpcs:enable WordPress.Security.NonceVerification.Recommended
		return 'edit-tags.php?taxonomy=' . $wcb_tax . '&post_type=wcb_job';
	}

	/**
	 * Register the Settings submenu at priority 25 so it appears after all Pro items.
	 *
	 * @since  1.0.0
	 * @return void
	 */
	public function register_settings_submenu(): void {
		add_submenu_page(
			'wp-career-board',
			__( 'Settings', 'wp-career-board' ),
			__( 'Settings', 'wp-career-board' ),
			'wcb_manage_settings',
			'wcb-settings',
			array( new AdminSettings(), 'render' )
		);
	}

	/**
	 * Filter callback: let Board Moderators through WooCommerce's
	 * "lock down admin" redirect so they can reach the Jobs queue. Returns
	 * the upstream value unchanged for everyone else.
	 *
	 * @since 1.2.1
	 *
	 * @param bool $prevent Whether WooCommerce wants to redirect the user.
	 * @return bool
	 */
	public function allow_moderator_admin_access( bool $prevent ): bool {
		if ( ! $prevent ) {
			return $prevent;
		}
		return wp_is_ability_granted( 'wcb/moderate-jobs' ) ? false : $prevent; // phpcs:ignore -- ability polyfill, see core/abilities-api-polyfill.php
	}


	/**
	 * Send Job Moderators straight to the Jobs queue.
	 *
	 * Moderators (wcb/moderate-jobs, not wcb/manage-settings) have no use for
	 * the WP Dashboard or the Career Board dashboard — its stats and the Pro
	 * license/credit nudges aren't theirs to act on. Runs on admin_init, BEFORE
	 * any output, so the redirect is silent. Covers both /wp-admin/
	 * (pagenow=index.php) and the Career Board dashboard (page=wp-career-board).
	 * Admins are never redirected.
	 *
	 * @since  1.2.0
	 * @return void
	 */
	public function redirect_moderator_to_queue(): void {
		if ( wp_doing_ajax() || wp_doing_cron() ) {
			return;
		}
		// Only Job Moderators (moderate-jobs without manage-settings) are bounced.
		if ( wp_is_ability_granted( 'wcb/manage-settings' ) || ! wp_is_ability_granted( 'wcb/moderate-jobs' ) ) { // phpcs:ignore -- ability polyfill, see core/abilities-api-polyfill.php
			return;
		}
		$pagenow = isset( $GLOBALS['pagenow'] ) ? (string) $GLOBALS['pagenow'] : '';
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';

		$on_wp_dashboard  = ( 'index.php' === $pagenow && '' === $page );
		$on_wcb_dashboard = ( 'admin.php' === $pagenow && 'wp-career-board' === $page );

		if ( $on_wp_dashboard || $on_wcb_dashboard ) {
			wp_safe_redirect( admin_url( 'admin.php?page=wcb-jobs' ) );
			exit;
		}
	}

	/**
	 * Render the admin dashboard — stats, pending queue, recent applications.
	 *
	 * @since  1.0.0
	 * @return void
	 */
	public function render_dashboard(): void {
		// Moderators never reach here — redirect_moderator_to_queue() bounces
		// them to the Jobs queue on admin_init (before this render callback).
		$jobs_count   = wp_count_posts( 'wcb_job' );
		$apps_count   = wp_count_posts( 'wcb_application' );
		$total_jobs   = isset( $jobs_count->publish ) ? (int) $jobs_count->publish : 0;
		$total_apps   = isset( $apps_count->publish ) ? (int) $apps_count->publish : 0;
		$pending_jobs = isset( $jobs_count->pending ) ? (int) $jobs_count->pending : 0;

		// Getting Started card: hide once setup complete AND at least one job is published.
		$wcb_setup_done = SetupWizard::is_setup_complete();
		$wcb_show_gs    = ! ( $wcb_setup_done && $total_jobs > 0 );

		if ( $wcb_show_gs ) {
			$wcb_page_keys     = array(
				'employer_registration_page',
				'employer_dashboard_page',
				'candidate_dashboard_page',
				'jobs_archive_page',
				'company_archive_page',
				'post_job_page',
			);
			$wcb_pages_created = count( array_filter( array_map( static fn( string $k ): int => \WCB\Admin\Settings::int( $k, 0 ), $wcb_page_keys ) ) );
			$wcb_total_pages   = count( $wcb_page_keys );
		}
		$total_emp  = count(
			get_users(
				array(
					'role'   => 'wcb_employer',
					'fields' => 'ID',
					'number' => 9999,
				)
			)
		); // phpcs:ignore WordPress.WP.PostsPerPage.posts_per_page_number
		$total_cand = count(
			get_users(
				array(
					'role'   => 'wcb_candidate',
					'fields' => 'ID',
					'number' => 9999,
				)
			)
		); // phpcs:ignore WordPress.WP.PostsPerPage.posts_per_page_number

		// Pending jobs for inline moderation queue.
		$pending_posts = get_posts(
			array(
				'post_type'      => 'wcb_job',
				'post_status'    => 'pending',
				'posts_per_page' => 10,
				'orderby'        => 'date',
				'order'          => 'DESC',
			)
		);

		// Five most recent applications.
		$recent_apps = get_posts(
			array(
				'post_type'      => 'wcb_application',
				'post_status'    => 'any',
				'posts_per_page' => 5,
				'orderby'        => 'date',
				'order'          => 'DESC',
			)
		);
		?>
		<div class="wrap wcb-admin wcb-admin-dashboard">
			<h1 class="screen-reader-text"><?php esc_html_e( 'WP Career Board', 'wp-career-board' ); ?></h1>

			<div class="wcb-page-header">
				<div class="wcb-page-header__left">
					<h2 class="wcb-page-header__title">
						<i data-lucide="briefcase" class="wcb-icon--lg"></i>
		<?php esc_html_e( 'WP Career Board', 'wp-career-board' ); ?>
						<span class="wcb-version-badge">v<?php echo esc_html( WCB_VERSION ); ?></span>
		<?php if ( apply_filters( 'wcb_pro_active', false ) ) : ?>
							<span class="wcb-pro-badge"><?php esc_html_e( 'Pro', 'wp-career-board' ); ?></span>
		<?php endif; ?>
					</h2>
					<p class="wcb-page-header__desc"><?php esc_html_e( 'Manage your job board, applications, and hiring pipeline.', 'wp-career-board' ); ?></p>
				</div>
				<div class="wcb-page-header__actions">
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>" target="_blank" rel="noopener noreferrer" class="wcb-btn">
		<?php esc_html_e( 'Visit Site', 'wp-career-board' ); ?>
						<i data-lucide="external-link" class="wcb-icon--sm"></i>
					</a>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=wcb-settings' ) ); ?>" class="wcb-btn">
						<i data-lucide="settings" class="wcb-icon--sm"></i>
		<?php esc_html_e( 'Settings', 'wp-career-board' ); ?>
					</a>
				</div>
			</div>

		<?php /* ── Getting Started checklist — hidden once setup complete + 1+ job published ── */ ?>
		<?php if ( $wcb_show_gs ) : ?>
			<div class="wcb-settings-card wcb-getting-started-card">
				<div class="wcb-settings-card-header">
					<h2 class="wcb-settings-card-title"><?php esc_html_e( 'Getting Started', 'wp-career-board' ); ?></h2>
				</div>
				<ul class="wcb-getting-started-list">
					<li class="wcb-gs-item wcb-gs-done">
						<i data-lucide="circle-check" class="wcb-gs-icon"></i>
						<span class="wcb-gs-label"><?php esc_html_e( 'Plugin activated', 'wp-career-board' ); ?></span>
					</li>
					<li class="wcb-gs-item <?php echo $wcb_pages_created >= $wcb_total_pages ? 'wcb-gs-done' : ''; ?>">
						<i data-lucide="<?php echo $wcb_pages_created >= $wcb_total_pages ? 'circle-check' : 'circle'; ?>" class="wcb-gs-icon"></i>
						<span class="wcb-gs-label">
			<?php
			echo esc_html(
				sprintf(
				/* translators: 1: pages created count, 2: total pages count */
					__( 'Pages created (%1$d/%2$d)', 'wp-career-board' ),
					$wcb_pages_created,
					$wcb_total_pages
				)
			);
			?>
			<?php if ( $wcb_pages_created < $wcb_total_pages ) : ?>
								&mdash; <a href="<?php echo esc_url( admin_url( 'admin.php?page=wcb-setup' ) ); ?>"><?php esc_html_e( 'Run Wizard', 'wp-career-board' ); ?></a>
			<?php endif; ?>
						</span>
					</li>
					<li class="wcb-gs-item <?php echo $total_jobs > 0 ? 'wcb-gs-done' : ''; ?>">
						<i data-lucide="<?php echo $total_jobs > 0 ? 'circle-check' : 'circle'; ?>" class="wcb-gs-icon"></i>
						<span class="wcb-gs-label">
			<?php esc_html_e( 'Add your first job', 'wp-career-board' ); ?>
			<?php if ( 0 === $total_jobs ) : ?>
								&mdash; <a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=wcb_job' ) ); ?>"><?php esc_html_e( '+ Add Job', 'wp-career-board' ); ?></a>
			<?php endif; ?>
						</span>
					</li>
					<li class="wcb-gs-item">
						<i data-lucide="circle" class="wcb-gs-icon"></i>
						<span class="wcb-gs-label">
			<?php esc_html_e( 'Invite an employer', 'wp-career-board' ); ?>
							&mdash; <a href="<?php echo esc_url( admin_url( 'user-new.php' ) ); ?>"><?php esc_html_e( '+ Add User', 'wp-career-board' ); ?></a>
						</span>
					</li>
				</ul>
			</div>
		<?php endif; ?>

		<?php /* ── Stats row ── */ ?>
			<div class="wcb-stats-grid">
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=wcb-jobs' ) ); ?>" class="wcb-stat-box">
					<span class="wcb-stat-icon"><i data-lucide="briefcase"></i></span>
					<span class="wcb-stat-number"><?php echo (int) $total_jobs; ?></span>
					<span class="wcb-stat-label"><?php esc_html_e( 'Active Jobs', 'wp-career-board' ); ?></span>
				</a>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=wcb-applications' ) ); ?>" class="wcb-stat-box">
					<span class="wcb-stat-icon"><i data-lucide="clipboard-list"></i></span>
					<span class="wcb-stat-number"><?php echo (int) $total_apps; ?></span>
					<span class="wcb-stat-label"><?php esc_html_e( 'Applications', 'wp-career-board' ); ?></span>
				</a>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=wcb-employers' ) ); ?>" class="wcb-stat-box">
					<span class="wcb-stat-icon"><i data-lucide="building-2"></i></span>
					<span class="wcb-stat-number"><?php echo (int) $total_emp; ?></span>
					<span class="wcb-stat-label"><?php esc_html_e( 'Employers', 'wp-career-board' ); ?></span>
				</a>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=wcb-candidates' ) ); ?>" class="wcb-stat-box">
					<span class="wcb-stat-icon"><i data-lucide="users"></i></span>
					<span class="wcb-stat-number"><?php echo (int) $total_cand; ?></span>
					<span class="wcb-stat-label"><?php esc_html_e( 'Candidates', 'wp-career-board' ); ?></span>
				</a>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=wcb-jobs' ) ); ?>" class="wcb-stat-box<?php echo $pending_jobs > 0 ? ' wcb-stat-alert' : ''; ?>">
					<span class="wcb-stat-icon"><i data-lucide="flag"></i></span>
					<span class="wcb-stat-number"><?php echo (int) $pending_jobs; ?></span>
					<span class="wcb-stat-label"><?php esc_html_e( 'Pending Review', 'wp-career-board' ); ?></span>
				</a>
			</div>

			<div class="wcb-dashboard-columns">

		<?php /* ── Pending moderation queue ── */ ?>
				<div class="wcb-dashboard-col">
					<div class="wcb-dashboard-panel">
						<h2 class="wcb-panel-header" data-panel="pending_review">
			<?php esc_html_e( 'Pending Review', 'wp-career-board' ); ?>
							<span class="wcb-panel-header-right">
								<a href="<?php echo esc_url( admin_url( 'admin.php?page=wcb-jobs' ) ); ?>" class="wcb-panel-link">
									<?php esc_html_e( 'View all →', 'wp-career-board' ); ?>
								</a>
								<button type="button" class="wcb-panel-toggle" aria-label="<?php esc_attr_e( 'Toggle panel', 'wp-career-board' ); ?>">
									<i data-lucide="chevron-up"></i>
								</button>
							</span>
						</h2>
						<div class="wcb-panel-body">
			<?php if ( empty( $pending_posts ) ) : ?>
								<p class="wcb-empty"><?php esc_html_e( 'No jobs pending review.', 'wp-career-board' ); ?></p>
							<?php else : ?>
								<table class="widefat striped">
									<tbody>
								<?php foreach ( $pending_posts as $wcb_job ) : ?>
											<tr>
												<td>
													<a href="<?php echo esc_url( (string) get_edit_post_link( $wcb_job->ID ) ); ?>" style="font-weight:600">
									<?php echo esc_html( get_the_title( $wcb_job ) ); ?>
													</a>
													<br><small><?php echo esc_html( get_the_author_meta( 'display_name', (int) $wcb_job->post_author ) ); ?> &middot; <?php echo esc_html( get_the_date( 'M j', $wcb_job ) ); ?></small>
												</td>
												<td style="white-space:nowrap">
													<button type="button" class="wcb-btn wcb-btn--primary wcb-btn--sm wcb-approve-job" data-job-id="<?php echo (int) $wcb_job->ID; ?>"><?php esc_html_e( 'Approve', 'wp-career-board' ); ?></button>
													<button type="button" class="wcb-btn wcb-btn--sm wcb-reject-job" data-job-id="<?php echo (int) $wcb_job->ID; ?>"><?php esc_html_e( 'Reject', 'wp-career-board' ); ?></button>
												</td>
											</tr>
								<?php endforeach; ?>
									</tbody>
								</table>
							<?php endif; ?>
						</div>
					</div>
				</div>

		<?php /* ── Recent applications ── */ ?>
				<div class="wcb-dashboard-col">
					<div class="wcb-dashboard-panel">
						<h2 class="wcb-panel-header" data-panel="recent_apps">
			<?php esc_html_e( 'Recent Applications', 'wp-career-board' ); ?>
							<span class="wcb-panel-header-right">
								<a href="<?php echo esc_url( admin_url( 'admin.php?page=wcb-applications' ) ); ?>" class="wcb-panel-link">
									<?php esc_html_e( 'View all →', 'wp-career-board' ); ?>
								</a>
								<button type="button" class="wcb-panel-toggle" aria-label="<?php esc_attr_e( 'Toggle panel', 'wp-career-board' ); ?>">
									<i data-lucide="chevron-up"></i>
								</button>
							</span>
						</h2>
						<div class="wcb-panel-body">
		<?php if ( empty( $recent_apps ) ) : ?>
							<p class="wcb-empty"><?php esc_html_e( 'No applications yet.', 'wp-career-board' ); ?></p>
						<?php else : ?>
							<table class="widefat striped">
								<tbody>
							<?php foreach ( $recent_apps as $wcb_app ) : ?>
								<?php
								$wcb_job_id   = (int) get_post_meta( $wcb_app->ID, '_wcb_job_id', true );
								$wcb_cand_id  = (int) get_post_meta( $wcb_app->ID, '_wcb_candidate_id', true );
								$wcb_status   = (string) get_post_meta( $wcb_app->ID, '_wcb_status', true );
								$wcb_job_obj  = $wcb_job_id ? get_post( $wcb_job_id ) : null;
								$wcb_cand_obj = $wcb_cand_id ? get_userdata( $wcb_cand_id ) : false;
								$wcb_job_lbl  = $wcb_job_obj instanceof \WP_Post ? $wcb_job_obj->post_title : __( '(deleted)', 'wp-career-board' );
								$wcb_cand_lbl = $wcb_cand_obj instanceof \WP_User ? $wcb_cand_obj->display_name : __( '(deleted)', 'wp-career-board' );
								$wcb_status   = $wcb_status ? $wcb_status : 'submitted';
								?>
										<tr>
											<td>
												<strong><?php echo esc_html( $wcb_cand_lbl ); ?></strong><br>
												<small>
								<?php if ( $wcb_job_obj instanceof \WP_Post ) : ?>
														<a href="<?php echo esc_url( (string) get_edit_post_link( $wcb_job_id ) ); ?>"><?php echo esc_html( $wcb_job_lbl ); ?></a>
													<?php else : ?>
														<?php echo esc_html( $wcb_job_lbl ); ?>
													<?php endif; ?>
													&middot; <?php echo esc_html( get_the_date( 'M j', $wcb_app ) ); ?>
												</small>
											</td>
											<td>
								<?php
								$wcb_badge_map = array(
									'submitted'   => 'info',
									'reviewing'   => 'warn',
									'shortlisted' => 'success',
									'rejected'    => 'danger',
									'hired'       => 'success',
								);
								$wcb_badge_var = $wcb_badge_map[ $wcb_status ] ?? 'default';
								?>
												<span class="wcb-badge wcb-badge--<?php echo esc_attr( $wcb_badge_var ); ?>">
								<?php echo esc_html( ucfirst( $wcb_status ) ); ?>
												</span>
											</td>
										</tr>
							<?php endforeach; ?>
								</tbody>
							</table>
						<?php endif; ?>
						</div>
					</div>
				</div>

			</div><!-- .wcb-dashboard-columns -->

		<?php /* ── Quick actions ── */ ?>
			<div class="wcb-settings-card wcb-dashboard-actions-card">
				<div class="wcb-settings-card-header">
					<h2 class="wcb-settings-card-title"><?php esc_html_e( 'Quick Actions', 'wp-career-board' ); ?></h2>
				</div>
				<div class="wcb-dashboard-actions">
					<a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=wcb_job' ) ); ?>" class="wcb-action-item">
						<i data-lucide="plus"></i>
						<span><?php esc_html_e( 'Post a Job', 'wp-career-board' ); ?></span>
					</a>
					<a href="<?php echo esc_url( admin_url( 'user-new.php' ) ); ?>" class="wcb-action-item">
						<i data-lucide="user-plus"></i>
						<span><?php esc_html_e( 'Add User', 'wp-career-board' ); ?></span>
					</a>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=wcb-settings' ) ); ?>" class="wcb-action-item">
						<i data-lucide="settings"></i>
						<span><?php esc_html_e( 'Settings', 'wp-career-board' ); ?></span>
					</a>
		<?php if ( ! SetupWizard::is_setup_complete() ) : ?>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=wcb-setup' ) ); ?>" class="wcb-action-item">
						<i data-lucide="settings"></i>
						<span><?php esc_html_e( 'Setup Wizard', 'wp-career-board' ); ?></span>
					</a>
		<?php endif; ?>
				</div>
			</div>

		<?php /* ── Pro upgrade banner — hidden once Pro is active or banner dismissed ── */ ?>
		<?php
		$wcb_pro_active    = (bool) apply_filters( 'wcb_pro_active', false );
		$wcb_pro_upsell    = (string) apply_filters( 'wcb_pro_upsell_url', 'https://store.wbcomdesigns.com/wp-career-board-pro/' );
		$wcb_banner_hidden = (bool) get_user_meta( get_current_user_id(), 'wcb_pro_banner_dismissed', true );
		?>
		<?php if ( ! $wcb_pro_active && ! $wcb_banner_hidden ) : ?>
			<div class="wcb-settings-card wcb-pro-upgrade-card" id="wcb-pro-upgrade-banner">
				<div class="wcb-settings-card-header">
					<h2 class="wcb-settings-card-title"><?php esc_html_e( 'Unlock Pro Features', 'wp-career-board' ); ?></h2>
					<button type="button" class="wcb-pro-banner-dismiss" aria-label="<?php esc_attr_e( 'Dismiss', 'wp-career-board' ); ?>">
						<i data-lucide="x" class="wcb-icon--sm"></i>
					</button>
				</div>
				<div class="wcb-pro-upgrade-body">
					<ul class="wcb-pro-feature-list">
						<li>
							<i data-lucide="kanban"></i>
							<span><?php esc_html_e( 'Application Pipeline  -  Drag-and-drop Kanban hiring stages', 'wp-career-board' ); ?></span>
						</li>
						<li>
							<i data-lucide="file-user"></i>
							<span><?php esc_html_e( 'Resume Builder  -  Candidate resume profiles with rich fields', 'wp-career-board' ); ?></span>
						</li>
						<li>
							<i data-lucide="sparkles"></i>
							<span><?php esc_html_e( 'AI Job Descriptions  -  Auto-generate job posts with AI', 'wp-career-board' ); ?></span>
						</li>
						<li>
							<i data-lucide="credit-card"></i>
							<span><?php esc_html_e( 'Credits System  -  Sell job post credits via Stripe', 'wp-career-board' ); ?></span>
						</li>
					</ul>
					<a href="<?php echo esc_url( $wcb_pro_upsell ); ?>"
						target="_blank"
						rel="noopener noreferrer"
						class="wcb-btn wcb-btn--primary">
			<?php esc_html_e( 'Upgrade to Pro', 'wp-career-board' ); ?>
						<i data-lucide="external-link" class="wcb-icon--sm"></i>
					</a>
				</div>
			</div>
		<?php endif; ?>

		</div>
		<?php
	}

	/**
	 * Register the Emails submenu page (redirects to the Settings emails tab).
	 *
	 * Keeps old URL working while consolidating Emails into Settings > Emails tab.
	 *
	 * @since 1.0.0
	 */
	public function register_emails_submenu(): void {
		add_submenu_page(
			'wp-career-board',
			__( 'Emails', 'wp-career-board' ),
			'',
			'wcb_manage_settings',
			'wcb-emails',
			static function (): void {
				wp_safe_redirect( admin_url( 'admin.php?page=wcb-settings&tab=emails' ) );
				exit;
			}
		);

		// Remove from visible menu — page remains accessible for backward-compat redirect.
		global $submenu;
		if ( isset( $submenu['wp-career-board'] ) ) {
			foreach ( $submenu['wp-career-board'] as $wcb_key => $wcb_item ) {
				if ( 'wcb-emails' === ( $wcb_item[2] ?? '' ) ) {
					unset( $submenu['wp-career-board'][ $wcb_key ] );
					break;
				}
			}
		}
	}

	/**
	 * Enqueue admin CSS and JS on WCB admin pages.
	 *
	 * @since 1.0.0
	 *
	 * @param  string $hook Current admin page hook suffix.
	 * @return void
	 */
	public function enqueue_assets( string $hook ): void {
		global $post_type;
		$wcb_cpt_edit = ( 'post.php' === $hook || 'post-new.php' === $hook )
		&& in_array( $post_type, array( 'wcb_job', 'wcb_company', 'wcb_application' ), true );
		if ( ! $wcb_cpt_edit && false === strpos( $hook, 'wcb' ) && false === strpos( $hook, 'wp-career-board' ) ) {
			return;
		}

		wp_enqueue_style( 'wcb-tokens', WCB_URL . 'assets/css/admin/tokens.css', array(), WCB_VERSION );
		wp_enqueue_style( 'wcb-icons-css', WCB_URL . 'assets/css/admin/icons.css', array( 'wcb-tokens' ), WCB_VERSION );
		wp_enqueue_style( 'wcb-shared', WCB_URL . 'assets/css/admin/shared.css', array( 'wcb-tokens' ), WCB_VERSION );
		wp_enqueue_style( 'wcb-toast-css', WCB_URL . 'assets/css/admin/toast.css', array( 'wcb-tokens' ), WCB_VERSION );
		wp_enqueue_style( 'wcb-admin', WCB_URL . 'assets/css/admin.css', array( 'wcb-tokens' ), WCB_VERSION );
		wp_style_add_data( 'wcb-admin', 'rtl', 'replace' );

		wp_enqueue_script( 'lucide', WCB_URL . 'assets/js/vendor/lucide.min.js', array(), '0.460.0', true );
		wp_enqueue_script( 'wcb-icons', WCB_URL . 'assets/js/admin/icons.js', array( 'lucide' ), WCB_VERSION, true );
		wp_enqueue_script( 'wcb-toast', WCB_URL . 'assets/js/admin/toast.js', array(), WCB_VERSION, true );
		wp_enqueue_script( 'wcb-admin', WCB_URL . 'assets/js/admin.js', array( 'wp-api-fetch', 'wcb-toast' ), WCB_VERSION, true );

		wp_localize_script(
			'wcb-admin',
			'wcbAdmin',
			array(
				'restUrl'   => esc_url_raw( untrailingslashit( rest_url( 'wcb/v1' ) ) ),
				'restNonce' => wp_create_nonce( 'wp_rest' ),
				'i18n'      => array(
					'approveTitle' => __( 'Approve Job', 'wp-career-board' ),
					'approveMsg'   => __( 'This job will be published and the employer will be notified.', 'wp-career-board' ),
					'approveBtn'   => __( 'Approve', 'wp-career-board' ),
					'rejectTitle'  => __( 'Reject Job', 'wp-career-board' ),
					'rejectMsg'    => __( 'This job will be moved to Draft and the employer will be notified.', 'wp-career-board' ),
					'rejectBtn'    => __( 'Reject', 'wp-career-board' ),
					'reasonLabel'  => __( 'Reason (optional):', 'wp-career-board' ),
					'confirm'      => __( 'Confirm', 'wp-career-board' ),
					'cancel'       => __( 'Cancel', 'wp-career-board' ),
					'saveFailed'   => __( 'Could not update. Please try again.', 'wp-career-board' ),
				),
			)
		);

		// Settings page — sidebar layout CSS + hash-router JS.
		if ( str_contains( $hook, 'wcb-settings' ) ) {
			wp_enqueue_style( 'wcb-settings-css', WCB_URL . 'assets/css/admin/settings.css', array( 'wcb-tokens' ), WCB_VERSION );
			wp_enqueue_script( 'wcb-settings-nav', WCB_URL . 'assets/js/admin/settings-nav.js', array( 'lucide' ), WCB_VERSION, true );
		}

		// Application edit screen — composite widget assets.
		if ( ( 'post.php' === $hook || 'post-new.php' === $hook ) && 'wcb_application' === $post_type ) {
			wp_enqueue_style(
				'wcb-application-detail',
				WCB_URL . 'assets/css/admin/application-detail.css',
				array( 'wcb-tokens' ),
				WCB_VERSION
			);
			wp_enqueue_script(
				'wcb-application-detail',
				WCB_URL . 'assets/js/admin/application-detail.js',
				array(),
				WCB_VERSION,
				true
			);
			wp_localize_script(
				'wcb-application-detail',
				'wcbAppDetail',
				array(
					'savedLabel' => __( 'Saved.', 'wp-career-board' ),
					'errorLabel' => __( 'Could not save.', 'wp-career-board' ),
					'labels'     => \WCB\Modules\Applications\Widgets\StatusTimeline::status_labels(),
				)
			);
		}
	}
}
