<?php
/**
 * Admin settings page — registers, sanitizes, and renders WCB plugin settings.
 *
 * Settings stored as a single serialised array under the 'wcb_settings' option key.
 *
 * Keys and usage:
 *  auto_publish_jobs        — publish employer jobs without admin review (default: OFF)
 *  jobs_per_page            — listings per page in the job-listings block (default: 10)
 *  jobs_expire_days         — default listing lifetime in days (default: 30)
 *  deadline_auto_close      — auto-close jobs when application deadline passes (default: OFF)
 *  allow_withdraw           — let candidates withdraw their own applications (default: ON, only an explicit OFF turns it off)
 *  salary_currency          — default currency code for new job postings (default: USD)
 *  apply_resume_required    — require a resume on applications (default: ON, only an explicit OFF turns it off)
 *  jobs_archive_page        — page containing wcb/job-listings block
 *  employer_dashboard_page  — page containing wcb/employer-dashboard block
 *  candidate_dashboard_page — page containing wcb/candidate-dashboard block
 *  post_job_page            — page containing wcb/job-form block
 *  company_archive_page     — page containing wcb/company-archive block
 *  notification_email       — address that receives admin notifications
 *  from_name                — sender name for all WCB notification emails
 *  from_email               — sender address for all WCB notification emails
 *  max_resumes              — maximum resumes a candidate may create (Pro reader; default: 2)
 *  resume_archive_page      — page containing wcb/resume-archive block (Pro reader; default: 0)
 *
 * Developer hooks (for Pro extensions):
 *  Filter: wcb_settings_tabs( array $tabs )                      — add or reorder settings tabs
 *  Filter: wcb_settings_sanitize( array $output, array $input )  — extend sanitization for Pro keys
 *  Action: wcb_settings_tab_{slug}( array $settings )            — render a Pro tab's content
 *
 * @package WP_Career_Board
 * @since   1.0.0
 */

declare( strict_types=1 );

namespace WCB\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Manages the WCB settings page (Career Board > Settings).
 *
 * Writer — read raw option to render the form. This class is the sanitize
 * + render pair for the wcb_settings option, so every read here intentionally
 * uses get_option() directly. Reader sites elsewhere route through
 * \WCB\Admin\Settings (the cached accessor); this file is the exception.
 *
 * @since 1.0.0
 */
class AdminSettings {



	/**
	 * WordPress option key for all WCB settings.
	 *
	 * @since 1.0.0
	 * @var   string
	 */
	const OPTION_KEY = 'wcb_settings';

	/**
	 * Canonical currency catalog. Every consumer in Free + Pro reads from
	 * here — admin dropdowns, salary formatters, REST enum, sanitize
	 * allow-lists, Pro board settings, Pro CSV importer. There is no
	 * derivative helper; callers iterate the catalog and pick the
	 * field they need (`['symbol']`, `array_keys(...)`, etc.).
	 *
	 * Pro extends the catalog via the `wcb_currency_catalog` filter and
	 * MUST return the same `array{name, symbol}` shape so every consumer
	 * keeps trusting it.
	 *
	 * @since 1.0.0 (1.1.1: shape became array{name,symbol}; was string label).
	 * @var   array<string,array{name:string,symbol:string}>
	 */
	const CURRENCIES = array(
		'USD' => array(
			'name'   => 'US Dollar',
			'symbol' => '$',
		),
		'EUR' => array(
			'name'   => 'Euro',
			'symbol' => '€',
		),
		'GBP' => array(
			'name'   => 'British Pound',
			'symbol' => '£',
		),
		'CAD' => array(
			'name'   => 'Canadian Dollar',
			'symbol' => 'CA$',
		),
		'AUD' => array(
			'name'   => 'Australian Dollar',
			'symbol' => 'A$',
		),
		'INR' => array(
			'name'   => 'Indian Rupee',
			'symbol' => '₹',
		),
		'SGD' => array(
			'name'   => 'Singapore Dollar',
			'symbol' => 'S$',
		),
	);

	/**
	 * Filtered currency catalog — the single source of truth.
	 *
	 * @since 1.1.1
	 *
	 * @return array<string,array{name:string,symbol:string}>
	 */
	public static function get_currency_catalog(): array {
		/**
		 * Filter the canonical currency catalog. Pro hooks this to add
		 * JPY / BRL / MXN / etc. with their own names and symbols. Each
		 * entry must be `array{name: string, symbol: string}`; malformed
		 * entries are dropped so callers can trust the shape.
		 *
		 * @since 1.1.1
		 *
		 * @param array<string,array{name:string,symbol:string}> $catalog Base catalog.
		 */
		/** @var array<mixed,mixed> $catalog Filtered output may be anything. */
		$catalog = (array) apply_filters( 'wcb_currency_catalog', self::CURRENCIES );
		$out     = array();
		foreach ( $catalog as $code => $entry ) {
			if ( ! is_string( $code ) || ! is_array( $entry ) ) {
				continue;
			}
			$name   = $entry['name'] ?? null;
			$symbol = $entry['symbol'] ?? null;
			if ( ! is_string( $name ) || ! is_string( $symbol ) ) {
				continue;
			}
			$out[ $code ] = array(
				'name'   => $name,
				'symbol' => $symbol,
			);
		}
		return $out;
	}

	/**
	 * Boot the settings module.
	 *
	 * @since  1.0.0
	 * @return void
	 */
	public function boot(): void {
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'admin_post_wcb_create_pages', array( $this, 'handle_create_pages' ) );
		add_filter( 'wp_mail_from', array( $this, 'mail_from' ) );
		add_filter( 'wp_mail_from_name', array( $this, 'mail_from_name' ) );
		add_action( 'wcb_settings_tab_emails', array( $this, 'render_emails_tab' ) );
		add_action( 'wcb_settings_tab_import', array( $this, 'render_import_tab' ) );
	}

	/**
	 * Register the WCB settings group with WordPress.
	 *
	 * @since  1.0.0
	 * @return void
	 */
	public function register_settings(): void {
		register_setting(
			'wcb_settings_group',
			self::OPTION_KEY,
			array(
				'sanitize_callback' => array( $this, 'sanitize' ),
				'autoload'          => false,
			)
		);
	}

	/**
	 * Sanitize submitted settings values.
	 *
	 * @since 1.0.0
	 *
	 * @param  mixed $input Raw input from the settings form.
	 * @return array<string,mixed>
	 */
	public function sanitize( mixed $input ): array {
		$input    = is_array( $input ) ? $input : array();
		$existing = (array) get_option( self::OPTION_KEY, array() );

		// Determine which tab was submitted based on which fields are present.
		$tab_fields = array(
			'listings'      => array( 'auto_publish_jobs', 'jobs_per_page', 'jobs_expire_days', 'deadline_auto_close', 'allow_withdraw', 'salary_currency', 'apply_resume_required', 'apply_resume_max_mb', 'apply_featured_days', 'candidate_requires_role' ),
			'pages'         => array( 'jobs_archive_page', 'employer_dashboard_page', 'candidate_dashboard_page', 'company_archive_page', 'post_job_page', 'employer_registration_page', 'resume_archive_page' ),
			'notifications' => array( 'notification_email', 'from_name', 'from_email' ),
		);

		// Sanitize every known key; use submitted value when present, otherwise keep existing.
		$sanitized = array(
			'auto_publish_jobs'          => ! empty( $input['auto_publish_jobs'] ),
			'jobs_per_page'              => isset( $input['jobs_per_page'] ) ? max( 1, min( 100, (int) $input['jobs_per_page'] ) ) : 10,
			'jobs_expire_days'           => isset( $input['jobs_expire_days'] ) ? max( 1, (int) $input['jobs_expire_days'] ) : 30,
			'deadline_auto_close'        => ! empty( $input['deadline_auto_close'] ),
			'allow_withdraw'             => ! empty( $input['allow_withdraw'] ),
			'apply_resume_required'      => ! empty( $input['apply_resume_required'] ),
			'candidate_requires_role'    => ! empty( $input['candidate_requires_role'] ),
			'apply_resume_max_mb'        => isset( $input['apply_resume_max_mb'] ) ? max( 1, min( 20, (int) $input['apply_resume_max_mb'] ) ) : 5,
			'apply_featured_days'        => isset( $input['apply_featured_days'] ) ? max( 1, min( 365, (int) $input['apply_featured_days'] ) ) : 30,
			'salary_currency'            => isset( $input['salary_currency'] ) && array_key_exists( strtoupper( (string) $input['salary_currency'] ), self::get_currency_catalog() ) ? strtoupper( (string) $input['salary_currency'] ) : 'USD',
			'jobs_archive_page'          => isset( $input['jobs_archive_page'] ) ? (int) $input['jobs_archive_page'] : 0,
			'employer_dashboard_page'    => isset( $input['employer_dashboard_page'] ) ? (int) $input['employer_dashboard_page'] : 0,
			'candidate_dashboard_page'   => isset( $input['candidate_dashboard_page'] ) ? (int) $input['candidate_dashboard_page'] : 0,
			'company_archive_page'       => isset( $input['company_archive_page'] ) ? (int) $input['company_archive_page'] : 0,
			'post_job_page'              => isset( $input['post_job_page'] ) ? (int) $input['post_job_page'] : 0,
			'employer_registration_page' => isset( $input['employer_registration_page'] ) ? (int) $input['employer_registration_page'] : 0,
			'notification_email'         => isset( $input['notification_email'] ) ? sanitize_email( $input['notification_email'] ) : '',
			'from_name'                  => isset( $input['from_name'] ) ? sanitize_text_field( $input['from_name'] ) : '',
			'from_email'                 => isset( $input['from_email'] ) ? sanitize_email( $input['from_email'] ) : '',
			'resume_archive_page'        => isset( $input['resume_archive_page'] ) ? (int) $input['resume_archive_page'] : 0,
		);

		// Identify which tab was submitted by checking for its fields in $input.
		$submitted_tab = '';
		foreach ( $tab_fields as $tab => $fields ) {
			foreach ( $fields as $field ) {
				if ( array_key_exists( $field, $input ) ) {
					$submitted_tab = $tab;
					break 2;
				}
			}
		}

		// Start from existing settings, then overlay only the submitted tab's keys.
		$output = $existing;
		if ( $submitted_tab ) {
			foreach ( $tab_fields[ $submitted_tab ] as $field ) {
				$output[ $field ] = $sanitized[ $field ];
			}
		} else {
			// Fallback: unknown tab or full-form submission — apply all sanitized keys.
			$output = array_merge( $existing, $sanitized );
		}

		/**
		 * Filter the sanitized settings output.
		 *
		 * Pro extensions can validate and persist their own keys here.
		 *
		 * @since 1.0.0
		 *
		 * @param array<string,mixed> $output Sanitized settings.
		 * @param array<string,mixed> $input  Raw submitted values.
		 */
		return apply_filters( 'wcb_settings_sanitize', $output, $input );
	}

	/**
	 * Override wp_mail_from with the configured From Email.
	 *
	 * @since 1.0.0
	 *
	 * @param  string $email Default sender address.
	 * @return string
	 */
	public function mail_from( string $email ): string {
		$settings = (array) get_option( self::OPTION_KEY, array() );
		return ! empty( $settings['from_email'] ) ? $settings['from_email'] : $email;
	}

	/**
	 * Override wp_mail_from_name with the configured From Name.
	 *
	 * @since 1.0.0
	 *
	 * @param  string $name Default sender name.
	 * @return string
	 */
	public function mail_from_name( string $name ): string {
		$settings = (array) get_option( self::OPTION_KEY, array() );
		return ! empty( $settings['from_name'] ) ? $settings['from_name'] : $name;
	}

	/**
	 * Handle the "Create Missing Pages" form POST.
	 *
	 * @since  1.0.0
	 * @return void
	 */
	public function handle_create_pages(): void {
		check_admin_referer( 'wcb_create_pages' );

		// Defense-in-depth cap check alongside the Abilities API gate. The
		// `wcb/manage-settings` resolves to `manage_options` via the
		// Abilities API. The single gate is sufficient; no need to
		// double-check the capability the ability already wraps.
		if ( ! wp_is_ability_granted( 'wcb/manage-settings' ) ) { // phpcs:ignore WordPress.WP.Capabilities.Unknown -- polyfilled in core/abilities-api-polyfill.php.
			wp_die( esc_html__( 'You do not have permission to do this.', 'wp-career-board' ) );
		}

		$settings = (array) get_option( self::OPTION_KEY, array() );

		$pages = array(
			'jobs_archive_page'          => array(
				'title'   => __( 'Find Jobs', 'wp-career-board' ),
				'content' => '<!-- wp:wp-career-board/job-search /--><!-- wp:wp-career-board/job-filters /--><!-- wp:wp-career-board/job-listings /-->',
			),
			'employer_dashboard_page'    => array(
				'title'   => __( 'Employer Dashboard', 'wp-career-board' ),
				'content' => '<!-- wp:wp-career-board/employer-dashboard /-->',
			),
			'candidate_dashboard_page'   => array(
				'title'   => __( 'Candidate Dashboard', 'wp-career-board' ),
				'content' => '<!-- wp:wp-career-board/candidate-dashboard /-->',
			),
			'company_archive_page'       => array(
				'title'   => __( 'Companies', 'wp-career-board' ),
				'content' => '<!-- wp:wp-career-board/company-archive /-->',
			),
			'post_job_page'              => array(
				'title'   => __( 'Post a Job', 'wp-career-board' ),
				'content' => '<!-- wp:wp-career-board/job-form /-->',
			),
			'employer_registration_page' => array(
				'title'   => __( 'Employer Registration', 'wp-career-board' ),
				'content' => '<!-- wp:wp-career-board/employer-registration /-->',
			),
		);

		foreach ( $pages as $key => $page ) {
			if ( ! empty( $settings[ $key ] ) && get_post( (int) $settings[ $key ] ) ) {
				continue;
			}
			$page_id = wp_insert_post(
				array(
					'post_title'   => $page['title'],
					'post_content' => $page['content'],
					'post_status'  => 'publish',
					'post_type'    => 'page',
				)
			);
			if ( $page_id && ! is_wp_error( $page_id ) ) {
				$settings[ $key ] = $page_id;
			}
		}

		update_option( self::OPTION_KEY, $settings, false );

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'    => 'wcb-settings',
					'tab'     => 'pages',
					'created' => '1',
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	/**
	 * Return the ordered list of settings tabs.
	 *
	 * Pro extensions add tabs via the `wcb_settings_tabs` filter.
	 *
	 * @since  1.0.0
	 * @return array<string,string> Tab slug => label.
	 */
	private function get_tabs(): array {
		$tabs = array(
			'listings'      => __( 'Job Listings', 'wp-career-board' ),
			'pages'         => __( 'Pages', 'wp-career-board' ),
			'notifications' => __( 'Notifications', 'wp-career-board' ),
			'emails'        => __( 'Emails', 'wp-career-board' ),
			'import'        => __( 'Import', 'wp-career-board' ),
		);

		/**
		 * Filter the settings tab list.
		 *
		 * Add Pro tabs:
		 *   add_filter( 'wcb_settings_tabs', function( $tabs ) {
		 *       $tabs['credits'] = __( 'Credits', 'wp-career-board-pro' );
		 *       return $tabs;
		 *   } );
		 *
		 * @since 1.0.0
		 * @param array<string,string> $tabs Tab slug => label.
		 */
		return apply_filters( 'wcb_settings_tabs', $tabs );
	}

	/**
	 * Lucide icon names for each known sidebar nav item.
	 *
	 * @since  1.0.0
	 * @return array<string,string> Tab slug => Lucide icon name.
	 */
	private function get_tab_icons(): array {
		return array(
			'listings'      => 'list',
			'pages'         => 'file-text',
			'import'        => 'upload',
			'antispam'      => 'shield',
			'notifications' => 'bell',
			'emails'        => 'mail',
			'boards'        => 'layout-grid',
			'field-builder' => 'wrench',
			'ai-settings'   => 'sparkles',
			'job-feed'      => 'rss',
			'credits'       => 'credit-card',
			'pipeline'      => 'kanban',
			'integrations'  => 'puzzle',
			'license'       => 'key-round',
		);
	}

	/**
	 * Return the nav-group assignment for known Free tabs.
	 *
	 * Tabs not listed here are assumed to be "pro" group.
	 *
	 * @since  1.0.0
	 * @return array<string,string> Tab slug => group key.
	 */
	private function get_free_tab_slugs(): array {
		return array(
			'listings'      => 'general',
			'pages'         => 'general',
			'notifications' => 'general',
			'emails'        => 'general',
			'import'        => 'general',
			'antispam'      => 'general',
		);
	}

	/**
	 * Pro feature teaser tabs shown in the sidebar when Pro is not active.
	 *
	 * @since  1.0.0
	 * @return array<string,array{label:string}> Keyed by slug.
	 */
	private function get_pro_teaser_tabs(): array {
		return array(
			'pipeline'      => array( 'label' => __( 'Pipeline', 'wp-career-board' ) ),
			'credits'       => array( 'label' => __( 'Credits', 'wp-career-board' ) ),
			'field-builder' => array( 'label' => __( 'Field Builder', 'wp-career-board' ) ),
			'ai-settings'   => array( 'label' => __( 'AI Settings', 'wp-career-board' ) ),
			'job-feed'      => array( 'label' => __( 'Job Feed', 'wp-career-board' ) ),
			'boards'        => array( 'label' => __( 'Boards', 'wp-career-board' ) ),
		);
	}

	/**
	 * Render the Emails tab — delegates to EmailSettings::render_form().
	 *
	 * @since  1.0.0
	 * @return void
	 */
	public function render_emails_tab(): void {
		( new EmailSettings() )->render_form();
	}

	/**
	 * Render the Import tab — delegates to AdminImport::render().
	 *
	 * @since  1.0.0
	 * @return void
	 */
	public function render_import_tab(): void {
		( new AdminImport() )->render();

		// Sample data removal section. Defer detection to the wizard so out-of-sync
		// sites — flag is false but `wcb-sample-` jobs / `*.example.com` companies /
		// `_wcb_sample = 1` tagged posts still exist — also see the cleanup button
		// instead of being stranded.
		$wcb_has_sample = SetupWizard::has_sample_data();

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only post-redirect flag.
		if ( isset( $_GET['wcb_demo'] ) && 'installed' === sanitize_key( wp_unslash( $_GET['wcb_demo'] ) ) ) {
			echo '<div class="notice notice-success wcb-notice is-dismissible"><p>' . esc_html__( 'Sample data installed.', 'wp-career-board' ) . '</p></div>';
		}

		// Install option - shown when no sample data exists, so demo content can be
		// created straight from Settings (the setup wizard remains available too).
		if ( ! $wcb_has_sample ) :
			?>
			<div class="wcb-settings-card" id="wcb-install-sample-block">
				<div class="wcb-settings-card-header">
					<h2 class="wcb-settings-card-title"><?php esc_html_e( 'Sample Data', 'wp-career-board' ); ?></h2>
				</div>
				<div class="wcb-settings-row" style="display: block;">
					<p class="description" style="margin: 0 0 12px;"><?php esc_html_e( 'Install demo jobs, companies, and candidates so you can explore every feature. You can remove it again any time.', 'wp-career-board' ); ?></p>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="wcb_install_demo" />
			<?php wp_nonce_field( 'wcb_install_demo' ); ?>
						<button type="submit" class="button button-secondary"><?php esc_html_e( 'Install Sample Data', 'wp-career-board' ); ?></button>
					</form>
				</div>
			</div>
			<?php
		endif;

		if ( $wcb_has_sample ) :
			// Ensure the shared confirm-modal assets are present on the settings
			// page so wcbConfirm() resolves; wcbToast() ships with wcb-admin.
			wp_enqueue_style( 'wcb-confirm-modal' );
			wp_enqueue_script( 'wcb-confirm-modal' );
			?>
			<div class="wcb-settings-card" id="wcb-sample-data-block">
				<div class="wcb-settings-card-header">
					<h2 class="wcb-settings-card-title"><?php esc_html_e( 'Sample Data', 'wp-career-board' ); ?></h2>
				</div>
				<div class="wcb-settings-row" style="display: block;">
					<p class="description" style="margin: 0 0 12px;"><?php esc_html_e( 'Remove demo jobs, companies, candidates, and unused taxonomy terms created by the setup wizard or marked as sample.', 'wp-career-board' ); ?></p>
					<button type="button" id="wcb-remove-sample-data" class="button button-secondary">
				<?php esc_html_e( 'Remove Sample Data', 'wp-career-board' ); ?>
				</button>
				<span id="wcb-remove-sample-status" class="description" style="margin-left: 0.75rem;"></span>
				<script>
				( function () {
					var btn = document.getElementById( 'wcb-remove-sample-data' );
					if ( ! btn ) { return; }

					var labelDefault  = btn.textContent;
					var labelRemoving = <?php echo wp_json_encode( __( 'Removing…', 'wp-career-board' ) ); ?>;
					var i18n = {
						confirmTitle:   <?php echo wp_json_encode( __( 'Remove Sample Data', 'wp-career-board' ) ); ?>,
						confirmMessage: <?php echo wp_json_encode( __( 'Permanently delete all demo jobs, companies, candidates, and unused taxonomy terms? This cannot be undone.', 'wp-career-board' ) ); ?>,
						confirmCta:     <?php echo wp_json_encode( __( 'Delete Sample Data', 'wp-career-board' ) ); ?>,
						cancel:         <?php echo wp_json_encode( __( 'Cancel', 'wp-career-board' ) ); ?>,
						success:        <?php echo wp_json_encode( __( 'Removed %JOBS% sample jobs, %COMPANIES% sample companies, %CANDIDATES% sample candidates, %TERMS% taxonomy terms.', 'wp-career-board' ) ); ?>,
						emptyNotice:    <?php echo wp_json_encode( __( 'Nothing to remove - no sample data was found.', 'wp-career-board' ) ); ?>,
						error:          <?php echo wp_json_encode( __( 'Could not remove sample data. Please try again.', 'wp-career-board' ) ); ?>,
					};

					function toast( message, type ) {
						if ( 'function' === typeof window.wcbToast ) {
							window.wcbToast( message, type || 'info' );
						}
					}

					function openConfirm() {
						if ( 'function' === typeof window.wcbConfirm ) {
							return window.wcbConfirm( {
								title:       i18n.confirmTitle,
								message:     i18n.confirmMessage,
								confirmText: i18n.confirmCta,
								cancelText:  i18n.cancel,
								destructive: true,
							} );
						}
						// Last-resort fallback — only fires if the modal asset failed to load.
						return window.confirm( i18n.confirmMessage )
							? Promise.resolve( true )
							: Promise.reject();
					}

					btn.addEventListener( 'click', function () {
						openConfirm().then( function () {
							var status = document.getElementById( 'wcb-remove-sample-status' );
							btn.disabled = true;
							btn.textContent = labelRemoving;
							status.textContent = '';

							return fetch( wcbAdmin.restUrl + '/wizard/remove-sample-data', {
								method:  'POST',
								headers: {
									'X-WP-Nonce':   wcbAdmin.restNonce,
									'Content-Type': 'application/json',
								},
							} ).then( function ( r ) {
								if ( ! r.ok ) { throw new Error( 'http ' + r.status ); }
								return r.json();
							} ).then( function ( data ) {
								var jobs       = parseInt( data && data.jobs, 10 ) || 0;
								var companies  = parseInt( data && data.companies, 10 ) || 0;
								var candidates = parseInt( data && data.candidates, 10 ) || 0;
								var terms      = parseInt( data && data.terms, 10 ) || 0;
								var total      = jobs + companies + candidates + terms;

								if ( total > 0 ) {
									var msg = i18n.success
										.replace( '%JOBS%', String( jobs ) )
										.replace( '%COMPANIES%', String( companies ) )
										.replace( '%CANDIDATES%', String( candidates ) )
										.replace( '%TERMS%', String( terms ) );
									status.textContent = msg;
									toast( msg, 'success' );
									setTimeout( function () {
										var block = document.getElementById( 'wcb-sample-data-block' );
										if ( block ) { block.style.display = 'none'; }
									}, 2500 );
								} else {
									status.textContent = i18n.emptyNotice;
									toast( i18n.emptyNotice, 'info' );
									btn.disabled = false;
									btn.textContent = labelDefault;
								}
							} );
						} ).catch( function ( err ) {
							// User cancelled the modal — `err` is undefined; do nothing.
							if ( ! err ) { return; }
							var status = document.getElementById( 'wcb-remove-sample-status' );
							if ( status ) { status.textContent = i18n.error; }
							toast( i18n.error, 'error' );
							btn.disabled = false;
							btn.textContent = labelDefault;
						} );
					} );
				} )();
				</script>
				</div>
			</div>
			<?php
		endif;
	}

	/**
	 * Render the settings page with sidebar navigation.
	 *
	 * @since  1.0.0
	 * @return void
	 */
	public function render(): void {
		$settings           = (array) get_option( self::OPTION_KEY, array() );
		$salary_currency    = isset( $settings['salary_currency'] ) ? $settings['salary_currency'] : 'USD';
		$notification_email = ! empty( $settings['notification_email'] ) ? $settings['notification_email'] : (string) get_option( 'admin_email', '' );
		$from_name          = ! empty( $settings['from_name'] ) ? $settings['from_name'] : (string) get_option( 'blogname', '' );
		$from_email         = ! empty( $settings['from_email'] ) ? $settings['from_email'] : (string) get_option( 'admin_email', '' );

		$wcb_tabs      = $this->get_tabs();
		$wcb_tab_icons = $this->get_tab_icons();
		$wcb_free_tabs = $this->get_free_tab_slugs();

		$wcb_page_keys = array( 'jobs_archive_page', 'employer_dashboard_page', 'candidate_dashboard_page', 'company_archive_page', 'post_job_page', 'employer_registration_page' );
		$wcb_missing   = array();
		foreach ( $wcb_page_keys as $wcb_k ) {
			if ( 0 === Pages::get_id( $wcb_k ) ) {
				$wcb_missing[] = $wcb_k;
			}
		}

		// Group tabs for the sidebar.
		$wcb_groups = array(
			'general' => array(
				'label' => __( 'General', 'wp-career-board' ),
				'items' => array(),
			),
			'pro'     => array(
				'label' => __( 'Pro', 'wp-career-board' ),
				'items' => array(),
			),
		);

		foreach ( $wcb_tabs as $wcb_slug => $wcb_label ) {
			$wcb_group = $wcb_free_tabs[ $wcb_slug ] ?? 'pro';
			if ( ! isset( $wcb_groups[ $wcb_group ] ) ) {
				$wcb_group = 'pro';
			}
			$wcb_groups[ $wcb_group ]['items'][ $wcb_slug ] = $wcb_label;
		}

		// Remove empty groups.
		$wcb_groups = array_filter(
			$wcb_groups,
			static fn( array $g ): bool => ! empty( $g['items'] )
		);

		// Tabs that save via options.php (Settings API).
		$wcb_settings_tabs = array( 'listings', 'pages', 'notifications' );
		?>
		<div class="wrap wcb-admin">

			<h1 class="screen-reader-text"><?php esc_html_e( 'Career Board Settings', 'wp-career-board' ); ?></h1>

		<?php if ( isset( $_GET['settings-updated'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
				<div class="notice notice-success wcb-notice is-dismissible">
					<p><?php esc_html_e( 'Settings saved.', 'wp-career-board' ); ?></p>
				</div>
		<?php endif; ?>

		<?php
		// Pro returns a notice text when its own settings save fired (e.g. ?wcbp_saved=1).
		// Filter declared in core/class-pro-coordination.php (F-1).
		$wcb_pro_saved_notice = apply_filters( 'wcb_pro_settings_saved_notice', null );
		if ( ! empty( $wcb_pro_saved_notice ) ) :
			?>
				<div class="notice notice-success wcb-notice is-dismissible">
					<p><?php echo esc_html( (string) $wcb_pro_saved_notice ); ?></p>
				</div>
			<?php
		endif;
		?>

		<?php if ( isset( $_GET['created'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
				<div class="notice notice-success wcb-notice is-dismissible">
					<p><?php esc_html_e( 'Missing pages created and assigned successfully.', 'wp-career-board' ); ?></p>
				</div>
		<?php endif; ?>

		<?php if ( isset( $_GET['test_email'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
			<?php if ( 'sent' === $_GET['test_email'] ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
					<div class="notice notice-success wcb-notice is-dismissible">
						<p><?php esc_html_e( 'Test email sent. Please check your inbox.', 'wp-career-board' ); ?></p>
					</div>
				<?php else : ?>
					<div class="notice notice-error wcb-notice is-dismissible">
						<p><?php esc_html_e( 'Test email failed. Check your server mail configuration.', 'wp-career-board' ); ?></p>
					</div>
				<?php endif; ?>
		<?php endif; ?>

		<?php if ( ! empty( $wcb_missing ) ) : ?>
			<?php
			$wcb_missing_labels = array(
				'jobs_archive_page'        => __( 'Find Jobs', 'wp-career-board' ),
				'employer_dashboard_page'  => __( 'Employer Dashboard', 'wp-career-board' ),
				'candidate_dashboard_page' => __( 'Candidate Dashboard', 'wp-career-board' ),
				'company_archive_page'     => __( 'Companies', 'wp-career-board' ),
				'post_job_page'            => __( 'Post a Job', 'wp-career-board' ),
			);
			$wcb_missing_names  = array_map( static fn( string $k ): string => $wcb_missing_labels[ $k ] ?? $k, $wcb_missing );
			?>
				<div class="notice notice-warning wcb-notice">
					<p>
						<strong><?php esc_html_e( 'Missing pages:', 'wp-career-board' ); ?></strong>
			<?php echo esc_html( implode( ', ', $wcb_missing_names ) ); ?>
					</p>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top: 6px;">
						<input type="hidden" name="action" value="wcb_create_pages">
			<?php wp_nonce_field( 'wcb_create_pages' ); ?>
			<?php submit_button( __( 'Create Missing Pages', 'wp-career-board' ), 'primary', 'submit', false ); ?>
					</form>
				</div>
		<?php endif; ?>

			<div class="wcb-page-header">
				<div class="wcb-page-header__left">
					<h2 class="wcb-page-header__title">
						<i data-lucide="settings" class="wcb-icon--lg"></i>
		<?php esc_html_e( 'WP Career Board', 'wp-career-board' ); ?>
						<span class="wcb-version-badge">v<?php echo esc_html( WCB_VERSION ); ?></span>
					</h2>
					<p class="wcb-page-header__desc"><?php esc_html_e( 'Career Board settings and configuration', 'wp-career-board' ); ?></p>
				</div>
				<div class="wcb-page-header__actions">
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=wcb-setup' ) ); ?>" class="wcb-btn">
						<i data-lucide="settings" class="wcb-icon--sm"></i>
		<?php esc_html_e( 'Run Setup Wizard', 'wp-career-board' ); ?>
					</a>
				</div>
			</div>

			<!-- ── Sidebar + Content layout ─────────────────────────────────── -->
			<div class="wcb-settings-wrap">

				<!-- Sidebar -->
				<aside class="wcb-settings-sidebar">
					<div class="wcb-settings-sidebar__brand">
						<span class="wcb-settings-sidebar__logo"><i data-lucide="briefcase"></i></span>
						<span class="wcb-settings-sidebar__brand-text">
							<strong><?php esc_html_e( 'Career Board', 'wp-career-board' ); ?></strong>
							<span>v<?php echo esc_html( WCB_VERSION ); ?></span>
						</span>
					</div>
		<?php foreach ( $wcb_groups as $wcb_gkey => $wcb_group ) : ?>
					<nav class="wcb-settings-nav-group" aria-label="<?php echo esc_attr( $wcb_group['label'] ); ?>">
						<span class="wcb-settings-nav-group__label"><?php echo esc_html( $wcb_group['label'] ); ?></span>
			<?php foreach ( $wcb_group['items'] as $wcb_slug => $wcb_label ) : ?>
							<a href="#<?php echo esc_attr( $wcb_slug ); ?>" class="wcb-settings-nav-item" data-section="<?php echo esc_attr( $wcb_slug ); ?>">
								<i data-lucide="<?php echo esc_attr( $wcb_tab_icons[ $wcb_slug ] ?? 'settings' ); ?>"></i>
				<?php echo esc_html( $wcb_label ); ?>
				<?php if ( 'pro' === $wcb_gkey ) : ?>
									<span class="wcb-pro-badge"><?php esc_html_e( 'Pro', 'wp-career-board' ); ?></span>
				<?php endif; ?>
							</a>
			<?php endforeach; ?>
					</nav>
		<?php endforeach; ?>
		<?php
		// Pro filter (F-1) decides whether to show the Pro teasers nav group.
		$wcb_pro_active_for_teasers = (bool) apply_filters( 'wcb_pro_active', false );
		$wcb_pro_upsell_url         = (string) apply_filters( 'wcb_pro_upsell_url', 'https://store.wbcomdesigns.com/wp-career-board-pro/' );
		if ( ! $wcb_pro_active_for_teasers ) :
			?>
			<?php $wcb_pro_teasers = $this->get_pro_teaser_tabs(); ?>
					<nav class="wcb-settings-nav-group wcb-settings-nav-group--pro-teasers" aria-label="<?php esc_attr_e( 'Pro', 'wp-career-board' ); ?>">
						<span class="wcb-settings-nav-group__label"><?php esc_html_e( 'Pro', 'wp-career-board' ); ?></span>
			<?php foreach ( $wcb_pro_teasers as $wcb_teaser_slug => $wcb_teaser ) : ?>
							<a href="<?php echo esc_url( $wcb_pro_upsell_url ); ?>"
								target="_blank"
								rel="noopener noreferrer"
								class="wcb-settings-nav-item wcb-settings-nav-item--teaser"
								aria-label="<?php echo esc_attr( sprintf( '%s — %s', $wcb_teaser['label'], __( 'Requires Pro', 'wp-career-board' ) ) ); ?>">
								<i data-lucide="<?php echo esc_attr( $wcb_tab_icons[ $wcb_teaser_slug ] ?? 'lock' ); ?>"></i>
				<?php echo esc_html( $wcb_teaser['label'] ); ?>
								<i data-lucide="lock" class="wcb-icon wcb-nav-lock-icon"></i>
							</a>
			<?php endforeach; ?>
					</nav>
		<?php endif; ?>
				</aside>

				<!-- Content -->
				<div class="wcb-settings-content">

					<!-- ── Listings ─────────────────────────────────────────── -->
					<div class="wcb-settings-section" id="section-listings">
						<form method="post" action="options.php">
		<?php settings_fields( 'wcb_settings_group' ); ?>
							<div class="wcb-card">
								<div class="wcb-card__head">
									<p class="wcb-card__title"><?php esc_html_e( 'Job Listings', 'wp-career-board' ); ?></p>
									<p class="wcb-card__desc"><?php esc_html_e( 'Configure job listing behavior and defaults.', 'wp-career-board' ); ?></p>
								</div>
								<div class="wcb-card__body">
									<div class="wcb-settings-row">
										<div class="wcb-settings-row-label"><?php esc_html_e( 'Auto-Publish Jobs', 'wp-career-board' ); ?></div>
										<div class="wcb-settings-row-control">
											<label class="wcb-toggle-label">
												<span class="wcb-toggle">
													<input type="checkbox" name="wcb_settings[auto_publish_jobs]" value="1" <?php checked( ! empty( $settings['auto_publish_jobs'] ) ); ?>>
													<span class="wcb-toggle-slider"></span>
												</span>
												<?php esc_html_e( 'Publish jobs immediately without admin review', 'wp-career-board' ); ?>
											</label>
											<span class="description"><?php esc_html_e( 'When unchecked, new jobs are held as "Pending" until approved under Career Board > Jobs.', 'wp-career-board' ); ?></span>
										</div>
									</div>
									<div class="wcb-settings-row">
										<div class="wcb-settings-row-label"><label for="wcb-jobs-per-page"><?php esc_html_e( 'Jobs Per Page', 'wp-career-board' ); ?></label></div>
										<div class="wcb-settings-row-control">
											<input type="number" id="wcb-jobs-per-page" name="wcb_settings[jobs_per_page]" value="<?php echo isset( $settings['jobs_per_page'] ) ? (int) $settings['jobs_per_page'] : 10; ?>" min="1" max="100" style="width:80px">
											<span class="description"><?php esc_html_e( 'Number of job listings shown per page in the job board block. Maximum 100.', 'wp-career-board' ); ?></span>
										</div>
									</div>
									<div class="wcb-settings-row">
										<div class="wcb-settings-row-label"><label for="wcb-jobs-expire-days"><?php esc_html_e( 'Job Expiry (days)', 'wp-career-board' ); ?></label></div>
										<div class="wcb-settings-row-control">
											<input type="number" id="wcb-jobs-expire-days" name="wcb_settings[jobs_expire_days]" value="<?php echo isset( $settings['jobs_expire_days'] ) ? (int) $settings['jobs_expire_days'] : 30; ?>" min="1" max="365" style="width:80px">
											<span class="description"><?php esc_html_e( 'Default: 30 days. Jobs older than this auto-close. Closing is reversible  -  open the job in admin and republish to extend the lifetime.', 'wp-career-board' ); ?></span>
										</div>
									</div>
									<div class="wcb-settings-row">
										<div class="wcb-settings-row-label"><?php esc_html_e( 'Deadline Auto-Close', 'wp-career-board' ); ?></div>
										<div class="wcb-settings-row-control">
											<label class="wcb-toggle-label">
												<span class="wcb-toggle">
													<input type="checkbox" name="wcb_settings[deadline_auto_close]" value="1" <?php checked( ! empty( $settings['deadline_auto_close'] ) ); ?>>
													<span class="wcb-toggle-slider"></span>
												</span>
												<?php esc_html_e( 'Automatically close jobs when their application deadline passes', 'wp-career-board' ); ?>
											</label>
											<span class="description"><?php esc_html_e( 'Off by default. Runs hourly via WP-Cron  -  make sure your host has cron working (DISABLE_WP_CRON should not be set, or wp-cli should run it externally). Closed jobs remain visible but show "Applications Closed" instead of the apply form.', 'wp-career-board' ); ?></span>
										</div>
									</div>
									<div class="wcb-settings-row">
										<div class="wcb-settings-row-label"><?php esc_html_e( 'Allow Withdraw', 'wp-career-board' ); ?></div>
										<div class="wcb-settings-row-control">
											<label class="wcb-toggle-label">
												<span class="wcb-toggle">
													<input type="checkbox" name="wcb_settings[allow_withdraw]" value="1" <?php checked( array_key_exists( 'allow_withdraw', $settings ) ? ! empty( $settings['allow_withdraw'] ) : true ); ?>>
													<span class="wcb-toggle-slider"></span>
												</span>
												<?php esc_html_e( 'Let candidates withdraw their own applications', 'wp-career-board' ); ?>
											</label>
											<span class="description"><?php esc_html_e( 'On by default. Withdrawn applications are removed from the employer\'s applicant list. Turn off for boards that want apply-once-final flows (compliance, regulated hiring).', 'wp-career-board' ); ?></span>
										</div>
									</div>
									<div class="wcb-settings-row">
										<div class="wcb-settings-row-label"><label for="wcb-salary-currency"><?php esc_html_e( 'Default Salary Currency', 'wp-career-board' ); ?></label></div>
										<div class="wcb-settings-row-control">
											<select id="wcb-salary-currency" name="wcb_settings[salary_currency]">
												<?php foreach ( self::get_currency_catalog() as $wcb_code => $wcb_meta ) : ?>
													<option value="<?php echo esc_attr( $wcb_code ); ?>" <?php selected( $salary_currency, $wcb_code ); ?>>
														<?php
														printf(
															/* translators: 1: code (USD), 2: name (US Dollar), 3: symbol ($). */
															esc_html__( '%1$s  -  %2$s (%3$s)', 'wp-career-board' ),
															esc_html( (string) $wcb_code ),
															esc_html( (string) $wcb_meta['name'] ),
															esc_html( (string) $wcb_meta['symbol'] )
														);
														?>
													</option>
												<?php endforeach; ?>
											</select>
											<span class="description"><?php esc_html_e( 'Site-wide default for new job postings. Employers can override it per job.', 'wp-career-board' ); ?></span>
										</div>
									</div>
									<div class="wcb-settings-row">
										<div class="wcb-settings-row-label"><?php esc_html_e( 'Resume Required', 'wp-career-board' ); ?></div>
										<div class="wcb-settings-row-control">
											<label class="wcb-toggle-label">
												<span class="wcb-toggle">
													<input type="checkbox" name="wcb_settings[apply_resume_required]" value="1" <?php checked( array_key_exists( 'apply_resume_required', $settings ) ? ! empty( $settings['apply_resume_required'] ) : true ); ?>>
													<span class="wcb-toggle-slider"></span>
												</span>
												<?php esc_html_e( 'Require applicants to attach a resume', 'wp-career-board' ); ?>
											</label>
											<span class="description"><?php esc_html_e( 'On by default. Turn off only for boards where applicants can apply with a cover letter alone (e.g. internal job boards, walk-in roles).', 'wp-career-board' ); ?></span>
										</div>
									</div>
									<div class="wcb-settings-row">
										<div class="wcb-settings-row-label"><?php esc_html_e( 'Require Candidate Role', 'wp-career-board' ); ?></div>
										<div class="wcb-settings-row-control">
											<label class="wcb-toggle-label">
												<span class="wcb-toggle">
													<input type="checkbox" name="wcb_settings[candidate_requires_role]" value="1" <?php checked( ! empty( $settings['candidate_requires_role'] ) ); ?>>
													<span class="wcb-toggle-slider"></span>
												</span>
												<?php esc_html_e( 'Only the Candidate role can apply, bookmark, and use the candidate dashboard', 'wp-career-board' ); ?>
											</label>
											<span class="description"><?php esc_html_e( 'Off by default: any logged-in member can apply and manage a resume (ideal when the job board is part of a community site). Turn on to reserve the candidate experience for users with the Candidate role.', 'wp-career-board' ); ?></span>
										</div>
									</div>
									<div class="wcb-settings-row">
										<div class="wcb-settings-row-label"><label for="wcb-resume-max-mb"><?php esc_html_e( 'Application Resume File Size (MB)', 'wp-career-board' ); ?></label></div>
										<div class="wcb-settings-row-control">
											<input
												id="wcb-resume-max-mb"
												type="number"
												name="wcb_settings[apply_resume_max_mb]"
												value="<?php echo esc_attr( (string) ( isset( $settings['apply_resume_max_mb'] ) ? (int) $settings['apply_resume_max_mb'] : 5 ) ); ?>"
												min="1"
												max="20"
												step="1"
											>
											<span class="description"><?php esc_html_e( 'Maximum size of a resume file a candidate uploads when applying to a job (1-20 MB). Accepted formats: PDF, DOC, DOCX. The resume profile builder lives under Settings > Resumes.', 'wp-career-board' ); ?></span>
										</div>
									</div>
									<div class="wcb-settings-row">
										<div class="wcb-settings-row-label"><label for="wcb-featured-days"><?php esc_html_e( 'Featured Duration (days)', 'wp-career-board' ); ?></label></div>
										<div class="wcb-settings-row-control">
											<input
												id="wcb-featured-days"
												type="number"
												name="wcb_settings[apply_featured_days]"
												value="<?php echo esc_attr( (string) ( isset( $settings['apply_featured_days'] ) ? (int) $settings['apply_featured_days'] : 30 ) ); ?>"
												min="1"
												max="365"
												step="1"
											>
											<span class="description"><?php esc_html_e( 'How many days a job stays in the Featured spotlight before reverting automatically. Daily cron clears expired flags.', 'wp-career-board' ); ?></span>
										</div>
									</div>
								</div>
							</div>
							<div class="wcb-settings-section__footer">
								<?php submit_button( __( 'Save Changes', 'wp-career-board' ), 'primary', 'submit', false, array( 'class' => 'wcb-btn wcb-btn--primary' ) ); ?>
							</div>
						</form>
					</div>

					<!-- ── Pages ────────────────────────────────────────────── -->
					<div class="wcb-settings-section" id="section-pages">
						<form method="post" action="options.php">
		<?php settings_fields( 'wcb_settings_group' ); ?>
							<div class="wcb-card">
								<div class="wcb-card__head">
									<p class="wcb-card__title"><?php esc_html_e( 'Pages', 'wp-career-board' ); ?></p>
									<p class="wcb-card__desc"><?php esc_html_e( 'Assign the WordPress pages that contain each WP Career Board block.', 'wp-career-board' ); ?></p>
								</div>
								<div class="wcb-card__body">
									<?php
									$wcb_page_settings = array(
										'jobs_archive_page' => array(
											'label' => __( 'Jobs Archive Page', 'wp-career-board' ),
											'desc'  => __( 'Contains the wcb/job-listings block. Used as the main job board.', 'wp-career-board' ),
										),
										'employer_dashboard_page' => array(
											'label' => __( 'Employer Dashboard Page', 'wp-career-board' ),
											'desc'  => __( 'Contains the wcb/employer-dashboard block. Employers manage jobs and profiles here.', 'wp-career-board' ),
										),
										'candidate_dashboard_page' => array(
											'label' => __( 'Candidate Dashboard Page', 'wp-career-board' ),
											'desc'  => __( 'Contains the wcb/candidate-dashboard block. Candidates track applications and saved jobs.', 'wp-career-board' ),
										),
										'company_archive_page' => array(
											'label' => __( 'Company Directory Page', 'wp-career-board' ),
											'desc'  => __( 'Contains the wcb/company-archive block. Lists all employer company profiles.', 'wp-career-board' ),
										),
										'post_job_page' => array(
											'label' => __( 'Post a Job Page', 'wp-career-board' ),
											'desc'  => __( 'Contains the wcb/job-form block. Employers use this to post new jobs.', 'wp-career-board' ),
										),
										'employer_registration_page' => array(
											'label' => __( 'Employer Registration Page', 'wp-career-board' ),
											'desc'  => __( 'Contains the wcb/employer-registration block. New employers sign up and gain posting access here.', 'wp-career-board' ),
										),
									);

									/**
									 * Filter the page settings configuration.
									 *
									 * @since 1.0.0
									 */
									$wcb_page_settings = (array) apply_filters( 'wcb_page_settings', $wcb_page_settings );
									?>
		<?php foreach ( $wcb_page_settings as $wcb_key => $wcb_info ) : ?>
			<?php $wcb_resolved_id = (int) Pages::get_id( (string) $wcb_key ); ?>
										<div class="wcb-settings-row">
											<div class="wcb-settings-row-label">
												<label for="wcb-page-<?php echo esc_attr( sanitize_key( $wcb_key ) ); ?>"><?php echo esc_html( $wcb_info['label'] ); ?></label>
											</div>
											<div class="wcb-settings-row-control">
			<?php
			wp_dropdown_pages(
				array(
					'id'               => 'wcb-page-' . sanitize_key( $wcb_key ),
					'name'             => 'wcb_settings[' . sanitize_key( $wcb_key ) . ']',
					'selected'         => (int) $wcb_resolved_id,
					'show_option_none' => esc_html__( ' -  Select a page  - ', 'wp-career-board' ),
				)
			);
			if ( $wcb_resolved_id ) {
				$wcb_page_url = get_permalink( $wcb_resolved_id );
				if ( $wcb_page_url ) {
					echo ' <a href="' . esc_url( $wcb_page_url ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'View Page →', 'wp-career-board' ) . '</a>';
				}
			}
			?>
												<span class="description"><?php echo esc_html( $wcb_info['desc'] ); ?></span>
											</div>
										</div>
		<?php endforeach; ?>
								</div>
							</div>
							<div class="wcb-settings-section__footer">
		<?php submit_button( __( 'Save Changes', 'wp-career-board' ), 'primary', 'submit', false, array( 'class' => 'wcb-btn wcb-btn--primary' ) ); ?>
							</div>
						</form>
					</div>

					<!-- ── Notifications ────────────────────────────────────── -->
					<div class="wcb-settings-section" id="section-notifications">
						<form method="post" action="options.php">
		<?php settings_fields( 'wcb_settings_group' ); ?>
							<div class="wcb-card">
								<div class="wcb-card__head">
									<p class="wcb-card__title"><?php esc_html_e( 'Email Configuration', 'wp-career-board' ); ?></p>
									<p class="wcb-card__desc"><?php esc_html_e( 'Configure sender details and admin notification address.', 'wp-career-board' ); ?></p>
								</div>
								<div class="wcb-card__body">
									<div class="wcb-settings-row">
										<div class="wcb-settings-row-label"><label for="wcb-from-name"><?php esc_html_e( 'From Name', 'wp-career-board' ); ?></label></div>
										<div class="wcb-settings-row-control">
											<input type="text" id="wcb-from-name" name="wcb_settings[from_name]" value="<?php echo esc_attr( $from_name ); ?>" class="regular-text">
											<span class="description"><?php esc_html_e( 'Sender name shown on all WCB notification emails. Defaults to your site name.', 'wp-career-board' ); ?></span>
										</div>
									</div>
									<div class="wcb-settings-row">
										<div class="wcb-settings-row-label"><label for="wcb-from-email"><?php esc_html_e( 'From Email', 'wp-career-board' ); ?></label></div>
										<div class="wcb-settings-row-control">
											<input type="email" id="wcb-from-email" name="wcb_settings[from_email]" value="<?php echo esc_attr( $from_email ); ?>" class="regular-text">
											<span class="description"><?php esc_html_e( 'Sender address for all WCB emails. Defaults to the site admin email.', 'wp-career-board' ); ?></span>
										</div>
									</div>
									<div class="wcb-settings-row">
										<div class="wcb-settings-row-label"><label for="wcb-notification-email"><?php esc_html_e( 'Admin Notification Email', 'wp-career-board' ); ?></label></div>
										<div class="wcb-settings-row-control">
											<input type="email" id="wcb-notification-email" name="wcb_settings[notification_email]" value="<?php echo esc_attr( $notification_email ); ?>" class="regular-text" required>
											<span class="description"><?php esc_html_e( 'Where admin alerts (new jobs, flagged content) are sent. Defaults to the site admin email.', 'wp-career-board' ); ?></span>
										</div>
									</div>
								</div>
							</div>
							<div class="wcb-settings-section__footer">
		<?php submit_button( __( 'Save Changes', 'wp-career-board' ), 'primary', 'submit', false, array( 'class' => 'wcb-btn wcb-btn--primary' ) ); ?>
							</div>
						</form>
					</div>

					<!-- ── Emails ───────────────────────────────────────────── -->
					<div class="wcb-settings-section" id="section-emails">
		<?php
		/**
		 * Render the Emails tab content.
		 *
		 * @since 1.0.0
		 * @param array<string,mixed> $settings Current WCB settings.
		 */
		do_action( 'wcb_settings_tab_emails', $settings );
		?>
					</div>

		<?php
		// Render Pro / extension tab sections.
		$wcb_builtin = array( 'listings', 'pages', 'notifications', 'emails' );
		foreach ( $wcb_tabs as $wcb_slug => $wcb_label ) :
			if ( in_array( $wcb_slug, $wcb_builtin, true ) ) {
				continue;
			}
			?>
						<div class="wcb-settings-section" id="section-<?php echo esc_attr( $wcb_slug ); ?>">
			<?php
			/**
			 * Render content for a Pro or custom settings tab.
			 *
			 * @since 1.0.0
			 * @param array<string,mixed> $settings Current WCB settings.
			 */
			do_action( 'wcb_settings_tab_' . $wcb_slug, $settings );
			?>
						</div>
		<?php endforeach; ?>

				</div><!-- .wcb-settings-content -->
			</div><!-- .wcb-settings-wrap -->

			<p class="wcb-settings-page-footer">
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=wcb-setup&wcb_rerun=1' ) ); ?>">
					<?php esc_html_e( 'Re-run Setup Wizard', 'wp-career-board' ); ?>
				</a>
				<span class="separator" aria-hidden="true">·</span>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=wp-career-board' ) ); ?>">
					<?php esc_html_e( 'Back to Dashboard', 'wp-career-board' ); ?>
				</a>
			</p>

		</div>
		<?php
	}
}
