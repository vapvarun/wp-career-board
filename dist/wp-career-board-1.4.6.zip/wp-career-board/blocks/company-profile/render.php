<?php
/**
 * Block render: wcb/company-profile — LinkedIn-style public company profile page.
 *
 * WordPress injects:
 *   $attributes  (array)    Block attributes defined in block.json.
 *   $content     (string)   Inner block content (empty for this block).
 *   $block       (WP_Block) Block instance object.
 *
 * @package WP_Career_Board
 * @since   1.0.0
 */

declare( strict_types=1 );

defined( 'ABSPATH' ) || exit;

// ── Resolve company post ──────────────────────────────────────────────────────
$wcb_company_id = (int) ( $attributes['companyId'] ?? 0 );
if ( ! $wcb_company_id ) {
	$wcb_queried = get_queried_object();
	if ( $wcb_queried instanceof \WP_Post && 'wcb_company' === $wcb_queried->post_type ) {
		$wcb_company_id = $wcb_queried->ID;
	}
}

$wcb_company = $wcb_company_id ? get_post( $wcb_company_id ) : null;
if ( ! $wcb_company instanceof \WP_Post ) {
	return;
}

// ── Meta fields ───────────────────────────────────────────────────────────────
$wcb_name     = $wcb_company->post_title;
$wcb_desc     = $wcb_company->post_content;
$wcb_tagline  = (string) get_post_meta( $wcb_company_id, '_wcb_tagline', true );
$wcb_website  = (string) get_post_meta( $wcb_company_id, '_wcb_website', true );
$wcb_linkedin = (string) get_post_meta( $wcb_company_id, '_wcb_linkedin', true );
$wcb_twitter  = (string) get_post_meta( $wcb_company_id, '_wcb_twitter', true );
$wcb_industry = \WCB\Core\Industries::label( (string) get_post_meta( $wcb_company_id, '_wcb_industry', true ) );
$wcb_size     = (string) get_post_meta( $wcb_company_id, '_wcb_company_size', true );
$wcb_type     = (string) get_post_meta( $wcb_company_id, '_wcb_company_type', true );
$wcb_founded  = (string) get_post_meta( $wcb_company_id, '_wcb_founded', true );
$wcb_hq       = (string) get_post_meta( $wcb_company_id, '_wcb_hq_location', true );
$wcb_trust    = (string) get_post_meta( $wcb_company_id, '_wcb_trust_level', true );
$wcb_logo_url = (string) get_the_post_thumbnail_url( $wcb_company_id, 'medium' );
$wcb_is_owner = get_current_user_id() === (int) $wcb_company->post_author;

// ── Initials avatar ───────────────────────────────────────────────────────────
$wcb_words    = array_filter( explode( ' ', trim( $wcb_name ) ) );
$wcb_initials = '';
foreach ( array_slice( $wcb_words, 0, 2 ) as $wcb_word ) {
	$wcb_initials .= mb_strtoupper( mb_substr( $wcb_word, 0, 1 ) );
}
$wcb_initials = $wcb_initials ? $wcb_initials : '?';

// ── Trust badge ───────────────────────────────────────────────────────────────
$wcb_trust_map  = array(
	'verified' => array(
		'label' => __( 'Verified', 'wp-career-board' ),
		'class' => 'wcb-trust--verified',
	),
	'trusted'  => array(
		'label' => __( 'Trusted', 'wp-career-board' ),
		'class' => 'wcb-trust--trusted',
	),
	'premium'  => array(
		'label' => __( 'Premium', 'wp-career-board' ),
		'class' => 'wcb-trust--premium',
	),
);
$wcb_trust_info = $wcb_trust_map[ $wcb_trust ] ?? null;

// ── Size labels ───────────────────────────────────────────────────────────────
$wcb_size_labels = array(
	'1-10'      => __( '1-10 employees', 'wp-career-board' ),
	'11-50'     => __( '11-50 employees', 'wp-career-board' ),
	'51-200'    => __( '51-200 employees', 'wp-career-board' ),
	'201-500'   => __( '201-500 employees', 'wp-career-board' ),
	'501-1000'  => __( '501-1,000 employees', 'wp-career-board' ),
	'1001-5000' => __( '1,001-5,000 employees', 'wp-career-board' ),
	'5000+'     => __( '5,000+ employees', 'wp-career-board' ),
);
$wcb_size_label  = $wcb_size_labels[ $wcb_size ] ?? $wcb_size;

// ── Bookmark state ───────────────────────────────────────────────────────────
// Mirrors the archive-card bookmark + Find Jobs single hero so a customer who
// follows a company from /companies/ sees the same Saved state when they land
// on the company profile from a search engine result.
$wcb_current_user_id   = get_current_user_id();
$wcb_company_bookmarks = $wcb_current_user_id
	? array_map( 'intval', (array) get_user_meta( $wcb_current_user_id, '_wcb_company_bookmark', false ) )
	: array();
$wcb_cp_is_bookmarked  = in_array( $wcb_company_id, $wcb_company_bookmarks, true );
$wcb_cp_bookmark_label = $wcb_cp_is_bookmarked
	? __( 'Saved', 'wp-career-board' )
	: __( 'Save', 'wp-career-board' );

wp_interactivity_state(
	'wcb-company-profile',
	array(
		'companyId'     => $wcb_company_id,
		'bookmarked'    => $wcb_cp_is_bookmarked,
		'bookmarking'   => false,
		'bookmarkLabel' => $wcb_cp_bookmark_label,
		'apiBase'       => untrailingslashit( rest_url( 'wcb/v1/companies' ) ),
		'restNonce'     => wp_create_nonce( 'wp_rest' ),
		'labelSave'     => __( 'Save', 'wp-career-board' ),
		'labelSaved'    => __( 'Saved', 'wp-career-board' ),
	)
);

?>
<div
	<?php echo get_block_wrapper_attributes( array( 'class' => 'wcb-company-profile wcb-cp-wrap' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
	data-wp-interactive="wcb-company-profile"
>

	<?php /* ── Hero ── */ ?>
	<div class="wcb-cp-hero">
		<div class="wcb-cp-cover" aria-hidden="true"></div>

		<?php
		/*
		 * Save button anchored top-right of the hero card, matching Find Jobs
		 * single hero placement. Out of the inline action row so it stays
		 * visually paired with the page corner instead of fighting Website /
		 * LinkedIn pills below the meta.
		 */
		?>
		<?php if ( is_user_logged_in() ) : ?>
			<button
				type="button"
				class="wcb-bookmark-hero-btn wcb-cp-hero-save"
				data-wp-on--click="actions.toggleBookmark"
				data-wp-class--wcb-bookmarked="state.bookmarked"
				data-wp-bind--disabled="state.bookmarking"
				data-wp-bind--aria-label="state.bookmarkLabel"
				aria-label="<?php echo esc_attr( $wcb_cp_bookmark_label ); ?>"
				title="<?php esc_attr_e( 'Save this company', 'wp-career-board' ); ?>"
			>
				<?php echo \WCB\Core\Icon::svg( 'bookmark' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- pre-escaped inside helper. ?>
				<span data-wp-text="state.bookmarkLabel"><?php echo esc_html( $wcb_cp_bookmark_label ); ?></span>
			</button>
		<?php endif; ?>

		<div class="wcb-cp-hero-body">
			<?php /* Avatar / Logo */ ?>
			<div class="wcb-cp-avatar-wrap">
				<?php if ( $wcb_logo_url ) : ?>
					<img class="wcb-cp-logo" src="<?php echo esc_url( $wcb_logo_url ); ?>" alt="<?php echo esc_attr( $wcb_name ); ?>" />
				<?php else : ?>
					<div class="wcb-cp-avatar" aria-hidden="true">
						<?php echo esc_html( $wcb_initials ); ?>
					</div>
				<?php endif; ?>
			</div>

			<div class="wcb-cp-hero-info">
				<div class="wcb-cp-name-row">
					<h1 class="wcb-cp-name"><?php echo esc_html( $wcb_name ); ?></h1>
					<?php if ( $wcb_trust_info ) : ?>
						<span class="wcb-cp-trust-badge <?php echo esc_attr( $wcb_trust_info['class'] ); ?>" role="status">
							<?php if ( 'premium' === $wcb_trust ) : ?>
								<?php echo \WCB\Core\Icon::svg( 'star' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- pre-escaped inside helper. ?>
							<?php else : ?>
								<?php echo \WCB\Core\Icon::svg( 'check' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- pre-escaped inside helper. ?>
							<?php endif; ?>
							<?php echo esc_html( $wcb_trust_info['label'] ); ?>
						</span>
					<?php endif; ?>
				</div>

				<?php if ( $wcb_tagline ) : ?>
					<p class="wcb-cp-tagline"><?php echo esc_html( $wcb_tagline ); ?></p>
				<?php endif; ?>

				<?php /* Quick meta chips */ ?>
				<div class="wcb-cp-meta-chips">
					<?php if ( $wcb_industry ) : ?>
						<span class="wcb-cp-chip">
							<?php echo \WCB\Core\Icon::svg( 'briefcase' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- pre-escaped inside helper. ?>
							<?php echo esc_html( $wcb_industry ); ?>
						</span>
					<?php endif; ?>
					<?php if ( $wcb_size_label ) : ?>
						<span class="wcb-cp-chip">
							<?php echo \WCB\Core\Icon::svg( 'users' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- pre-escaped inside helper. ?>
							<?php echo esc_html( $wcb_size_label ); ?>
						</span>
					<?php endif; ?>
					<?php if ( $wcb_hq ) : ?>
						<span class="wcb-cp-chip">
							<?php echo \WCB\Core\Icon::svg( 'map-pin' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- pre-escaped inside helper. ?>
							<?php echo esc_html( $wcb_hq ); ?>
						</span>
					<?php endif; ?>
				</div>

				<?php
				/*
				 * External links + Save affordance.
				 * Save button matches Find Jobs single hero so a customer who
				 * follows companies from /companies/ archive cards has the
				 * same Save button on the profile page. Wires to the same
				 * /wcb/v1/companies/{id}/bookmark REST route the archive cards.
				 */
				?>
				<div class="wcb-cp-links">
					<?php if ( $wcb_website ) : ?>
						<a class="wcb-cp-link wcb-cp-link--web" href="<?php echo esc_url( $wcb_website ); ?>" target="_blank" rel="noopener noreferrer">
							<?php echo \WCB\Core\Icon::svg( 'globe' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- pre-escaped inside helper. ?>
							<?php esc_html_e( 'Website', 'wp-career-board' ); ?>
						</a>
					<?php endif; ?>
					<?php if ( $wcb_linkedin ) : ?>
						<a class="wcb-cp-link wcb-cp-link--linkedin" href="<?php echo esc_url( $wcb_linkedin ); ?>" target="_blank" rel="noopener noreferrer">
							<?php echo \WCB\Core\Icon::svg( 'linkedin' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- pre-escaped inside helper. ?>
							<?php esc_html_e( 'LinkedIn', 'wp-career-board' ); ?>
						</a>
					<?php endif; ?>
					<?php if ( $wcb_twitter ) : ?>
						<a class="wcb-cp-link wcb-cp-link--twitter" href="<?php echo esc_url( $wcb_twitter ); ?>" target="_blank" rel="noopener noreferrer">
							<?php echo \WCB\Core\Icon::svg( 'twitter' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- pre-escaped inside helper. ?>
							<?php esc_html_e( 'X / Twitter', 'wp-career-board' ); ?>
						</a>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</div>

	<?php /* ── Body (2-col on desktop: main + sidebar) ── */ ?>
	<div class="wcb-cp-body">

	<div class="wcb-cp-main">

		<?php /* About */ ?>
		<?php if ( $wcb_desc ) : ?>
			<section class="wcb-cp-section">
				<h2 class="wcb-cp-section-title"><?php esc_html_e( 'About', 'wp-career-board' ); ?></h2>
				<div class="wcb-cp-desc">
					<?php echo wp_kses_post( wpautop( $wcb_desc ) ); ?>
				</div>
			</section>
		<?php endif; ?>

		<?php /* Company Details */ ?>
		<?php if ( $wcb_industry || $wcb_size || $wcb_type || $wcb_founded || $wcb_hq || $wcb_website ) : ?>
			<section class="wcb-cp-section">
				<h2 class="wcb-cp-section-title"><?php esc_html_e( 'Company Details', 'wp-career-board' ); ?></h2>
				<dl class="wcb-cp-details-grid">
					<?php if ( $wcb_industry ) : ?>
						<div class="wcb-cp-detail-item">
							<dt><?php esc_html_e( 'Industry', 'wp-career-board' ); ?></dt>
							<dd><?php echo esc_html( $wcb_industry ); ?></dd>
						</div>
					<?php endif; ?>
					<?php if ( $wcb_size_label ) : ?>
						<div class="wcb-cp-detail-item">
							<dt><?php esc_html_e( 'Company size', 'wp-career-board' ); ?></dt>
							<dd><?php echo esc_html( $wcb_size_label ); ?></dd>
						</div>
					<?php endif; ?>
					<?php if ( $wcb_type ) : ?>
						<div class="wcb-cp-detail-item">
							<dt><?php esc_html_e( 'Type', 'wp-career-board' ); ?></dt>
							<dd><?php echo esc_html( $wcb_type ); ?></dd>
						</div>
					<?php endif; ?>
					<?php if ( $wcb_founded ) : ?>
						<div class="wcb-cp-detail-item">
							<dt><?php esc_html_e( 'Founded', 'wp-career-board' ); ?></dt>
							<dd><?php echo esc_html( $wcb_founded ); ?></dd>
						</div>
					<?php endif; ?>
					<?php if ( $wcb_hq ) : ?>
						<div class="wcb-cp-detail-item">
							<dt><?php esc_html_e( 'Headquarters', 'wp-career-board' ); ?></dt>
							<dd><?php echo esc_html( $wcb_hq ); ?></dd>
						</div>
					<?php endif; ?>
					<?php if ( $wcb_website ) : ?>
						<div class="wcb-cp-detail-item">
							<dt><?php esc_html_e( 'Website', 'wp-career-board' ); ?></dt>
							<dd>
								<a href="<?php echo esc_url( $wcb_website ); ?>" target="_blank" rel="noopener noreferrer">
									<?php echo esc_html( preg_replace( '#^https?://#', '', rtrim( $wcb_website, '/' ) ) ); ?>
								</a>
							</dd>
						</div>
					<?php endif; ?>
				</dl>
			</section>
		<?php endif; ?>

		<?php
		/* ── Open Positions — Interactivity API (paginated) ── */
		$wcb_cp_per_page  = 10;
		$wcb_cp_author_id = (int) $wcb_company->post_author;

		$wcb_open_jobs = get_posts(
			array(
				'post_type'     => 'wcb_job',
				'post_status'   => 'publish',
				'numberposts'   => $wcb_cp_per_page,
				'no_found_rows' => true,
				'meta_query'    => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
					array(
						'key'   => '_wcb_company_id',
						'value' => $wcb_company->ID,
					),
				),
			)
		);

		$wcb_cp_jobs_state = array();
		foreach ( $wcb_open_jobs as $wcb_jpost ) {
			$wcb_jloc            = wp_get_object_terms( $wcb_jpost->ID, 'wcb_location', array( 'fields' => 'names' ) );
			$wcb_jtype           = wp_get_object_terms( $wcb_jpost->ID, 'wcb_job_type', array( 'fields' => 'names' ) );
			$wcb_cp_jobs_state[] = array(
				'id'        => $wcb_jpost->ID,
				'title'     => $wcb_jpost->post_title,
				'permalink' => (string) get_permalink( $wcb_jpost->ID ),
				'type'      => is_wp_error( $wcb_jtype ) ? '' : implode( ', ', $wcb_jtype ),
				'location'  => is_wp_error( $wcb_jloc ) ? '' : implode( ', ', $wcb_jloc ),
			);
		}

		wp_interactivity_state(
			'wcb-company-profile',
			array(
				'jobs'      => $wcb_cp_jobs_state,
				'page'      => 1,
				'perPage'   => $wcb_cp_per_page,
				'author'    => $wcb_cp_author_id,
				'loading'   => false,
				'hasMore'   => count( $wcb_open_jobs ) >= $wcb_cp_per_page,
				'hasNoJobs' => empty( $wcb_cp_jobs_state ),
				// Distinct key from the companies `apiBase` set above — both calls
				// merge into the same store, so reusing `apiBase` here clobbered the
				// bookmark route (company save POSTed to /jobs/{id}/bookmark).
				'jobsApiBase' => untrailingslashit( rest_url( 'wcb/v1/jobs' ) ),
			)
		);
		?>
		<section class="wcb-cp-section">
			<h2 class="wcb-cp-section-title"><?php esc_html_e( 'Open Positions', 'wp-career-board' ); ?></h2>

			<p class="wcb-cp-no-jobs" data-wp-bind--hidden="!state.hasNoJobs">
				<?php esc_html_e( 'No open positions at the moment. Check back soon.', 'wp-career-board' ); ?>
			</p>

			<div class="wcb-cp-jobs-list">
				<template data-wp-each--job="state.jobs" data-wp-each-key="context.job.id">
					<article class="wcb-cp-job-card">
						<div class="wcb-cp-job-main">
							<h3 class="wcb-cp-job-title">
								<a aria-label="<?php esc_attr_e( 'Job listing', 'wp-career-board' ); ?>" data-wp-bind--href="context.job.permalink" data-wp-bind--aria-label="context.job.title" data-wp-text="context.job.title"></a>
							</h3>
							<div class="wcb-cp-job-badges">
								<span class="wcb-cjbadge wcb-cjbadge--type" data-wp-class--wcb-shown="context.job.type" data-wp-text="context.job.type"></span>
								<span class="wcb-cjbadge wcb-cjbadge--location" data-wp-class--wcb-shown="context.job.location">
									<?php echo \WCB\Core\Icon::svg( 'map-pin' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- pre-escaped inside helper. ?>
									<span data-wp-text="context.job.location"></span>
								</span>
							</div>
						</div>
						<a class="wcb-cp-job-apply" data-wp-bind--href="context.job.permalink"><?php esc_html_e( 'View Job', 'wp-career-board' ); ?></a>
					</article>
				</template>
			</div>

			<div class="wcb-load-more-wrap" data-wp-class--wcb-shown="state.hasMore">
				<button
					type="button"
					class="wcb-cbtn wcb-cbtn--ghost wcb-load-more-btn"
					data-wp-on--click="actions.loadMore"
					data-wp-bind--disabled="state.loading"
				>
					<span data-wp-class--wcb-hidden="state.loading"><?php esc_html_e( 'Load more jobs', 'wp-career-board' ); ?></span>
					<span class="wcb-load-more-loading" data-wp-class--wcb-shown="state.loading"><?php esc_html_e( 'Loading&hellip;', 'wp-career-board' ); ?></span>
				</button>
			</div>

		</section>

	</div>

	<?php
	/*
	Sidebar: always renders the same three plugin blocks for shape
	 * consistency. The previous behavior swapped in admin-placed widgets
	 * from a `wcb-company-sidebar` widget area when any were assigned,
	 * but admins routinely misassigned footer / generic widgets there
	 * and the company sidebar ended up showing white-on-white footer
	 * columns.
	 *
	 * Extensibility hooks (use these instead of the retired widget area):
	 *
	 *   do_action( 'wcb_company_sidebar_before', int $company_id )
	 *   do_action( 'wcb_company_sidebar_after',  int $company_id )
	 *     - Echo any markup; runs inside `<aside class="wcb-cp-sidebar">`
	 *       before or after the three default cards.
	 *
	 *   apply_filters( 'wcb_company_sidebar_blocks', array $blocks, int $company_id )
	 *     - Replace, reorder, or append to the default three blocks.
	 *       Each entry is a Gutenberg block-comment string passed to
	 *       `do_blocks()`. Return an empty array to render nothing.
	 */
	$wcb_cp_sidebar_blocks = (array) apply_filters(
		'wcb_company_sidebar_blocks',
		array(
			'<!-- wp:wp-career-board/similar-companies-card /-->',
			'<!-- wp:wp-career-board/recent-jobs {"count":5,"showViewAll":true} /-->',
			'<!-- wp:wp-career-board/job-alert-card /-->',
		),
		(int) $wcb_company_id
	);
	?>
	<aside class="wcb-cp-sidebar" aria-label="<?php esc_attr_e( 'Company profile sidebar', 'wp-career-board' ); ?>">
		<?php
		do_action( 'wcb_company_sidebar_before', (int) $wcb_company_id );

		foreach ( $wcb_cp_sidebar_blocks as $wcb_cp_sidebar_block ) {
			// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- do_blocks returns pre-escaped HTML.
			echo do_blocks( (string) $wcb_cp_sidebar_block );
		}

		do_action( 'wcb_company_sidebar_after', (int) $wcb_company_id );
		?>
	</aside>

	</div>

</div>
