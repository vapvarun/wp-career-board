<?php
/**
 * Block render: wcb/candidate-dashboard — sidebar layout candidate interface.
 *
 * WordPress injects:
 *   $attributes  (array)    Block attributes defined in block.json.
 *   $content     (string)   Inner block content (empty for this block).
 *   $block       (WP_Block) Block instance object.
 *
 * @package WP_Career_Board
 * @since   1.0.0
 */

declare( strict_types=1 );

defined( 'ABSPATH' ) || exit;

if ( ! is_user_logged_in() ) {
	?>
	<div class="wcb-db-gate">
		<p><?php esc_html_e( 'Please sign in to access your candidate dashboard.', 'wp-career-board' ); ?></p>
		<a href="<?php echo esc_url( wp_login_url( (string) get_permalink() ) ); ?>" class="wcb-db-btn wcb-db-btn--primary">
	<?php esc_html_e( 'Sign In', 'wp-career-board' ); ?>
		</a>
	</div>
	<?php
	return;
}

$wcb_can_access_candidate_dashboard = wp_is_ability_granted( 'wcb/access-candidate-dashboard' );

if ( ! $wcb_can_access_candidate_dashboard ) {
	echo '<p>' . esc_html__( 'You do not have permission to view this dashboard.', 'wp-career-board' ) . '</p>';
	return;
}

// Shared confirm-modal — used by withdrawApplication() and deleteResume() in view.js.
wp_enqueue_style( 'wcb-confirm-modal' );
wp_enqueue_script( 'wcb-confirm-modal' );

$wcb_candidate_id = get_current_user_id();
$wcb_current_user = wp_get_current_user();
$wcb_display_name = $wcb_current_user->display_name;

$wcb_jobs_page_id   = \WCB\Admin\Settings::int( 'jobs_archive_page', 0 );
$wcb_jobs_permalink = $wcb_jobs_page_id > 0 ? get_permalink( $wcb_jobs_page_id ) : false;
$wcb_jobs_url       = ( false !== $wcb_jobs_permalink && '' !== $wcb_jobs_permalink )
	? (string) $wcb_jobs_permalink
	: home_url( '/' );

// Pro signals its notifications module through the wcb_module_renders slot; when
// present, the dashboard shows a Notifications item in the ACCOUNT nav whose panel
// renders that markup (trusted plugin Interactivity HTML — emitted as-is below,
// since wp_kses_post would strip the <template>/data-wp-each loop).
$wcb_module_renders = (array) apply_filters( 'wcb_module_renders', array() );
$wcb_bell_enabled   = ! empty( $wcb_module_renders['notifications_bell'] );

// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only param, no state mutation.
$wcb_resume_embed_id         = absint( wp_unslash( $_GET['resume_id'] ?? '0' ) );
$wcb_resume_builder_embedded = WP_Block_Type_Registry::get_instance()->is_registered( 'wcb/resume-builder' );
$wcb_dashboard_url           = (string) get_permalink();

// Public-resume permalink for the sidebar shortcut. Mirrors Employer's
// "Public Page ↗" link so a candidate can preview the version of their
// resume an employer sees. We pick the most recently updated published
// resume the candidate owns; if none exists, the link stays hidden.
$wcb_public_resume_url = '';
if ( post_type_exists( 'wcb_resume' ) ) {
	$wcb_public_resumes = get_posts(
		array(
			'post_type'      => 'wcb_resume',
			'author'         => $wcb_candidate_id,
			'post_status'    => 'publish',
			'meta_key'       => '_wcb_resume_public', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
			'meta_value'     => '1', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
			'orderby'        => 'modified',
			'order'          => 'DESC',
			'posts_per_page' => 1,
			'fields'         => 'ids',
		)
	);
	if ( ! empty( $wcb_public_resumes ) ) {
		$wcb_public_resume_url = (string) get_permalink( (int) $wcb_public_resumes[0] );
	}
}

/**
 * Filter extra state keys for the candidate dashboard resumes tab.
 *
 * Pro uses this to inject maxResumes and resumeCount for cap enforcement.
 *
 * @since 1.0.0
 * @param array<string,mixed> $state   Default state with maxResumes=0, resumeCount=0.
 * @param int                 $user_id Current candidate user ID.
 */
$wcb_saved_jobs_count = (int) count( (array) get_user_meta( $wcb_candidate_id, '_wcb_bookmark', false ) );

$wcb_resumes_state = (array) apply_filters(
	'wcb_candidate_resumes_state',
	array(
		'maxResumes'  => 0,
		'resumeCount' => 0,
	),
	$wcb_candidate_id
);

wp_interactivity_state(
	'wcb-candidate-dashboard',
	array_merge(
		array(
			'strings'                 => array(
				'tabOverview'          => __( 'Overview', 'wp-career-board' ),
				'tabApplications'      => __( 'My Applications', 'wp-career-board' ),
				'tabBookmarks'         => __( 'Saved Jobs', 'wp-career-board' ),
				'tabResumes'           => __( 'My Resumes', 'wp-career-board' ),
				'tabAlerts'            => __( 'Job Alerts', 'wp-career-board' ),
				'tabResumeBuilder'     => __( 'Edit Resume', 'wp-career-board' ),
				'tabDashboard'         => __( 'Dashboard', 'wp-career-board' ),
				'tabProfile'           => __( 'Profile', 'wp-career-board' ),
				'tabSettings'          => __( 'Settings', 'wp-career-board' ),
				'resumesUnit'          => __( 'resumes', 'wp-career-board' ),
				'filterRemote'         => __( 'Remote', 'wp-career-board' ),
				'alertLabelAllJobs'    => __( 'All jobs', 'wp-career-board' ),
				'errLoadApplications'  => __( 'Could not load your applications.', 'wp-career-board' ),
				'errLoadBookmarks'     => __( 'Could not load saved jobs.', 'wp-career-board' ),
				'errLoadResumes'       => __( 'Could not load your resumes.', 'wp-career-board' ),
				'errLoadAlerts'        => __( 'Could not load your alerts.', 'wp-career-board' ),
				'errRemoveBookmark'    => __( 'Could not remove saved job. Please try again.', 'wp-career-board' ),
				'errCreateResume'      => __( 'Could not create resume. Please try again.', 'wp-career-board' ),
				'errDeleteResume'      => __( 'Could not delete resume. Please try again.', 'wp-career-board' ),
				'errConnectionFull'    => __( 'Connection error. Please check your network and try again.', 'wp-career-board' ),
				'errConnectionShort'   => __( 'Connection error.', 'wp-career-board' ),
				'confirmWithdrawTitle' => __( 'Withdraw application?', 'wp-career-board' ),
				'confirmWithdrawMsg'   => __( 'Are you sure you want to withdraw this application? This cannot be undone.', 'wp-career-board' ),
				'withdraw'             => __( 'Withdraw', 'wp-career-board' ),
				'confirmClearAllTitle' => __( 'Clear all notifications?', 'wp-career-board' ),
				'confirmClearAllMsg'   => __( 'This permanently removes all of your notifications. This cannot be undone.', 'wp-career-board' ),
				'clearAll'             => __( 'Clear all', 'wp-career-board' ),
				'errWithdraw'          => __( 'Could not withdraw application. Please try again.', 'wp-career-board' ),
				'confirmEraseTitle'    => __( 'Delete your account?', 'wp-career-board' ),
				'confirmEraseMsg'      => __( 'We\'ll send a confirmation email to your registered address. After you click the link in the email, the site administrator will permanently delete your applications, resumes, and account. This cannot be undone.', 'wp-career-board' ),
				'confirmEraseConfirm'  => __( 'Send confirmation email', 'wp-career-board' ),
				'errPrivacy'           => __( 'Could not submit your privacy request. Please try again or contact support.', 'wp-career-board' ),
				'recommendedTitle'     => __( 'Recommended for you', 'wp-career-board' ),
				'recommendedHint'      => __( 'AI-matched to your resume', 'wp-career-board' ),
			),
			'tab'                     => $wcb_resume_embed_id > 0 && $wcb_resume_builder_embedded ? 'resume-builder' : 'overview',
			'savedJobsCount'          => $wcb_saved_jobs_count,
			'applications'            => array(),
			'bookmarks'               => array(),
			'savedCompanies'          => array(),
			'savedCompaniesLoading'   => false,
			'savedCompaniesError'     => '',
			'savedCompaniesCountSeed' => (int) count( (array) get_user_meta( $wcb_candidate_id, '_wcb_company_bookmark', false ) ),
			'savedResumes'            => array(),
			'savedResumesLoading'     => false,
			'savedResumesError'       => '',
			'savedResumesCountSeed'   => post_type_exists( 'wcb_resume' )
				? (int) count( (array) get_user_meta( $wcb_candidate_id, '_wcb_resume_bookmark', false ) )
				: 0,
			'resumes'                 => array(),
			'loading'                 => false,
			'error'                   => '',
			'apiBase'                 => untrailingslashit( rest_url( 'wcb/v1' ) ),
			'nonce'                   => wp_create_nonce( 'wp_rest' ),
			'candidateId'             => $wcb_candidate_id,
			'candidateName'           => $wcb_display_name,
			'currentUserId'           => get_current_user_id(),
			'aiMatching'              => (bool) apply_filters( 'wcb_ai_matching_available', false ), // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound
			'recommendations'         => array(),
			'recsLoading'             => false,
			// `resumesEnabled` is true when Pro's Resumes module is loaded
			// (regardless of whether the customer has dropped a wcb/resume-builder
			// block). On Free-only installs, the My Resumes tab and the
			// `/wcb/v1/candidates/{id}/resumes` REST call are both Pro-only —
			// gating here prevents the "Could not load your resumes." 402 error
			// surfaced in the candidate-dashboard audit on 2026-05-06.
			'resumesEnabled'          => (bool) apply_filters( 'wcb_pro_resumes_enabled', false ) || $wcb_resume_builder_embedded,
			'dashboardUrl'            => $wcb_dashboard_url,
			'resumeBuilderEmbedded'   => $wcb_resume_builder_embedded,
			'resumeEmbedId'           => $wcb_resume_embed_id,
			'showNewResumeForm'       => false,
			'newResumeTitle'          => '',
			'customFieldGroups'       => apply_filters( 'wcb_candidate_form_fields', array(), $wcb_candidate_id ),
			'customFields'            => (object) (
				$wcb_candidate_id > 0
					? \WCB\Core\FormCustomFields::load_values(
						(array) apply_filters( 'wcb_candidate_form_fields', array(), $wcb_candidate_id ),
						$wcb_candidate_id,
						'user_meta'
					)
					: array()
			),
			'profileBio'              => get_the_author_meta( 'description', $wcb_candidate_id ),
			'profileEmail'            => $wcb_current_user->user_email,
			// Account Settings panel — editable display name + email + password.
			'accountName'             => $wcb_current_user->display_name,
			'accountEmail'            => $wcb_current_user->user_email,
			'curPassword'             => '',
			'newPassword'             => '',
			'confPassword'            => '',
			'accountMsg'              => '',
			'accountMsgType'          => '',
			'accountSaving'           => false,
			'pwMsg'                   => '',
			'pwMsgType'               => '',
			'pwSaving'                => false,
			// Phone + Location surfaced from the structured `_wcb_resume_data`
			// user meta so the candidate profile UI matches the contact info
			// rendered in resume-single + Pro's resume PDF download.
			'profilePhone'            => (string) (
				static function () use ( $wcb_candidate_id ): string {
					$wcb_rd = get_user_meta( $wcb_candidate_id, '_wcb_resume_data', true );
					return is_array( $wcb_rd ) ? (string) ( $wcb_rd['phone'] ?? '' ) : '';
				}
			)(),
			'profileLocation'         => (string) (
				static function () use ( $wcb_candidate_id ): string {
					$wcb_rd = get_user_meta( $wcb_candidate_id, '_wcb_resume_data', true );
					if ( is_array( $wcb_rd ) && ! empty( $wcb_rd['location'] ) ) {
						return (string) $wcb_rd['location'];
					}
					return (string) get_user_meta( $wcb_candidate_id, '_wcb_location', true );
				}
			)(),
			'profileSaving'           => false,
			'profileSaved'            => false,
			'passwordResetUrl'        => wp_lostpassword_url( $wcb_dashboard_url ),
			'bellNotifications'       => array(),
			'bellUnreadCount'         => 0,
			'bellLoading'             => false,
			'bellEnabled'             => $wcb_bell_enabled,
			'alerts'                  => array(),
			'alertsLoading'           => false,
			// Withdraw is gated by BOTH the site setting and the user ability —
			// admins disable the setting on sites that want apply-once-final
			// flows. Intended default is ON: a fresh install (no saved value)
			// lets candidates withdraw, mirroring the REST gate's default.
			'allowWithdraw'           => (
				static function (): bool {
					if ( ! \WCB\Admin\Settings::bool( 'allow_withdraw', true ) ) {
						return false;
					}
					return wp_is_ability_granted( 'wcb/withdraw-application' );
				}
			)(),
			'privacyBusy'             => false,
			'privacyExportRequested'  => false,
			'privacyEraseRequested'   => false,
			'privacyError'            => '',
			// Site-default currency symbol — surfaced to the saved-search filter
			// pill labels in view.js so dashboards on INR / EUR / etc. don't show
			// a hardcoded $ on the alert summary.
			'currencySymbol'          => (
				static function (): string {
					$wcb_default = \WCB\Admin\Settings::string( 'salary_currency', 'USD' );
					$wcb_catalog = \WCB\Admin\AdminSettings::get_currency_catalog();
					return isset( $wcb_catalog[ $wcb_default ]['symbol'] )
						? (string) $wcb_catalog[ $wcb_default ]['symbol']
						: '$';
				}
			)(),
		),
		$wcb_resumes_state
	)
);
?>
<div
	<?php echo get_block_wrapper_attributes( array( 'class' => 'wcb-dashboard' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
	data-wp-interactive="wcb-candidate-dashboard"
	data-wp-init="actions.init"
>

<div class="wcb-dashboard-shell">

	<!-- SIDEBAR -->
	<aside class="wcb-sidebar" data-wp-class--wcb-nav-open="state.navOpen">
		<button type="button" class="wcb-nav-toggle"
			aria-label="<?php esc_attr_e( 'Toggle navigation', 'wp-career-board' ); ?>"
			data-wp-on--click="actions.toggleNav"
			data-wp-bind--aria-expanded="state.navOpen">
			<span data-wp-text="state.activeTabLabel"><?php esc_html_e( 'Dashboard', 'wp-career-board' ); ?></span>
			<span class="wcb-nav-toggle-icon" aria-hidden="true"></span>
		</button>
		<button type="button" class="wcb-sidebar-logo"
			data-wp-on--click="actions.switchToOverview"
			data-wp-class--wcb-nav-active="state.isTabOverview">
			<?php esc_html_e( 'Dashboard', 'wp-career-board' ); ?>
		</button>

		<nav class="wcb-sidebar-nav" role="tablist" aria-label="<?php esc_attr_e( 'Candidate dashboard navigation', 'wp-career-board' ); ?>">
			<span class="wcb-nav-section-label"><?php esc_html_e( 'MY ACTIVITY', 'wp-career-board' ); ?></span>
			<button type="button" class="wcb-nav-item" role="tab" data-wp-bind--aria-selected="state.isTabApplications" data-wp-class--wcb-nav-active="state.isTabApplications" data-wp-on--click="actions.switchToApplications" id="wcb-tab-applications">
				<?php esc_html_e( 'My Applications', 'wp-career-board' ); ?>
				<span class="wcb-nav-badge wcb-nav-badge--blue" data-wp-text="state.appsCount">0</span>
			</button>
			<button
				type="button"
				class="wcb-nav-item"
				role="tab"
				id="wcb-tab-resumes"
				data-wp-bind--aria-selected="state.isTabResumes"
				data-wp-class--wcb-nav-active="state.isTabResumes"
				data-wp-on--click="actions.switchToResumes"
				data-wp-bind--hidden="!state.resumesEnabled"
				<?php
				if ( ! $wcb_resume_builder_embedded ) :
					?>
					hidden
					<?php
				endif;
				?>
			><?php esc_html_e( 'My Resumes', 'wp-career-board' ); ?></button>
			<?php if ( '' !== $wcb_public_resume_url ) : ?>
			<a
				class="wcb-nav-item wcb-nav-item--link"
				href="<?php echo esc_url( $wcb_public_resume_url ); ?>"
				target="_blank"
				rel="noopener noreferrer"
			>
				<?php esc_html_e( 'Public Resume', 'wp-career-board' ); ?> &#8599;
			</a>
			<?php endif; ?>
			<?php if ( $wcb_resume_builder_embedded ) : ?>
			<button
				type="button"
				class="wcb-nav-item"
				data-wp-class--wcb-nav-active="state.isTabResumeBuilder"
				data-wp-on--click="actions.switchToResumeBuilder"
				<?php echo $wcb_resume_embed_id > 0 ? '' : 'hidden'; ?>
				data-wp-bind--hidden="!state.resumeEmbedId"
			><?php esc_html_e( 'Edit Resume', 'wp-career-board' ); ?></button>
			<?php endif; ?>
			<?php if ( apply_filters( 'wcb_pro_alerts_enabled', false ) ) : ?>
			<button type="button" class="wcb-nav-item" role="tab" id="wcb-tab-alerts"
				data-wp-bind--aria-selected="state.isTabAlerts"
				data-wp-class--wcb-nav-active="state.isTabAlerts"
				data-wp-on--click="actions.switchToAlerts">
				<?php esc_html_e( 'Job Alerts', 'wp-career-board' ); ?>
				<span class="wcb-nav-badge wcb-nav-badge--green" data-wp-text="state.alertsCount">0</span>
			</button>
			<?php endif; ?>

			<?php
			/*
			My Saves - jobs, companies, and resumes are bookmark-able
					by any logged-in user (REST gate is `is_user_logged_in()`).
					Grouping them here keeps the three lists separate so saved
					jobs don't mix with saved companies or saved candidate
					profiles. Saved Resumes hides itself when the wcb_resume
					CPT isn't registered (Free-only sites). */
			?>
			<span class="wcb-nav-section-label"><?php esc_html_e( 'MY SAVES', 'wp-career-board' ); ?></span>
			<button type="button" class="wcb-nav-item" role="tab" data-wp-bind--aria-selected="state.isTabBookmarks" data-wp-class--wcb-nav-active="state.isTabBookmarks" data-wp-on--click="actions.switchToBookmarks" id="wcb-tab-bookmarks">
				<?php esc_html_e( 'Saved Jobs', 'wp-career-board' ); ?>
				<span class="wcb-nav-badge" data-wp-text="state.bookmarksCount">0</span>
			</button>
			<button type="button" class="wcb-nav-item" role="tab" data-wp-bind--aria-selected="state.isTabSavedCompanies" data-wp-class--wcb-nav-active="state.isTabSavedCompanies" data-wp-on--click="actions.switchToSavedCompanies" id="wcb-tab-saved-companies">
				<?php esc_html_e( 'Saved Companies', 'wp-career-board' ); ?>
				<span class="wcb-nav-badge" data-wp-text="state.savedCompaniesCount">0</span>
			</button>
			<?php if ( post_type_exists( 'wcb_resume' ) ) : ?>
			<button type="button" class="wcb-nav-item" role="tab" data-wp-bind--aria-selected="state.isTabSavedResumes" data-wp-class--wcb-nav-active="state.isTabSavedResumes" data-wp-on--click="actions.switchToSavedResumes" id="wcb-tab-saved-resumes">
				<?php esc_html_e( 'Saved Resumes', 'wp-career-board' ); ?>
				<span class="wcb-nav-badge" data-wp-text="state.savedResumesCount">0</span>
			</button>
			<?php endif; ?>

			<span class="wcb-nav-section-label"><?php esc_html_e( 'ACCOUNT', 'wp-career-board' ); ?></span>
			<button type="button" class="wcb-nav-item" role="tab" id="wcb-tab-profile"
				data-wp-bind--aria-selected="state.isTabProfile"
				data-wp-class--wcb-nav-active="state.isTabProfile"
				data-wp-on--click="actions.switchToProfile">
				<?php esc_html_e( 'Profile', 'wp-career-board' ); ?>
			</button>
			<button type="button" class="wcb-nav-item" role="tab" id="wcb-tab-settings"
				data-wp-bind--aria-selected="state.isTabSettings"
				data-wp-class--wcb-nav-active="state.isTabSettings"
				data-wp-on--click="actions.switchToSettings">
				<?php esc_html_e( 'Settings', 'wp-career-board' ); ?>
			</button>
			<?php if ( $wcb_bell_enabled ) : ?>
			<button type="button" class="wcb-nav-item" role="tab" id="wcb-tab-notifications"
				data-wp-bind--aria-selected="state.isTabNotifications"
				data-wp-class--wcb-nav-active="state.isTabNotifications"
				data-wp-on--click="actions.switchToNotifications">
				<?php esc_html_e( 'Notifications', 'wp-career-board' ); ?>
				<span class="wcb-nav-badge" data-wp-class--wcb-hidden="!state.bellUnreadCount" data-wp-text="state.bellUnreadCount"></span>
			</button>
			<?php endif; ?>
		</nav>

		<a href="<?php echo esc_url( $wcb_jobs_url ); ?>" class="wcb-sidebar-cta">
			<?php esc_html_e( 'Browse Jobs', 'wp-career-board' ); ?> &#8599;
		</a>

		<div class="wcb-sidebar-user">
			<div class="wcb-sidebar-avatar" data-wp-text="state.candidateInitials" aria-hidden="true"></div>
			<span class="wcb-sidebar-company" data-wp-text="state.candidateName"></span>
		</div>
	</aside>

	<!-- MAIN CONTENT -->
	<main class="wcb-main">

		<!-- VIEW: Overview -->
		<div class="wcb-view-panel" role="tabpanel" data-wp-class--wcb-view-active="state.isTabOverview">
			<div class="wcb-page-header">
				<h1 class="wcb-page-title"><?php esc_html_e( 'Overview', 'wp-career-board' ); ?></h1>
			</div>

			<!-- ── Welcome card — only when applications=0 AND saved=0 AND resumes=0 ── -->
			<div class="wcb-welcome-card" data-wp-class--wcb-shown="state.isFirstTime">
				<div class="wcb-welcome-card__header">
					<h2 class="wcb-welcome-card__title">
						<?php
						printf(
							/* translators: %s: candidate's first name */
							esc_html__( 'Welcome, %s 👋', 'wp-career-board' ),
							esc_html( $wcb_current_user->first_name ? $wcb_current_user->first_name : $wcb_display_name )
						);
						?>
					</h2>
					<p class="wcb-welcome-card__subtitle"><?php esc_html_e( 'Here\'s how to get started:', 'wp-career-board' ); ?></p>
				</div>
				<div class="wcb-welcome-card__steps">
					<a href="<?php echo esc_url( $wcb_jobs_url ); ?>" class="wcb-welcome-step">
						<span class="wcb-welcome-step__num">1</span>
						<div class="wcb-welcome-step__body">
							<span class="wcb-welcome-step__title"><?php esc_html_e( 'Browse jobs', 'wp-career-board' ); ?></span>
							<span class="wcb-welcome-step__desc"><?php esc_html_e( 'Search and apply to roles that match your skills.', 'wp-career-board' ); ?></span>
						</div>
					</a>
					<?php if ( $wcb_resume_builder_embedded ) : ?>
					<button type="button" class="wcb-welcome-step" data-wp-on--click="actions.switchToResumes">
						<span class="wcb-welcome-step__num">2</span>
						<div class="wcb-welcome-step__body">
							<span class="wcb-welcome-step__title"><?php esc_html_e( 'Build your resume', 'wp-career-board' ); ?></span>
							<span class="wcb-welcome-step__desc"><?php esc_html_e( 'A complete profile gets noticed by employers faster.', 'wp-career-board' ); ?></span>
						</div>
					</button>
					<?php endif; ?>
					<?php if ( apply_filters( 'wcb_pro_alerts_enabled', false ) ) : ?>
					<button type="button" class="wcb-welcome-step" data-wp-on--click="actions.switchToAlerts">
						<span class="wcb-welcome-step__num">3</span>
						<div class="wcb-welcome-step__body">
							<span class="wcb-welcome-step__title"><?php esc_html_e( 'Set up job alerts', 'wp-career-board' ); ?></span>
							<span class="wcb-welcome-step__desc"><?php esc_html_e( 'Get notified when matching roles are posted.', 'wp-career-board' ); ?></span>
						</div>
					</button>
					<?php endif; ?>
				</div>
			</div>

			<div class="wcb-stats-row">
				<div class="wcb-stat-card">
					<span class="wcb-stat-value" data-wp-text="state.appsCount">0</span>
					<span class="wcb-stat-label"><?php esc_html_e( 'Applications', 'wp-career-board' ); ?></span>
				</div>
				<div class="wcb-stat-card wcb-stat-card--green">
					<span class="wcb-stat-value" data-wp-text="state.overviewShortlistedCount">0</span>
					<span class="wcb-stat-label"><?php esc_html_e( 'Shortlisted', 'wp-career-board' ); ?></span>
				</div>
				<div class="wcb-stat-card wcb-stat-card--blue">
					<span class="wcb-stat-value" data-wp-text="state.savedJobsCount"><?php echo esc_html( (string) $wcb_saved_jobs_count ); ?></span>
					<span class="wcb-stat-label"><?php esc_html_e( 'Saved Jobs', 'wp-career-board' ); ?></span>
				</div>
				<div class="wcb-stat-card wcb-stat-card--amber">
					<span class="wcb-stat-value" data-wp-text="state.resumeCount"><?php echo esc_html( (string) ( $wcb_resumes_state['resumeCount'] ?? 0 ) ); ?></span>
					<span class="wcb-stat-label"><?php esc_html_e( 'My Resumes', 'wp-career-board' ); ?></span>
				</div>
				<?php if ( apply_filters( 'wcb_pro_alerts_enabled', false ) ) : ?>
				<div class="wcb-stat-card wcb-stat-card--green" style="cursor:pointer" data-wp-on--click="actions.switchToAlerts">
					<span class="wcb-stat-value" data-wp-text="state.alertsCount">0</span>
					<span class="wcb-stat-label"><?php esc_html_e( 'Job Alerts', 'wp-career-board' ); ?></span>
				</div>
				<?php endif; ?>
			</div>

			<div class="wcb-two-col">
				<div class="wcb-panel wcb-shown">
					<div class="wcb-panel-header">
						<span class="wcb-panel-title"><?php esc_html_e( 'Recent Applications', 'wp-career-board' ); ?></span>
						<button type="button" class="wcb-panel-link" data-wp-on--click="actions.switchToApplications"><?php esc_html_e( 'View all →', 'wp-career-board' ); ?></button>
					</div>
					<div data-wp-class--wcb-shown="state.hasRecentApps">
						<template data-wp-each--app="state.overviewRecentApps" data-wp-each-key="context.app.id">
							<div class="wcb-overview-app-row">
								<div class="wcb-app-info">
									<span class="wcb-app-name" data-wp-text="context.app.jobTitle"></span>
									<span class="wcb-app-job" data-wp-text="context.app.company"></span>
								</div>
								<span class="wcb-status-badge" role="status" data-wp-text="context.app.status" data-wp-bind--data-status="context.app.status"></span>
							</div>
						</template>
					</div>
					<p class="wcb-panel-empty" data-wp-class--wcb-shown="state.noRecentApps"><?php esc_html_e( 'No applications yet.', 'wp-career-board' ); ?> <a href="<?php echo esc_url( $wcb_jobs_url ); ?>"><?php esc_html_e( 'Browse jobs →', 'wp-career-board' ); ?></a></p>
				</div>

				<div class="wcb-panel wcb-shown">
					<div class="wcb-panel-header">
						<span class="wcb-panel-title"><?php esc_html_e( 'Saved Jobs', 'wp-career-board' ); ?></span>
						<button type="button" class="wcb-panel-link" data-wp-on--click="actions.switchToBookmarks"><?php esc_html_e( 'View all →', 'wp-career-board' ); ?></button>
					</div>
					<div data-wp-class--wcb-shown="state.hasRecentSavedJobs">
						<template data-wp-each--saved="state.overviewRecentSavedJobs" data-wp-each-key="context.saved.id">
							<div class="wcb-overview-app-row">
								<div class="wcb-app-info">
									<a class="wcb-app-name" role="link" tabindex="0" aria-label="<?php esc_attr_e( 'Saved job', 'wp-career-board' ); ?>" data-wp-bind--href="context.saved.permalink" data-wp-bind--aria-label="context.saved.title" data-wp-text="context.saved.title" target="_blank" rel="noopener noreferrer"></a>
									<span class="wcb-app-job" data-wp-text="context.saved.company"></span>
								</div>
								<span class="wcb-status-badge" role="status" data-wp-text="context.saved.type"></span>
							</div>
						</template>
					</div>
					<p class="wcb-panel-empty" data-wp-class--wcb-shown="state.noRecentSavedJobs"><?php esc_html_e( 'No saved jobs yet.', 'wp-career-board' ); ?> <a href="<?php echo esc_url( $wcb_jobs_url ); ?>"><?php esc_html_e( 'Browse jobs →', 'wp-career-board' ); ?></a></p>
				</div>
			</div>

			<section class="wcb-recommends" data-wp-class--wcb-shown="state.showRecommendations">
				<h2 class="wcb-section-title"><?php esc_html_e( 'Recommended for you', 'wp-career-board' ); ?></h2>
				<div class="wcb-recommends-grid">
					<template data-wp-each--rec="state.recommendations" data-wp-each-key="context.rec.job_id">
						<a class="wcb-rec-card" data-wp-bind--href="context.rec.url">
							<span class="wcb-rec-score" data-wp-text="context.rec.score_label"></span>
							<span class="wcb-rec-title" data-wp-text="context.rec.title"></span>
							<span class="wcb-rec-company" data-wp-text="context.rec.company"></span>
							<span class="wcb-rec-location" data-wp-text="context.rec.location"></span>
						</a>
					</template>
				</div>
			</section>
		</div>

		<!-- VIEW: My Applications -->
		<div class="wcb-view-panel" role="tabpanel" aria-labelledby="wcb-tab-applications" data-wp-class--wcb-view-active="state.isTabApplications">
			<div class="wcb-page-header">
				<h1 class="wcb-page-title"><?php esc_html_e( 'My Applications', 'wp-career-board' ); ?></h1>
			</div>

			<div class="wcb-cd-loading" role="status" data-wp-class--wcb-shown="state.loading">
				<span class="wcb-cd-spinner" aria-hidden="true"></span>
				<?php esc_html_e( 'Loading…', 'wp-career-board' ); ?>
			</div>
			<p class="wcb-cd-error" role="alert" data-wp-bind--hidden="!state.error" data-wp-text="state.error"></p>

			<div class="wcb-panel" aria-live="polite" data-wp-class--wcb-shown="state.hasApplications">
				<template data-wp-each--application="state.applications" data-wp-each-key="context.application.id">
					<div class="wcb-cd-app-row">
						<div class="wcb-cd-app-main">
							<h3 class="wcb-cd-app-title">
								<a
									data-wp-bind--href="context.application.jobPermalink"
									data-wp-text="context.application.jobTitle"
									target="_blank"
									rel="noopener noreferrer"
								></a>
							</h3>
							<span class="wcb-cd-app-company" data-wp-text="context.application.company"></span>
							<span class="wcb-cd-app-date" data-wp-text="context.application.date"></span>
						</div>
						<div class="wcb-cd-app-actions">
							<span
								class="wcb-cd-status-badge"
								role="status"
								data-wp-text="context.application.statusLabel"
								data-wp-bind--data-status="context.application.status"
							></span>
							<?php
							/*
							Withdraw shows for live applications (gated by ability).
							 * Remove shows for "Job no longer available" rows so the
							 * candidate can clean dead history out of their list -
							 * both buttons call the same REST endpoint which deletes
							 * the application record. */
							?>
							<button
								type="button"
								class="wcb-cd-withdraw-btn"
								data-wp-class--wcb-shown="state.allowWithdraw"
								data-wp-class--wcb-hidden="context.application.jobRemoved"
								data-wp-on--click="actions.withdrawApplication"
							><?php esc_html_e( 'Withdraw', 'wp-career-board' ); ?></button>
							<button
								type="button"
								class="wcb-cd-withdraw-btn wcb-cd-withdraw-btn--remove"
								data-wp-class--wcb-shown="context.application.jobRemoved"
								data-wp-on--click="actions.withdrawApplication"
							><?php esc_html_e( 'Remove', 'wp-career-board' ); ?></button>
						</div>
					</div>
				</template>
			</div>

			<div class="wcb-cd-empty" data-wp-class--wcb-shown="state.noApplications">
				<p class="wcb-cd-empty-msg"><?php esc_html_e( 'You haven\'t applied to any jobs yet.', 'wp-career-board' ); ?></p>
				<a href="<?php echo esc_url( $wcb_jobs_url ); ?>" class="wcb-cbtn wcb-cbtn--primary">
					<?php esc_html_e( 'Browse Jobs', 'wp-career-board' ); ?>
				</a>
			</div>
		</div>

		<!-- VIEW: Saved Jobs -->
		<div class="wcb-view-panel" role="tabpanel" aria-labelledby="wcb-tab-bookmarks" data-wp-class--wcb-view-active="state.isTabBookmarks">
			<div class="wcb-page-header">
				<h1 class="wcb-page-title"><?php esc_html_e( 'Saved Jobs', 'wp-career-board' ); ?></h1>
			</div>

			<div class="wcb-cd-loading" role="status" data-wp-class--wcb-shown="state.loading">
				<span class="wcb-cd-spinner" aria-hidden="true"></span>
				<?php esc_html_e( 'Loading…', 'wp-career-board' ); ?>
			</div>
			<p class="wcb-cd-error" role="alert" data-wp-bind--hidden="!state.error" data-wp-text="state.error"></p>

			<div class="wcb-panel" aria-live="polite" data-wp-class--wcb-shown="state.hasBookmarks">
				<template data-wp-each--bookmark="state.bookmarks" data-wp-each-key="context.bookmark.id">
					<div class="wcb-cd-bookmark-row">
						<div class="wcb-cd-bookmark-main">
							<h3 class="wcb-cd-bookmark-title">
								<a
									data-wp-bind--href="context.bookmark.permalink"
									data-wp-text="context.bookmark.title"
									target="_blank"
									rel="noopener noreferrer"
								></a>
							</h3>
							<div class="wcb-cd-bookmark-meta">
							<span data-wp-text="context.bookmark.company"></span>
							<span class="wcb-cd-bookmark-meta-sep" data-wp-class--wcb-hidden="!context.bookmark.location" aria-hidden="true">·</span>
							<span data-wp-class--wcb-hidden="!context.bookmark.location" data-wp-text="context.bookmark.location"></span>
							<span class="wcb-cd-bookmark-meta-sep" data-wp-class--wcb-hidden="!context.bookmark.type" aria-hidden="true">·</span>
							<span data-wp-class--wcb-hidden="!context.bookmark.type" data-wp-text="context.bookmark.type"></span>
						</div>
					</div>
					<div class="wcb-cd-bookmark-actions">
							<a
								class="wcb-cbtn wcb-cbtn--ghost wcb-cbtn--sm"
								data-wp-bind--href="context.bookmark.permalink"
								target="_blank"
								rel="noopener noreferrer"
							><?php esc_html_e( 'View Job', 'wp-career-board' ); ?></a>
							<button
								type="button"
								class="wcb-cbtn wcb-cbtn--danger wcb-cbtn--sm"
								data-wp-on--click="actions.unbookmark"
							><?php esc_html_e( 'Remove', 'wp-career-board' ); ?></button>
						</div>
					</div>
				</template>
			</div>

			<div class="wcb-cd-empty" data-wp-class--wcb-shown="state.noBookmarks">
				<p class="wcb-cd-empty-msg"><?php esc_html_e( 'No saved jobs yet. Bookmark a job to find it here.', 'wp-career-board' ); ?></p>
				<a href="<?php echo esc_url( $wcb_jobs_url ); ?>" class="wcb-cbtn wcb-cbtn--primary">
					<?php esc_html_e( 'Browse Jobs', 'wp-career-board' ); ?>
				</a>
			</div>
		</div>

		<!-- VIEW: Saved Companies -->
		<div class="wcb-view-panel" role="tabpanel" aria-labelledby="wcb-tab-saved-companies" data-wp-class--wcb-view-active="state.isTabSavedCompanies">
			<div class="wcb-page-header">
				<h1 class="wcb-page-title"><?php esc_html_e( 'Saved Companies', 'wp-career-board' ); ?></h1>
			</div>

			<div class="wcb-cd-loading" role="status" data-wp-class--wcb-shown="state.savedCompaniesLoading">
				<span class="wcb-cd-spinner" aria-hidden="true"></span>
				<?php esc_html_e( 'Loading…', 'wp-career-board' ); ?>
			</div>
			<p class="wcb-cd-error" role="alert" data-wp-bind--hidden="!state.savedCompaniesError" data-wp-text="state.savedCompaniesError"></p>

			<div class="wcb-panel" aria-live="polite" data-wp-class--wcb-shown="state.hasSavedCompanies">
				<template data-wp-each--company="state.savedCompanies" data-wp-each-key="context.company.id">
					<div class="wcb-cd-bookmark-row">
						<div class="wcb-cd-bookmark-main">
							<h3 class="wcb-cd-bookmark-title">
								<a
									data-wp-bind--href="context.company.permalink"
									data-wp-text="context.company.title"
									target="_blank"
									rel="noopener noreferrer"
								></a>
							</h3>
							<div class="wcb-cd-bookmark-meta">
								<span data-wp-class--wcb-hidden="!context.company.industry" data-wp-text="context.company.industry"></span>
								<span class="wcb-cd-bookmark-meta-sep" data-wp-class--wcb-hidden="!context.company.hq" aria-hidden="true">·</span>
								<span data-wp-class--wcb-hidden="!context.company.hq" data-wp-text="context.company.hq"></span>
							</div>
						</div>
						<div class="wcb-cd-bookmark-actions">
							<a
								class="wcb-cbtn wcb-cbtn--ghost wcb-cbtn--sm"
								data-wp-bind--href="context.company.permalink"
								target="_blank"
								rel="noopener noreferrer"
							><?php esc_html_e( 'View Profile', 'wp-career-board' ); ?></a>
							<button
								type="button"
								class="wcb-cbtn wcb-cbtn--danger wcb-cbtn--sm"
								data-wp-on--click="actions.unbookmarkCompany"
							><?php esc_html_e( 'Remove', 'wp-career-board' ); ?></button>
						</div>
					</div>
				</template>
			</div>

			<div class="wcb-cd-empty" data-wp-class--wcb-shown="state.noSavedCompanies">
				<p class="wcb-cd-empty-msg"><?php esc_html_e( 'No saved companies yet. Bookmark a company to find it here.', 'wp-career-board' ); ?></p>
				<a href="<?php echo esc_url( home_url( '/companies/' ) ); ?>" class="wcb-cbtn wcb-cbtn--primary">
					<?php esc_html_e( 'Browse Companies', 'wp-career-board' ); ?>
				</a>
			</div>
		</div>

		<?php if ( post_type_exists( 'wcb_resume' ) ) : ?>
		<!-- VIEW: Saved Resumes -->
		<div class="wcb-view-panel" role="tabpanel" aria-labelledby="wcb-tab-saved-resumes" data-wp-class--wcb-view-active="state.isTabSavedResumes">
			<div class="wcb-page-header">
				<h1 class="wcb-page-title"><?php esc_html_e( 'Saved Resumes', 'wp-career-board' ); ?></h1>
			</div>

			<div class="wcb-cd-loading" role="status" data-wp-class--wcb-shown="state.savedResumesLoading">
				<span class="wcb-cd-spinner" aria-hidden="true"></span>
				<?php esc_html_e( 'Loading…', 'wp-career-board' ); ?>
			</div>
			<p class="wcb-cd-error" role="alert" data-wp-bind--hidden="!state.savedResumesError" data-wp-text="state.savedResumesError"></p>

			<div class="wcb-panel" aria-live="polite" data-wp-class--wcb-shown="state.hasSavedResumes">
				<template data-wp-each--resume="state.savedResumes" data-wp-each-key="context.resume.id">
					<div class="wcb-cd-bookmark-row">
						<div class="wcb-cd-bookmark-main">
							<h3 class="wcb-cd-bookmark-title">
								<a
									data-wp-bind--href="context.resume.permalink"
									data-wp-text="context.resume.title"
									target="_blank"
									rel="noopener noreferrer"
								></a>
							</h3>
							<div class="wcb-cd-bookmark-meta">
								<span data-wp-class--wcb-hidden="!context.resume.role" data-wp-text="context.resume.role"></span>
								<span class="wcb-cd-bookmark-meta-sep" data-wp-class--wcb-hidden="!context.resume.location" aria-hidden="true">·</span>
								<span data-wp-class--wcb-hidden="!context.resume.location" data-wp-text="context.resume.location"></span>
							</div>
						</div>
						<div class="wcb-cd-bookmark-actions">
							<a
								class="wcb-cbtn wcb-cbtn--ghost wcb-cbtn--sm"
								data-wp-bind--href="context.resume.permalink"
								target="_blank"
								rel="noopener noreferrer"
							><?php esc_html_e( 'View Resume', 'wp-career-board' ); ?></a>
							<button
								type="button"
								class="wcb-cbtn wcb-cbtn--danger wcb-cbtn--sm"
								data-wp-on--click="actions.unbookmarkResume"
							><?php esc_html_e( 'Remove', 'wp-career-board' ); ?></button>
						</div>
					</div>
				</template>
			</div>

			<div class="wcb-cd-empty" data-wp-class--wcb-shown="state.noSavedResumes">
				<p class="wcb-cd-empty-msg"><?php esc_html_e( 'No saved resumes yet. Bookmark a candidate to find it here.', 'wp-career-board' ); ?></p>
				<a href="<?php echo esc_url( home_url( '/find-candidates/' ) ); ?>" class="wcb-cbtn wcb-cbtn--primary">
					<?php esc_html_e( 'Browse Candidates', 'wp-career-board' ); ?>
				</a>
			</div>
		</div>
		<?php endif; ?>

		<!-- VIEW: My Resumes (Pro) -->
		<div class="wcb-view-panel" role="tabpanel" aria-labelledby="wcb-tab-resumes" data-wp-class--wcb-view-active="state.isTabResumes">
			<div class="wcb-page-header">
				<h1 class="wcb-page-title"><?php esc_html_e( 'My Resumes', 'wp-career-board' ); ?></h1>
				<div class="wcb-resumes-header">
					<div class="wcb-resumes-actions" data-wp-class--wcb-hidden="state.showNewResumeForm">
						<button
							type="button"
							class="wcb-cbtn wcb-cbtn--primary"
							data-wp-on--click="actions.toggleNewResumeForm"
							data-wp-bind--disabled="state.isAtResumesCap"
						><?php esc_html_e( '+ New Resume', 'wp-career-board' ); ?></button>
						<label class="wcb-cbtn wcb-cbtn--ghost wcb-upload-label" data-wp-bind--hidden="state.isAtResumesCap">
							<?php esc_html_e( 'Upload CV', 'wp-career-board' ); ?>
							<input
								type="file"
								class="wcb-sr-only"
								accept=".pdf,.doc,.docx"
								data-wp-on--change="actions.uploadResumeFile"
							/>
						</label>
						<span class="wcb-resume-cap-info" data-wp-bind--hidden="!state.maxResumes" data-wp-text="state.resumeCapLabel"></span>
					</div>
					<div class="wcb-new-resume-form" data-wp-class--wcb-hidden="!state.showNewResumeForm">
						<label class="screen-reader-text" for="wcb-new-resume-title"><?php esc_html_e( 'Resume title', 'wp-career-board' ); ?></label>
						<input
							type="text"
							id="wcb-new-resume-title"
							class="wcb-input"
							placeholder="<?php esc_attr_e( 'e.g. Software Developer', 'wp-career-board' ); ?>"
							data-wp-bind--value="state.newResumeTitle"
							data-wp-on--input="actions.setNewResumeTitle"
						>
						<button type="button" class="wcb-cbtn wcb-cbtn--primary" data-wp-on--click="actions.createResume"><?php esc_html_e( 'Create', 'wp-career-board' ); ?></button>
						<button type="button" class="wcb-cbtn wcb-cbtn--ghost" data-wp-on--click="actions.toggleNewResumeForm"><?php esc_html_e( 'Cancel', 'wp-career-board' ); ?></button>
					</div>
				</div>
			</div>

			<div class="wcb-cd-loading" role="status" data-wp-class--wcb-shown="state.loading">
				<span class="wcb-cd-spinner" aria-hidden="true"></span>
				<?php esc_html_e( 'Loading…', 'wp-career-board' ); ?>
			</div>
			<p class="wcb-cd-error" role="alert" data-wp-bind--hidden="!state.error" data-wp-text="state.error"></p>

			<div class="wcb-panel" aria-live="polite" data-wp-class--wcb-shown="state.hasResumes">
			<template data-wp-each--resume="state.resumes" data-wp-each-key="context.resume.id">
				<div class="wcb-resume-card" data-wp-context='{"confirmingDelete": false}'>
					<div class="wcb-resume-card-info">
						<span class="wcb-resume-card-title" data-wp-text="context.resume.title"></span>
						<span class="wcb-resume-card-date" data-wp-text="context.resume.date"></span>
					</div>
					<div class="wcb-resume-card-actions" data-wp-class--wcb-hidden="context.confirmingDelete">
						<a
							class="wcb-cbtn wcb-cbtn--ghost wcb-cbtn--sm"
							data-wp-bind--href="context.resume.pdfUrl"
							data-wp-class--wcb-hidden="!context.resume.isPdf"
							target="_blank"
							rel="noopener"
						><?php esc_html_e( 'Open PDF', 'wp-career-board' ); ?></a>
						<a
							class="wcb-cbtn wcb-cbtn--ghost wcb-cbtn--sm"
							data-wp-bind--href="context.resume.permalink"
							data-wp-class--wcb-hidden="context.resume.isPdf"
							data-wp-bind--hidden="!context.resume.permalink"
							target="_blank"
							rel="noopener"
						><?php esc_html_e( 'View', 'wp-career-board' ); ?></a>
						<button
							type="button"
							class="wcb-cbtn wcb-cbtn--ghost wcb-cbtn--sm"
							data-wp-class--wcb-hidden="context.resume.isPdf"
							data-wp-on--click="actions.openResumeEditor"
						><?php esc_html_e( 'Edit', 'wp-career-board' ); ?></button>
						<label
							class="wcb-cbtn wcb-cbtn--ghost wcb-cbtn--sm wcb-resume-reupload"
							data-wp-class--wcb-hidden="!context.resume.isPdf"
						>
							<?php esc_html_e( 'Re-upload PDF', 'wp-career-board' ); ?>
							<input
								type="file"
								accept="application/pdf"
								data-wp-on--change="actions.reuploadResumePdf"
								class="wcb-resume-reupload-input"
							/>
						</label>
						<button
							type="button"
							class="wcb-cbtn wcb-cbtn--danger wcb-cbtn--sm"
							data-wp-on--click="actions.requestDeleteConfirm"
						><?php esc_html_e( 'Delete', 'wp-career-board' ); ?></button>
					</div>
					<div class="wcb-resume-card-confirm" data-wp-class--wcb-hidden="!context.confirmingDelete">
						<span class="wcb-resume-confirm-msg"><?php esc_html_e( 'Delete this resume?', 'wp-career-board' ); ?></span>
						<button
							type="button"
							class="wcb-cbtn wcb-cbtn--danger wcb-cbtn--sm"
							data-wp-on--click="actions.deleteResume"
						><?php esc_html_e( 'Confirm', 'wp-career-board' ); ?></button>
						<button
							type="button"
							class="wcb-cbtn wcb-cbtn--ghost wcb-cbtn--sm"
							data-wp-on--click="actions.cancelDelete"
						><?php esc_html_e( 'Cancel', 'wp-career-board' ); ?></button>
					</div>
				</div>
			</template>
		</div><!-- .wcb-panel -->

		<div class="wcb-cd-empty" data-wp-class--wcb-shown="state.noResumes">
			<p class="wcb-cd-empty-msg"><?php esc_html_e( 'No resumes yet. Create one with "+ New Resume" or upload a CV to get started.', 'wp-career-board' ); ?></p>
			<button type="button" class="wcb-cbtn wcb-cbtn--primary" data-wp-on--click="actions.toggleNewResumeForm">
				<?php esc_html_e( '+ New Resume', 'wp-career-board' ); ?>
			</button>
		</div>
		</div><!-- .wcb-view-panel: My Resumes -->

		<?php if ( $wcb_resume_builder_embedded ) : ?>
		<!-- VIEW: Resume Builder (Pro embedded) -->
		<div class="wcb-view-panel" data-wp-class--wcb-view-active="state.isTabResumeBuilder">
			<?php
			if ( $wcb_resume_embed_id > 0 ) {
				echo do_blocks( '<!-- wp:wcb/resume-builder /-->' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			} else {
				/* The Resume Builder block only renders when a specific resume
				 * is selected (via the ?wcb_resume=N query param wired by the
				 * Edit button on My Resumes). Without it the panel was an
				 * empty white card with no signal - this empty state tells
				 * the customer where to go next. */
				?>
				<div class="wcb-page-header">
					<h1 class="wcb-page-title"><?php esc_html_e( 'Resume Builder', 'wp-career-board' ); ?></h1>
				</div>
				<div class="wcb-panel-empty wcb-shown">
					<p><?php esc_html_e( 'Pick a resume from My Resumes to edit it here, or create a new one to get started.', 'wp-career-board' ); ?></p>
					<button type="button" class="wcb-cbtn wcb-cbtn--primary" data-wp-on--click="actions.switchToResumes"><?php esc_html_e( 'Go to My Resumes', 'wp-career-board' ); ?></button>
				</div>
				<?php
			}
			?>
		</div>
		<?php endif; ?>

	<?php if ( apply_filters( 'wcb_pro_alerts_enabled', false ) ) : ?>
		<!-- VIEW: Job Alerts (Pro) -->
		<div class="wcb-view-panel" role="tabpanel" aria-labelledby="wcb-tab-alerts" data-wp-class--wcb-view-active="state.isTabAlerts">
			<div class="wcb-page-header">
				<h1 class="wcb-page-title"><?php esc_html_e( 'Job Alerts', 'wp-career-board' ); ?></h1>
			</div>

			<div class="wcb-cd-loading" role="status" data-wp-class--wcb-shown="state.alertsLoading">
				<span class="wcb-cd-spinner" aria-hidden="true"></span>
			</div>

			<div class="wcb-panel" aria-live="polite" data-wp-class--wcb-shown="state.hasAlerts">
				<template data-wp-each--alert="state.alerts" data-wp-each-key="context.alert.id">
					<div class="wcb-alert-row">
						<div class="wcb-alert-main">
							<h3 class="wcb-alert-title" data-wp-text="context.alert.label"></h3>
							<div class="wcb-alert-meta">
								<template data-wp-each--pill="context.alert.filterPills" data-wp-each-key="context.pill">
									<span class="wcb-alert-pill" data-wp-text="context.pill"></span>
								</template>
							</div>
						</div>
						<div class="wcb-alert-actions">
							<select class="wcb-alert-freq" aria-label="<?php esc_attr_e( 'Alert frequency', 'wp-career-board' ); ?>" data-wp-bind--value="context.alert.frequency" data-wp-on--change="actions.changeAlertFrequency">
								<option value="instant"><?php esc_html_e( 'Instant', 'wp-career-board' ); ?></option>
								<option value="daily"><?php esc_html_e( 'Daily', 'wp-career-board' ); ?></option>
								<option value="weekly"><?php esc_html_e( 'Weekly', 'wp-career-board' ); ?></option>
							</select>
							<button type="button" class="wcb-cbtn wcb-cbtn--danger wcb-cbtn--sm" data-wp-on--click="actions.deleteAlert">
								<?php esc_html_e( 'Delete', 'wp-career-board' ); ?>
							</button>
						</div>
					</div>
				</template>
			</div>

			<div class="wcb-cd-empty" data-wp-class--wcb-shown="state.noAlerts">
				<p class="wcb-cd-empty-msg"><?php esc_html_e( 'No job alerts yet. Search for jobs and click "Alert me" to get notified when matching jobs are posted.', 'wp-career-board' ); ?></p>
				<a href="<?php echo esc_url( $wcb_jobs_url ); ?>" class="wcb-cbtn wcb-cbtn--primary">
		<?php esc_html_e( 'Browse Jobs', 'wp-career-board' ); ?>
				</a>
			</div>
		</div>
	<?php endif; ?>

	<!-- ── Profile panel ──────────────────────────────────────────── -->
	<div class="wcb-view-panel" role="tabpanel" aria-labelledby="wcb-tab-profile" data-wp-class--wcb-view-active="state.isTabProfile">
		<div class="wcb-page-header">
			<h1 class="wcb-page-title"><?php esc_html_e( 'My Profile', 'wp-career-board' ); ?></h1>
		</div>
		<div class="wcb-panel wcb-panel--form wcb-shown">
			<div class="wcb-form-field">
				<label class="wcb-form-label" for="wcb-profile-email"><?php esc_html_e( 'Email', 'wp-career-board' ); ?></label>
				<input
					type="email"
					id="wcb-profile-email"
					class="wcb-input"
					readonly
					data-wp-bind--value="state.profileEmail"
				/>
			</div>

			<div class="wcb-form-field">
				<label class="wcb-form-label" for="wcb-profile-phone"><?php esc_html_e( 'Phone', 'wp-career-board' ); ?></label>
				<input
					type="tel"
					id="wcb-profile-phone"
					class="wcb-input"
					placeholder="<?php esc_attr_e( 'e.g. +1 555 123 4567', 'wp-career-board' ); ?>"
					data-wp-bind--value="state.profilePhone"
					data-wp-on--input="actions.updateProfilePhone"
				/>
			</div>

			<div class="wcb-form-field">
				<label class="wcb-form-label" for="wcb-profile-location"><?php esc_html_e( 'Location', 'wp-career-board' ); ?></label>
				<input
					type="text"
					id="wcb-profile-location"
					class="wcb-input"
					placeholder="<?php esc_attr_e( 'e.g. Bengaluru, India', 'wp-career-board' ); ?>"
					data-wp-bind--value="state.profileLocation"
					data-wp-on--input="actions.updateProfileLocation"
				/>
			</div>

			<div class="wcb-form-field">
				<label class="wcb-form-label" for="wcb-profile-bio"><?php esc_html_e( 'Bio / About Me', 'wp-career-board' ); ?></label>
				<div class="wcb-editor" data-placeholder="<?php esc_attr_e( 'Tell employers about yourself…', 'wp-career-board' ); ?>">
					<div class="wcb-editor-holder" id="wcb-editor-profile-bio"></div>
					<textarea
						id="wcb-profile-bio"
						class="wcb-editor-source"
						rows="1"
						tabindex="-1"
						aria-label="<?php esc_attr_e( 'Bio / About me', 'wp-career-board' ); ?>"
						data-wp-bind--value="state.profileBio"
						data-wp-on--input="actions.updateProfileBio"
					></textarea>
				</div>
			</div>

			<?php
			// Custom-field groups from wcb_candidate_form_fields filter.
			// Stored against the candidate's user meta.
			$wcb_cd_custom = (array) apply_filters( 'wcb_candidate_form_fields', array(), $wcb_candidate_id );
			if ( ! empty( $wcb_cd_custom ) ) {
				\WCB\Core\FormCustomFields::render_groups( $wcb_cd_custom, 'updateCustomField', 'wcb-candidate-custom', (int) $wcb_candidate_id, 'user_meta' );
			}
			?>

			<div class="wcb-form-actions" style="margin-top:var(--wcb-space-lg)">
				<button type="button" class="wcb-cbtn wcb-cbtn--primary"
					data-wp-on--click="actions.saveProfile"
					data-wp-bind--disabled="state.profileSaving">
					<span data-wp-class--wcb-hidden="state.profileSaving"><?php esc_html_e( 'Save Profile', 'wp-career-board' ); ?></span>
					<span data-wp-class--wcb-hidden="!state.profileSaving"><?php esc_html_e( 'Saving…', 'wp-career-board' ); ?></span>
				</button>
				<span class="wcb-save-confirm wcb-icon-label" data-wp-class--wcb-shown="state.profileSaved"><?php echo \WCB\Core\Icon::svg( 'check' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- pre-escaped inside helper. ?><?php esc_html_e( 'Saved', 'wp-career-board' ); ?></span>
			</div>
		</div>
	</div>

	<!-- ── Settings panel ─────────────────────────────────────────── -->
	<div class="wcb-view-panel" role="tabpanel" aria-labelledby="wcb-tab-settings" data-wp-class--wcb-view-active="state.isTabSettings">
		<div class="wcb-page-header">
			<h1 class="wcb-page-title"><?php esc_html_e( 'Account Settings', 'wp-career-board' ); ?></h1>
		</div>
		<div class="wcb-panel wcb-panel--form wcb-shown">
			<p class="wcb-account-msg" role="status" data-wp-bind--hidden="!state.accountMsg" data-wp-bind--data-type="state.accountMsgType" data-wp-text="state.accountMsg"></p>
			<div class="wcb-form-field">
				<label class="wcb-form-label" for="wcb-account-name"><?php esc_html_e( 'Display Name', 'wp-career-board' ); ?></label>
				<input type="text" id="wcb-account-name" class="wcb-input" autocomplete="name" data-wp-bind--value="state.accountName" data-wp-on--input="actions.updateField" data-wcb-field="accountName" />
			</div>
			<div class="wcb-form-field">
				<label class="wcb-form-label" for="wcb-account-email"><?php esc_html_e( 'Email', 'wp-career-board' ); ?></label>
				<input type="email" id="wcb-account-email" class="wcb-input" autocomplete="email" data-wp-bind--value="state.accountEmail" data-wp-on--input="actions.updateField" data-wcb-field="accountEmail" />
			</div>
			<div class="wcb-form-field">
				<button type="button" class="wcb-cbtn wcb-cbtn--primary" data-wp-on--click="actions.saveAccount" data-wp-bind--disabled="state.accountSaving"><?php esc_html_e( 'Save changes', 'wp-career-board' ); ?></button>
			</div>
		</div>

		<div class="wcb-page-header" style="margin-top: var(--wcb-space-xl);">
			<h2 class="wcb-page-title"><?php esc_html_e( 'Change Password', 'wp-career-board' ); ?></h2>
		</div>
		<div class="wcb-panel wcb-panel--form wcb-shown">
			<p class="wcb-account-msg" role="status" data-wp-bind--hidden="!state.pwMsg" data-wp-bind--data-type="state.pwMsgType" data-wp-text="state.pwMsg"></p>
			<div class="wcb-form-field">
				<label class="wcb-form-label" for="wcb-account-curpw"><?php esc_html_e( 'Current Password', 'wp-career-board' ); ?></label>
				<input type="password" id="wcb-account-curpw" class="wcb-input" autocomplete="current-password" data-wp-bind--value="state.curPassword" data-wp-on--input="actions.updateField" data-wcb-field="curPassword" />
			</div>
			<div class="wcb-form-field">
				<label class="wcb-form-label" for="wcb-account-newpw"><?php esc_html_e( 'New Password', 'wp-career-board' ); ?></label>
				<input type="password" id="wcb-account-newpw" class="wcb-input" autocomplete="new-password" data-wp-bind--value="state.newPassword" data-wp-on--input="actions.updateField" data-wcb-field="newPassword" />
			</div>
			<div class="wcb-form-field">
				<label class="wcb-form-label" for="wcb-account-confpw"><?php esc_html_e( 'Confirm New Password', 'wp-career-board' ); ?></label>
				<input type="password" id="wcb-account-confpw" class="wcb-input" autocomplete="new-password" data-wp-bind--value="state.confPassword" data-wp-on--input="actions.updateField" data-wcb-field="confPassword" />
			</div>
			<div class="wcb-form-field">
				<button type="button" class="wcb-cbtn wcb-cbtn--primary" data-wp-on--click="actions.changePassword" data-wp-bind--disabled="state.pwSaving"><?php esc_html_e( 'Update password', 'wp-career-board' ); ?></button>
			</div>
		</div>

		<!-- ── Privacy & data controls (GDPR self-service, A-11) ─────── -->
		<div class="wcb-page-header" style="margin-top: var(--wcb-space-xl);">
			<h2 class="wcb-page-title"><?php esc_html_e( 'Privacy & My Data', 'wp-career-board' ); ?></h2>
		</div>
		<div class="wcb-panel wcb-panel--form wcb-shown wcb-privacy-panel">
			<p class="wcb-privacy-desc">
				<?php esc_html_e( 'Request a copy of your personal data, or delete your account permanently. Both actions are processed by the site administrator and you\'ll receive an email confirmation when complete.', 'wp-career-board' ); ?>
			</p>
			<div class="wcb-settings-row">
				<div class="wcb-settings-row-label"><?php esc_html_e( 'Export my data', 'wp-career-board' ); ?></div>
				<div class="wcb-settings-row-control">
					<button type="button" class="wcb-cbtn wcb-cbtn--ghost"
						data-wp-on--click="actions.requestExport"
						data-wp-bind--disabled="state.privacyBusy">
						<span data-wp-class--wcb-hidden="state.privacyExportRequested"><?php esc_html_e( 'Request data export', 'wp-career-board' ); ?></span>
						<span class="wcb-hidden wcb-icon-label" data-wp-class--wcb-hidden="!state.privacyExportRequested"><?php echo \WCB\Core\Icon::svg( 'check' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- pre-escaped inside helper. ?><?php esc_html_e( 'Export requested', 'wp-career-board' ); ?></span>
					</button>
				</div>
			</div>
			<div class="wcb-settings-row">
				<div class="wcb-settings-row-label"><?php esc_html_e( 'Delete my account', 'wp-career-board' ); ?></div>
				<div class="wcb-settings-row-control">
					<button type="button" class="wcb-cbtn wcb-cbtn--danger"
						data-wp-on--click="actions.requestErase"
						data-wp-bind--disabled="state.privacyBusy">
						<span data-wp-class--wcb-hidden="state.privacyEraseRequested"><?php esc_html_e( 'Request account deletion', 'wp-career-board' ); ?></span>
						<span class="wcb-hidden wcb-icon-label" data-wp-class--wcb-hidden="!state.privacyEraseRequested"><?php echo \WCB\Core\Icon::svg( 'check' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- pre-escaped inside helper. ?><?php esc_html_e( 'Deletion requested', 'wp-career-board' ); ?></span>
					</button>
				</div>
			</div>
			<p class="wcb-privacy-note" data-wp-class--wcb-shown="state.privacyError" data-wp-text="state.privacyError"></p>
		</div>
	</div>

		<?php if ( $wcb_bell_enabled ) : ?>
		<!-- VIEW: Notifications (Pro) -->
		<div class="wcb-view-panel" role="tabpanel" aria-labelledby="wcb-tab-notifications" data-wp-class--wcb-view-active="state.isTabNotifications">
			<div class="wcb-page-header">
				<h1 class="wcb-page-title"><?php esc_html_e( 'Notifications', 'wp-career-board' ); ?></h1>
			</div>
			<?php
			// Pro's notifications-list markup (trusted Interactivity HTML; see note at top).
			// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- trusted plugin Interactivity markup.
			echo $wcb_module_renders['notifications_bell'];
			?>
		</div>
		<?php endif; ?>

	</main>

</div><!-- .wcb-dashboard-shell -->

</div>
