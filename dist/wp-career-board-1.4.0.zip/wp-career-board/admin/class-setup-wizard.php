<?php // phpcs:ignore WordPress.Files.FileName.InvalidClassFileName -- hyphenated file name is intentional.
/**
 * Admin setup wizard — auto-creates required pages on first activation.
 *
 * Wizard steps are powered by REST endpoints (no admin-ajax.php).
 *
 * @package WP_Career_Board
 * @since   1.0.0
 */

declare( strict_types=1 );

namespace WCB\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Guides new site owners through first-run configuration via a REST-powered wizard.
 *
 * @since 1.0.0
 */
class SetupWizard extends \WCB\Api\RestController {



	/**
	 * Detect whether first-run setup has completed.
	 *
	 * Composes two signals so a desynced flag (DB restore, manual option
	 * deletion, partial wizard run that never persisted the flag) doesn't
	 * silently re-launch the wizard over a configured site:
	 *
	 *  1. The legacy `wcb_setup_complete` flag we explicitly write at the
	 *     end of the wizard.
	 *  2. Content fallback — if `wcb_settings` already maps any of the core
	 *     page IDs (employer dashboard, candidate dashboard, jobs archive)
	 *     to a real post, the wizard has run at some point in this site's
	 *     life and we should not restart it.
	 *
	 * @since 1.1.1
	 *
	 * @return bool
	 */
	public static function is_setup_complete(): bool {
		if ( (bool) get_option( 'wcb_setup_complete', false ) ) {
			return true;
		}
		foreach ( array( 'employer_dashboard_page', 'candidate_dashboard_page', 'jobs_archive_page' ) as $wcb_key ) {
			$wcb_id = Settings::int( $wcb_key, 0 );
			if ( $wcb_id > 0 && get_post( $wcb_id ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Boot the setup wizard.
	 *
	 * @since  1.0.0
	 * @return void
	 */
	public function boot(): void {
		add_action( 'admin_init', array( $this, 'maybe_redirect' ) );
		add_action( 'admin_menu', array( $this, 'register_page' ) );
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_wizard_assets' ) );
		add_action( 'admin_post_wcb_install_demo', array( $this, 'handle_install_demo' ) );
	}

	/**
	 * Install sample data from the Settings page (server-side form action), so
	 * the demo content can be created without re-running the setup wizard.
	 *
	 * @since 1.3.1
	 * @return void
	 */
	public function handle_install_demo(): void {
		check_admin_referer( 'wcb_install_demo' );

		if ( ! wp_is_ability_granted( 'wcb/manage-settings' ) ) { // phpcs:ignore WordPress.WP.Capabilities.Unknown -- polyfilled in core/abilities-api-polyfill.php.
			wp_die( esc_html__( 'You do not have permission to do this.', 'wp-career-board' ) );
		}

		$this->install_sample_data();

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'     => 'wcb-settings',
					'tab'      => 'listings',
					'wcb_demo' => 'installed',
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	/**
	 * Redirect to the wizard page on first activation.
	 *
	 * @since  1.0.0
	 * @return void
	 */
	public function maybe_redirect(): void {
		if ( ! get_transient( 'wcb_activation_redirect' ) ) {
			return;
		}

		if ( self::is_setup_complete() ) {
			return;
		}

		delete_transient( 'wcb_activation_redirect' );
		wp_safe_redirect( admin_url( 'admin.php?page=wcb-setup' ) );
		exit;
	}

	/**
	 * Register the hidden setup wizard submenu page.
	 *
	 * @since  1.0.0
	 * @return void
	 */
	public function register_page(): void {
		// Parent slug 'options.php' keeps the page accessible at
		// admin.php?page=wcb-setup but registers it in the $submenu global
		// so get_admin_page_title() resolves the title without WordPress
		// tripping on PHP 8.1+ strip_tags(null) in admin-header.php.
		add_submenu_page(
			'options.php',
			__( 'Setup Wizard', 'wp-career-board' ),
			__( 'Setup Wizard', 'wp-career-board' ),
			'wcb_manage_settings', // phpcs:ignore WordPress.WP.Capabilities.Unknown -- wcb_manage_settings is a registered WCB custom capability.
			'wcb-setup',
			array( $this, 'render' )
		);
	}

	/**
	 * Get the wizard step definitions.
	 *
	 * @since  1.1.0
	 * @return array<string, array{title: string, template: string, button_text: string}>
	 */
	public function get_steps(): array {
		/**
		 * Filters the wizard step definitions.
		 *
		 * Each entry is keyed by a unique slug and contains 'title', 'template'
		 * (absolute path to the step partial), and 'button_text'. Pro (and other
		 * add-ons) use this filter to append their own steps.
		 *
		 * @since 1.1.0
		 *
		 * @param array<string, array{title: string, template: string, button_text: string}> $steps Steps to render.
		 */
		return apply_filters(
			'wcb_wizard_steps',
			array(
				'create-pages' => array(
					'title'       => __( 'Create Pages', 'wp-career-board' ),
					'template'    => WCB_DIR . 'admin/views/wizard-steps/create-pages.php',
					'button_text' => __( 'Create Pages & Continue', 'wp-career-board' ),
				),
				'sample-data'  => array(
					'title'       => __( 'Sample Data', 'wp-career-board' ),
					'template'    => WCB_DIR . 'admin/views/wizard-steps/sample-data.php',
					'button_text' => __( 'Finish Setup', 'wp-career-board' ),
				),
			)
		);
	}

	/**
	 * Enqueue wizard assets only on the wizard admin page.
	 *
	 * @since 1.0.0
	 *
	 * @param  string $hook Current admin page hook suffix.
	 * @return void
	 */
	public function enqueue_wizard_assets( string $hook ): void {
		if ( 'admin_page_wcb-setup' !== $hook ) {
			return;
		}

		$steps = $this->get_steps();

		wp_enqueue_script(
			'wcb-wizard',
			WCB_URL . 'assets/js/wizard.js',
			array( 'wp-api-fetch' ),
			WCB_VERSION,
			true
		);

		wp_localize_script(
			'wcb-wizard',
			'wcbWizard',
			array(
				'restUrl'    => esc_url_raw( untrailingslashit( rest_url( 'wcb/v1/wizard' ) ) ),
				'steps'      => array_keys( $steps ),
				'totalSteps' => count( $steps ),
			)
		);
	}

	/**
	 * Register wizard REST routes.
	 *
	 * @since  1.0.0
	 * @return void
	 */
	public function register_routes(): void {
		register_rest_route(
			$this->namespace,
			'/wizard/create-pages',
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'create_pages_handler' ),
				'permission_callback' => array( $this, 'wizard_permission_check' ),
			)
		);

		register_rest_route(
			$this->namespace,
			'/wizard/sample-data',
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'sample_data_handler' ),
				'permission_callback' => array( $this, 'wizard_permission_check' ),
				'args'                => array(
					'install_sample' => array(
						'type'              => 'integer',
						'default'           => 0,
						'sanitize_callback' => 'absint',
					),
				),
			)
		);

		register_rest_route(
			$this->namespace,
			'/wizard/complete',
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'complete_handler' ),
				'permission_callback' => array( $this, 'wizard_permission_check' ),
			)
		);

		register_rest_route(
			$this->namespace,
			'/wizard/remove-sample-data',
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'remove_sample_data_handler' ),
				'permission_callback' => array( $this, 'wizard_permission_check' ),
			)
		);
	}

	/**
	 * Permission check for all wizard REST routes.
	 *
	 * @since  1.0.0
	 * @return bool|\WP_Error
	 */
	public function wizard_permission_check(): bool|\WP_Error {
		if ( $this->check_ability( 'wcb/manage-settings' ) ) {
			return true;
		}
		return $this->permission_error();
	}

	/**
	 * REST handler — create required WordPress pages.
	 *
	 * @since 1.0.0
	 *
	 * @param  \WP_REST_Request $request REST request (unused — no params required).
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function create_pages_handler( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {   // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundInExtendedClass
		$created = $this->create_required_pages();
		return rest_ensure_response( $created );
	}

	/**
	 * REST handler — optionally install sample taxonomy terms, company, and job.
	 *
	 * @since 1.0.0
	 *
	 * @param  \WP_REST_Request $request REST request; reads `install_sample` param.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function sample_data_handler( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		if ( $request->get_param( 'install_sample' ) ) {
			$this->install_sample_data();
		}
		return rest_ensure_response( array( 'installed' => (bool) $request->get_param( 'install_sample' ) ) );
	}

	/**
	 * REST handler — mark setup complete and return the dashboard redirect URL.
	 *
	 * @since 1.0.0
	 *
	 * @param  \WP_REST_Request $request REST request (unused — no params required).
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function complete_handler( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {   // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundInExtendedClass
		update_option( 'wcb_setup_complete', true );

		/**
		 * Fires after the setup wizard marks itself complete.
		 *
		 * Pro hooks this to set its own wcbp_setup_complete flag.
		 *
		 * @since 1.1.0
		 */
		do_action( 'wcb_wizard_completed' );

		/**
		 * Filters the redirect URL shown after wizard completion.
		 *
		 * @since 1.1.0
		 *
		 * @param string $redirect Dashboard URL.
		 */
		$redirect = apply_filters( 'wcb_wizard_complete_redirect', admin_url( 'admin.php?page=wp-career-board' ) );

		return rest_ensure_response( array( 'redirect' => $redirect ) );
	}

	/**
	 * REST handler — remove all wizard sample data.
	 *
	 * @since 1.0.0
	 *
	 * @param  \WP_REST_Request $request REST request (unused).
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function remove_sample_data_handler( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {   // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundInExtendedClass
		$removed = $this->remove_sample_data();
		return rest_ensure_response( $removed );
	}

	/**
	 * Render the setup wizard view.
	 *
	 * @since  1.0.0
	 * @return void
	 */
	public function render(): void {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only flag, no state mutation.
		$rerun = isset( $_GET['wcb_rerun'] ) && '1' === $_GET['wcb_rerun'];

		/**
		 * Allows add-ons to force the wizard to render even when setup is complete.
		 *
		 * Pro uses this for the mini-wizard (wcbp_only=1) so Pro-specific steps
		 * can run after the Free wizard has already finished.
		 *
		 * @since 1.1.0
		 *
		 * @param bool $force Whether to force-render the wizard.
		 */
		$force_render = apply_filters( 'wcb_wizard_force_render', $rerun );

		if ( self::is_setup_complete() && ! $force_render ) {
			include_once WCB_DIR . 'admin/views/setup-wizard-complete.php';
			return;
		}

		$steps = $this->get_steps(); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- template variable, not a global.
		include_once WCB_DIR . 'admin/views/setup-wizard.php';
	}

	/**
	 * Create the four required WCB pages and persist their IDs in wcb_settings.
	 *
	 * Skips any page whose setting key already has a non-zero value.
	 *
	 * @since  1.0.0
	 * @return array Map of setting_key => page_id for each page that was created.
	 */
	private function create_required_pages(): array {
		$settings = Settings::all();
		$created  = array();

		/**
		 * Filters the pages the setup wizard will create.
		 *
		 * Each entry is keyed by the wcb_settings option key and contains
		 * 'title' and 'content' for the page to insert. Pro (and other add-ons)
		 * use this filter to append their own required pages.
		 *
		 * @since 1.0.0
		 *
		 * @param array<string, array{title: string, content: string}> $pages Pages to create.
		 */
		$pages = apply_filters(
			'wcb_wizard_required_pages',
			array(
				'employer_registration_page' => array(
					'title'   => __( 'Employer Registration', 'wp-career-board' ),
					'content' => '<!-- wp:wp-career-board/employer-registration /-->',
				),
				'employer_dashboard_page'    => array(
					'title'   => __( 'Employer Dashboard', 'wp-career-board' ),
					'content' => '<!-- wp:wp-career-board/employer-dashboard /-->',
				),
				'candidate_dashboard_page'   => array(
					'title'   => __( 'Candidate Dashboard', 'wp-career-board' ),
					'content' => '<!-- wp:wp-career-board/candidate-dashboard /-->',
				),
				'jobs_archive_page'          => array(
					'title'   => __( 'Find Jobs', 'wp-career-board' ),
					'content' => '<!-- wp:heading {"level":1,"className":"wcb-page-heading"} --><h1 class="wp-block-heading wcb-page-heading">' . esc_html__( 'Find Jobs', 'wp-career-board' ) . '</h1><!-- /wp:heading --><!-- wp:wp-career-board/job-search /--><!-- wp:wp-career-board/job-filters /--><!-- wp:wp-career-board/job-listings /-->',
				),
				'company_archive_page'       => array(
					'title'   => __( 'Companies', 'wp-career-board' ),
					'content' => '<!-- wp:wp-career-board/company-archive /-->',
				),
				'post_job_page'              => array(
					'title'   => __( 'Post a Job', 'wp-career-board' ),
					'content' => '<!-- wp:wp-career-board/job-form /-->',
				),
			)
		);

		foreach ( $pages as $setting_key => $page_data ) {
			if ( ! empty( $settings[ $setting_key ] ) && get_post( (int) $settings[ $setting_key ] ) ) {
				continue;
			}

			// Re-use an existing published page that already contains this block.
			// Match the plugin's OWN block, not the first block: some pages (e.g.
			// Find Jobs) now lead with a wp:heading title block, and keying reuse
			// off "heading" grabbed any unrelated page that had a heading. Fall
			// back to the first block only when no wp-career-board block exists.
			$block_name = '';
			if ( preg_match( '/<!-- wp:(wp-career-board\/[a-z0-9-]+)/', $page_data['content'], $m )
				|| preg_match( '/<!-- wp:([a-z0-9-]+(?:\/[a-z0-9-]+)?)/', $page_data['content'], $m ) ) {
				$block_name = $m[1];
			}
			if ( $block_name ) {
				$existing = get_posts(
					array(
						'post_type'      => 'page',
						'post_status'    => 'publish',
						'posts_per_page' => 1,
						'fields'         => 'ids',
						's'              => $block_name,
						'no_found_rows'  => true,
					)
				);
				if ( $existing ) {
						$settings[ $setting_key ] = $existing[0];
						$created[ $setting_key ]  = $existing[0];
						continue;
				}
			}

			$page_id = wp_insert_post(
				array(
					'post_title'   => $page_data['title'],
					'post_content' => $page_data['content'],
					'post_status'  => 'publish',
					'post_type'    => 'page',
				)
			);

			if ( $page_id && ! is_wp_error( $page_id ) ) {
					$settings[ $setting_key ] = $page_id;
					$created[ $setting_key ]  = $page_id;
			}
		}

		update_option( 'wcb_settings', $settings );
		return $created;
	}

	/**
	 * Install rich sample data so the site admin can see the plugin in action.
	 *
	 * Creates 3 companies, 8 published jobs across multiple categories,
	 * and all required taxonomy terms. Every created ID is tracked in the
	 * `wcb_sample_data_ids` option so removal is clean.
	 *
	 * @since  1.0.0
	 * @return void
	 */
	private function install_sample_data(): void {
		$author_id   = get_current_user_id() ? get_current_user_id() : 1;
		$created_ids = array(
			'companies' => array(),
			'jobs'      => array(),
			'terms'     => array(),
		);

		$deadline_3m = gmdate( 'Y-m-d', (int) strtotime( '+3 months' ) );
		$deadline_6w = gmdate( 'Y-m-d', (int) strtotime( '+6 weeks' ) );
		$deadline_2m = gmdate( 'Y-m-d', (int) strtotime( '+2 months' ) );

		// -----------------------------------------------------------------
		// 1. Taxonomy terms.
		// -----------------------------------------------------------------
		$terms = array(
			'wcb_category'   => array( 'Engineering', 'Design', 'Marketing', 'Product', 'Data', 'Customer Success' ),
			'wcb_job_type'   => array( 'Full-time', 'Part-time', 'Contract', 'Freelance', 'Internship' ),
			'wcb_location'   => array( 'Remote', 'San Francisco, CA', 'New York, NY', 'London, UK' ),
			'wcb_experience' => array( 'Entry Level', 'Mid Level', 'Senior', 'Lead', 'Executive' ),
			'wcb_tag'        => array( 'Remote-first', 'SaaS', 'Fintech', 'E-commerce', 'Open Source' ),
		);

		$term_map = array();
		foreach ( $terms as $taxonomy => $names ) {
			foreach ( $names as $name ) {
				$existing = get_term_by( 'name', $name, $taxonomy );
				if ( $existing instanceof \WP_Term ) {
					$term_map[ $taxonomy ][ $name ] = $existing->term_id;
					continue;
				}
				$result = wp_insert_term( $name, $taxonomy );
				if ( ! is_wp_error( $result ) ) {
					$tid                            = (int) $result['term_id'];
					$term_map[ $taxonomy ][ $name ] = $tid;
					$created_ids['terms'][]         = array(
						'term_id'  => $tid,
						'taxonomy' => $taxonomy,
					);
				}
			}
		}

		// -----------------------------------------------------------------
		// 2. Companies.
		// -----------------------------------------------------------------
		$companies = array(
			array(
				'title' => 'Acme Corp',
				'slug'  => 'acme-corp',
				'meta'  => array(
					'_wcb_tagline'      => 'Building the future, one product at a time',
					'_wcb_website'      => 'https://acme-corp.example.com',
					'_wcb_industry'     => 'technology',
					'_wcb_company_size' => '201-500',
					'_wcb_hq_location'  => 'San Francisco, CA',
				),
			),
			array(
				'title' => 'Starter Labs',
				'slug'  => 'starter-labs',
				'meta'  => array(
					'_wcb_tagline'      => 'Developer tools for the modern web',
					'_wcb_website'      => 'https://starterlabs.example.com',
					'_wcb_industry'     => 'technology',
					'_wcb_company_size' => '51-200',
					'_wcb_hq_location'  => 'Remote',
				),
			),
			array(
				'title' => 'PayFlow',
				'slug'  => 'payflow',
				'meta'  => array(
					'_wcb_tagline'      => 'Payments infrastructure for the internet',
					'_wcb_website'      => 'https://payflow.example.com',
					'_wcb_industry'     => 'finance',
					'_wcb_company_size' => '501-1000',
					'_wcb_hq_location'  => 'New York, NY',
				),
			),
		);

		$company_ids = array();
		foreach ( $companies as $co ) {
			$existing = get_page_by_path( $co['slug'], OBJECT, 'wcb_company' );
			if ( $existing ) {
				$company_ids[ $co['slug'] ] = (int) $existing->ID;
				// Re-track on re-run so wcb_sample_data_ids stays complete
				// instead of being overwritten with an empty map.
				$created_ids['companies'][] = (int) $existing->ID;
				continue;
			}
			$cid = wp_insert_post(
				array(
					'post_type'   => 'wcb_company',
					'post_title'  => $co['title'],
					'post_name'   => $co['slug'],
					'post_status' => 'publish',
					'post_author' => $author_id,
				)
			);
			if ( $cid && ! is_wp_error( $cid ) ) {
				foreach ( $co['meta'] as $k => $v ) {
					update_post_meta( $cid, $k, $v );
				}
				update_post_meta( $cid, '_wcb_sample', 1 );
				\WCB\Core\Locations::sync_company_hq( (int) $cid, (string) $co['meta']['_wcb_hq_location'] );
				$company_ids[ $co['slug'] ] = $cid;
				$created_ids['companies'][] = $cid;
			}
		}

		// Link admin to first company (primary).
		if ( ! empty( $company_ids ) && ! get_user_meta( $author_id, '_wcb_company_id', true ) ) {
			update_user_meta( $author_id, '_wcb_company_id', reset( $company_ids ) );
		}

		// -----------------------------------------------------------------
		// 3. Jobs — 8 published across 3 companies.
		// -----------------------------------------------------------------
		$jobs = array(
			array(
				'title'   => 'Senior PHP Developer',
				'slug'    => 'wcb-sample-senior-php-developer',
				'company' => 'acme-corp',
				'content' => "We're looking for an experienced PHP developer to join our growing team.\n\n**What you'll do:**\n- Build and maintain scalable backend services with PHP 8+\n- Design RESTful APIs used by our frontend and mobile apps\n- Write tests, participate in code reviews, and mentor junior developers\n\n**You have:**\n- 5+ years of PHP experience (Laravel or WordPress preferred)\n- Strong understanding of SQL, caching, and queue systems",
				'meta'    => array(
					'_wcb_salary_min'      => '120000',
					'_wcb_salary_max'      => '160000',
					'_wcb_salary_currency' => 'USD',
					'_wcb_salary_type'     => 'annual',
					'_wcb_remote'          => '1',
					'_wcb_deadline'        => $deadline_3m,
					'_wcb_featured'        => '1',
				),
				'tax'     => array(
					'wcb_category'   => array( 'Engineering' ),
					'wcb_job_type'   => array( 'Full-time' ),
					'wcb_location'   => array( 'Remote', 'San Francisco, CA' ),
					'wcb_experience' => array( 'Senior' ),
				),
			),
			array(
				'title'   => 'Product Designer',
				'slug'    => 'wcb-sample-product-designer',
				'company' => 'acme-corp',
				'content' => "Shape the product experience for thousands of users.\n\n**Responsibilities:**\n- Own end-to-end design for key product areas\n- Create wireframes, prototypes, and high-fidelity mockups in Figma\n- Run usability studies and translate insights into designs",
				'meta'    => array(
					'_wcb_salary_min'      => '110000',
					'_wcb_salary_max'      => '145000',
					'_wcb_salary_currency' => 'USD',
					'_wcb_salary_type'     => 'annual',
					'_wcb_remote'          => '1',
					'_wcb_deadline'        => $deadline_2m,
					'_wcb_featured'        => '1',
				),
				'tax'     => array(
					'wcb_category'   => array( 'Design' ),
					'wcb_job_type'   => array( 'Full-time' ),
					'wcb_location'   => array( 'Remote' ),
					'wcb_experience' => array( 'Mid Level', 'Senior' ),
				),
			),
			array(
				'title'   => 'Growth Marketing Manager',
				'slug'    => 'wcb-sample-growth-marketing-manager',
				'company' => 'acme-corp',
				'content' => "Drive product-led growth across acquisition, activation, and retention.\n\n**Requirements:**\n- 4+ years in growth marketing at a SaaS company\n- Data-driven — comfortable with SQL, analytics tools, and A/B testing\n- Experience managing paid channels and SEO strategy",
				'meta'    => array(
					'_wcb_salary_min'      => '100000',
					'_wcb_salary_max'      => '135000',
					'_wcb_salary_currency' => 'USD',
					'_wcb_salary_type'     => 'annual',
					'_wcb_remote'          => '0',
					'_wcb_deadline'        => $deadline_6w,
					'_wcb_featured'        => '0',
				),
				'tax'     => array(
					'wcb_category'   => array( 'Marketing' ),
					'wcb_job_type'   => array( 'Full-time' ),
					'wcb_location'   => array( 'San Francisco, CA' ),
					'wcb_experience' => array( 'Senior' ),
				),
			),
			array(
				'title'   => 'Frontend Engineer',
				'slug'    => 'wcb-sample-frontend-engineer',
				'company' => 'starter-labs',
				'content' => "Build beautiful, performant developer tools.\n\n**What you'll do:**\n- Build React/TypeScript components for our developer dashboard\n- Optimize Core Web Vitals and bundle size\n- Work closely with designers to deliver pixel-perfect UIs",
				'meta'    => array(
					'_wcb_salary_min'      => '130000',
					'_wcb_salary_max'      => '175000',
					'_wcb_salary_currency' => 'USD',
					'_wcb_salary_type'     => 'annual',
					'_wcb_remote'          => '1',
					'_wcb_deadline'        => $deadline_3m,
					'_wcb_featured'        => '0',
				),
				'tax'     => array(
					'wcb_category'   => array( 'Engineering' ),
					'wcb_job_type'   => array( 'Full-time' ),
					'wcb_location'   => array( 'Remote' ),
					'wcb_experience' => array( 'Mid Level' ),
					'wcb_tag'        => array( 'Remote-first', 'Open Source' ),
				),
			),
			array(
				'title'   => 'DevOps Engineer',
				'slug'    => 'wcb-sample-devops-engineer',
				'company' => 'starter-labs',
				'content' => "Own our cloud infrastructure and CI/CD pipelines.\n\n**Requirements:**\n- 3+ years with AWS or GCP\n- Strong Kubernetes and Terraform experience\n- Observability mindset — Prometheus, Grafana, OpenTelemetry",
				'meta'    => array(
					'_wcb_salary_min'      => '140000',
					'_wcb_salary_max'      => '185000',
					'_wcb_salary_currency' => 'USD',
					'_wcb_salary_type'     => 'annual',
					'_wcb_remote'          => '1',
					'_wcb_deadline'        => $deadline_2m,
					'_wcb_featured'        => '0',
				),
				'tax'     => array(
					'wcb_category'   => array( 'Engineering' ),
					'wcb_job_type'   => array( 'Full-time' ),
					'wcb_location'   => array( 'Remote' ),
					'wcb_experience' => array( 'Senior' ),
					'wcb_tag'        => array( 'Remote-first' ),
				),
			),
			array(
				'title'   => 'Data Analyst',
				'slug'    => 'wcb-sample-data-analyst',
				'company' => 'payflow',
				'content' => "Turn data into insights that drive business decisions.\n\n**You have:**\n- 3+ years of analytics experience\n- Expert SQL skills and experience with Python or R\n- Experience building dashboards in Looker, Metabase, or similar",
				'meta'    => array(
					'_wcb_salary_min'      => '95000',
					'_wcb_salary_max'      => '130000',
					'_wcb_salary_currency' => 'USD',
					'_wcb_salary_type'     => 'annual',
					'_wcb_remote'          => '0',
					'_wcb_deadline'        => $deadline_6w,
					'_wcb_featured'        => '0',
				),
				'tax'     => array(
					'wcb_category'   => array( 'Data' ),
					'wcb_job_type'   => array( 'Full-time' ),
					'wcb_location'   => array( 'New York, NY' ),
					'wcb_experience' => array( 'Mid Level' ),
					'wcb_tag'        => array( 'Fintech' ),
				),
			),
			array(
				'title'   => 'Backend Engineer — Payments',
				'slug'    => 'wcb-sample-backend-engineer-payments',
				'company' => 'payflow',
				'content' => "Build reliable, secure payment systems processing millions of transactions.\n\n**What you'll do:**\n- Design and build APIs for payment processing, settlements, and reconciliation\n- Work with Go and PostgreSQL in a microservices architecture\n- Ensure PCI DSS compliance across all payment flows",
				'meta'    => array(
					'_wcb_salary_min'      => '160000',
					'_wcb_salary_max'      => '220000',
					'_wcb_salary_currency' => 'USD',
					'_wcb_salary_type'     => 'annual',
					'_wcb_remote'          => '1',
					'_wcb_deadline'        => $deadline_3m,
					'_wcb_featured'        => '1',
				),
				'tax'     => array(
					'wcb_category'   => array( 'Engineering' ),
					'wcb_job_type'   => array( 'Full-time' ),
					'wcb_location'   => array( 'Remote', 'New York, NY' ),
					'wcb_experience' => array( 'Senior', 'Lead' ),
					'wcb_tag'        => array( 'Fintech', 'Remote-first' ),
				),
			),
			array(
				'title'   => 'Customer Success Manager',
				'slug'    => 'wcb-sample-customer-success-manager',
				'company' => 'payflow',
				'content' => "Be the trusted advisor for our enterprise customers.\n\n**Requirements:**\n- 3+ years in customer success at a B2B SaaS company\n- Technical fluency — comfortable discussing APIs and integrations\n- Experience managing enterprise accounts with \$100K+ ARR",
				'meta'    => array(
					'_wcb_salary_min'      => '90000',
					'_wcb_salary_max'      => '120000',
					'_wcb_salary_currency' => 'USD',
					'_wcb_salary_type'     => 'annual',
					'_wcb_remote'          => '0',
					'_wcb_deadline'        => $deadline_2m,
					'_wcb_featured'        => '0',
				),
				'tax'     => array(
					'wcb_category'   => array( 'Customer Success' ),
					'wcb_job_type'   => array( 'Full-time' ),
					'wcb_location'   => array( 'New York, NY' ),
					'wcb_experience' => array( 'Mid Level' ),
					'wcb_tag'        => array( 'Fintech', 'SaaS' ),
				),
			),
		);

		foreach ( $jobs as $job ) {
			$existing = get_page_by_path( $job['slug'], OBJECT, 'wcb_job' );
			if ( $existing ) {
				// Re-track on re-run so wcb_sample_data_ids stays complete.
				$created_ids['jobs'][] = (int) $existing->ID;
				continue;
			}
			$cid = $company_ids[ $job['company'] ] ?? 0;

			$jid = wp_insert_post(
				array(
					'post_type'    => 'wcb_job',
					'post_title'   => $job['title'],
					'post_name'    => $job['slug'],
					'post_content' => self::sample_content_to_html( $job['content'] ),
					'post_status'  => 'publish',
					'post_author'  => $author_id,
				)
			);

			if ( ! $jid || is_wp_error( $jid ) ) {
				continue;
			}

			foreach ( $job['meta'] as $k => $v ) {
				update_post_meta( $jid, $k, $v );
			}
			update_post_meta( $jid, '_wcb_sample', 1 );
			if ( $cid ) {
				$co_post = get_post( $cid );
				update_post_meta( $jid, '_wcb_company_id', $cid );
				update_post_meta( $jid, '_wcb_company_name', $co_post ? $co_post->post_title : '' );
			}
			foreach ( $job['tax'] as $taxonomy => $names ) {
				$tids = array();
				foreach ( $names as $name ) {
					if ( isset( $term_map[ $taxonomy ][ $name ] ) ) {
						$tids[] = $term_map[ $taxonomy ][ $name ];
					}
				}
				if ( $tids ) {
					wp_set_post_terms( $jid, $tids, $taxonomy );
				}
			}
			$created_ids['jobs'][] = $jid;
		}

		// -----------------------------------------------------------------
		// 4. Track + flag.
		// -----------------------------------------------------------------
		update_option( 'wcb_sample_data_ids', $created_ids );
		update_option( 'wcb_sample_data_installed', true );

		/**
		 * Fires after sample/demo data is installed. Pro hooks this to seed
		 * demo resumes (and other Pro-owned content) tied to the sample set.
		 *
		 * @since 1.3.1
		 *
		 * @param array{companies: int[], jobs: int[], terms: int[]} $created_ids Created sample IDs.
		 */
		do_action( 'wcb_sample_data_installed', $created_ids );
	}

	/**
	 * Convert the lightweight markdown used in sample job content (blank-line
	 * paragraphs, `**Heading:**` lines, `- ` bullets) into clean HTML, so the
	 * demo jobs render as structured content - headings, paragraphs, and lists -
	 * on the frontend and in the editor, instead of raw markdown.
	 *
	 * @since 1.3.1
	 *
	 * @param  string $content Markdown-ish sample content.
	 * @return string HTML.
	 */
	private static function sample_content_to_html( string $content ): string {
		$html = '';
		$list = array();

		foreach ( explode( "\n", trim( $content ) ) as $raw ) {
			$line = trim( $raw );
			if ( '' === $line ) {
				continue;
			}

			if ( preg_match( '/^[-*]\s+(.+)/', $line, $m ) ) {
				$list[] = $m[1];
				continue;
			}

			if ( $list ) {
				$html .= '<ul><li>' . implode( '</li><li>', array_map( 'esc_html', $list ) ) . '</li></ul>';
				$list  = array();
			}

			if ( preg_match( '/^\*\*(.+?):?\*\*$/', $line, $m ) ) {
				$html .= '<h3>' . esc_html( $m[1] ) . '</h3>';
			} else {
				$html .= '<p>' . esc_html( $line ) . '</p>';
			}
		}

		if ( $list ) {
			$html .= '<ul><li>' . implode( '</li><li>', array_map( 'esc_html', $list ) ) . '</li></ul>';
		}

		return $html;
	}

	/**
	 * Detect whether wizard sample data still exists on the site.
	 *
	 * Considers four signals so the cleanup button never silently
	 * disappears while demo content is still around:
	 * 1. The legacy `wcb_sample_data_installed` flag.
	 * 2. The tracked id map in `wcb_sample_data_ids`.
	 * 3. The `_wcb_sample = 1` post meta marker stamped at install time
	 *    (covers wcb_job, wcb_company, wcb_candidate).
	 * 4. Orphan markers — wcb_job slugs prefixed with `wcb-sample-` or
	 *    wcb_company posts whose `_wcb_website` ends with `example.com`.
	 *
	 * @since 1.1.1
	 *
	 * @return bool
	 */
	public static function has_sample_data(): bool {
		if ( (bool) get_option( 'wcb_sample_data_installed', false ) ) {
			return true;
		}
		$ids = (array) get_option( 'wcb_sample_data_ids', array() );
		if ( ! empty( $ids ) ) {
			return true;
		}

		global $wpdb;

		// Meta marker — any CPT explicitly tagged at install time, including
		// posts an admin added manually then marked with `_wcb_sample = 1`.
		$tagged = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(p.ID)
				 FROM {$wpdb->posts} p
				 INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID AND pm.meta_key = %s AND pm.meta_value = %s
				 WHERE p.post_type IN ( 'wcb_job', 'wcb_company', 'wcb_candidate' )",
				'_wcb_sample',
				'1'
			)
		);
		if ( $tagged > 0 ) {
			return true;
		}

		$jobs = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = %s AND post_name LIKE %s",
				'wcb_job',
				'wcb-sample-%'
			)
		);
		if ( $jobs > 0 ) {
			return true;
		}
		$companies = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->posts} p
				 INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID AND pm.meta_key = %s
				 WHERE p.post_type = %s AND pm.meta_value LIKE %s",
				'_wcb_website',
				'wcb_company',
				'%example.com%'
			)
		);
		return $companies > 0;
	}

	/**
	 * Remove all sample data created by the wizard, plus any wizard-shaped
	 * orphans (slug prefix `wcb-sample-`, company website containing
	 * `example.com`) and any post explicitly tagged with `_wcb_sample = 1`
	 * (covers manually-added demo jobs, companies, and candidates that an
	 * admin or import script marked as sample). Idempotent — re-running
	 * with nothing to remove returns zero counts, never an error.
	 *
	 * @since 1.0.0
	 *
	 * @return array{jobs: int, companies: int, candidates: int, terms: int} Counts of removed items.
	 */
	public function remove_sample_data(): array {
		$ids     = (array) get_option( 'wcb_sample_data_ids', array() );
		$removed = array(
			'jobs'       => 0,
			'companies'  => 0,
			'candidates' => 0,
			'terms'      => 0,
		);
		$deleted = array(
			'wcb_job'       => array(),
			'wcb_company'   => array(),
			'wcb_candidate' => array(),
		);

		// Jobs — tracked ids.
		foreach ( $ids['jobs'] ?? array() as $jid ) {
			$jid = (int) $jid;
			if ( $jid && get_post( $jid ) ) {
				wp_delete_post( $jid, true );
				$deleted['wcb_job'][ $jid ] = true;
				++$removed['jobs'];
			}
		}

		// Companies — tracked ids.
		foreach ( $ids['companies'] ?? array() as $cid ) {
			$cid = (int) $cid;
			if ( $cid && get_post( $cid ) ) {
				wp_delete_post( $cid, true );
				$deleted['wcb_company'][ $cid ] = true;
				++$removed['companies'];
			}
		}

		// Terms (only delete if still created by wizard — skip if user added jobs to them).
		foreach ( $ids['terms'] ?? array() as $entry ) {
			$term = get_term( (int) $entry['term_id'], $entry['taxonomy'] );
			if ( $term instanceof \WP_Term && 0 === $term->count ) {
				wp_delete_term( $term->term_id, $entry['taxonomy'] );
				++$removed['terms'];
			}
		}

		global $wpdb;

		// Meta marker sweep — every CPT post explicitly tagged `_wcb_sample = 1`
		// (install-time auto-tag plus anything an admin/import script marked
		// manually). Covers wcb_job, wcb_company, wcb_candidate so candidates
		// added during a demo are cleaned up alongside jobs and companies.
		$tagged = (array) $wpdb->get_results(
			$wpdb->prepare(
				"SELECT p.ID, p.post_type
				 FROM {$wpdb->posts} p
				 INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID AND pm.meta_key = %s AND pm.meta_value = %s
				 WHERE p.post_type IN ( 'wcb_job', 'wcb_company', 'wcb_candidate' )
				 LIMIT 1000",
				'_wcb_sample',
				'1'
			)
		);
		foreach ( $tagged as $row ) {
			$post_id   = (int) $row->ID;
			$post_type = (string) $row->post_type;
			if ( isset( $deleted[ $post_type ][ $post_id ] ) ) {
				continue;
			}
			if ( ! get_post( $post_id ) ) {
				continue;
			}
			wp_delete_post( $post_id, true );
			$deleted[ $post_type ][ $post_id ] = true;
			$bucket                            = 'wcb_job' === $post_type ? 'jobs' : ( 'wcb_company' === $post_type ? 'companies' : 'candidates' );
			++$removed[ $bucket ];
		}

		// Orphan sweep — sites whose `wcb_sample_data_ids` got out of sync (manual
		// db edits, partial restores, an older wizard run that didn't track ids)
		// otherwise leave demo content stranded on the site forever. Match on
		// the wizard-emitted slug prefix and the *.example.com website signal,
		// both of which are unique to the seeder. Ignore anything posted by a
		// real employer.
		$wcb_orphan_jobs = array_map(
			'intval',
			(array) $wpdb->get_col(
				$wpdb->prepare(
					"SELECT ID FROM {$wpdb->posts} WHERE post_type = %s AND post_name LIKE %s LIMIT 200",
					'wcb_job',
					'wcb-sample-%'
				)
			)
		);
		foreach ( $wcb_orphan_jobs as $wcb_orphan_job_id ) {
			if ( isset( $deleted['wcb_job'][ $wcb_orphan_job_id ] ) ) {
				continue;
			}
			if ( get_post( (int) $wcb_orphan_job_id ) ) {
				wp_delete_post( (int) $wcb_orphan_job_id, true );
				$deleted['wcb_job'][ $wcb_orphan_job_id ] = true;
				++$removed['jobs'];
			}
		}

		$wcb_orphan_companies = (array) $wpdb->get_col(
			$wpdb->prepare(
				"SELECT p.ID
				 FROM {$wpdb->posts} p
				 INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID AND pm.meta_key = %s
				 WHERE p.post_type = %s AND pm.meta_value LIKE %s
				 LIMIT 100",
				'_wcb_website',
				'wcb_company',
				'%example.com%'
			)
		);
		foreach ( $wcb_orphan_companies as $wcb_orphan_co_id ) {
			$wcb_orphan_co_id = (int) $wcb_orphan_co_id;
			if ( isset( $deleted['wcb_company'][ $wcb_orphan_co_id ] ) ) {
				continue;
			}
			if ( get_post( $wcb_orphan_co_id ) ) {
				wp_delete_post( $wcb_orphan_co_id, true );
				$deleted['wcb_company'][ $wcb_orphan_co_id ] = true;
				++$removed['companies'];
			}
		}

		// Remove orphaned _wcb_company_id from the user who ran the wizard.
		$admin_company = get_user_meta( get_current_user_id(), '_wcb_company_id', true );
		if ( $admin_company && ! get_post( (int) $admin_company ) ) {
			delete_user_meta( get_current_user_id(), '_wcb_company_id' );
		}

		delete_option( 'wcb_sample_data_ids' );
		delete_option( 'wcb_sample_data_installed' );

		/**
		 * Fires after sample/demo data is removed. Pro hooks this to delete the
		 * demo resumes (and candidate users) it seeded.
		 *
		 * @since 1.3.1
		 */
		do_action( 'wcb_sample_data_removed' );

		return $removed;
	}
}
