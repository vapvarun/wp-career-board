<?php // phpcs:ignore WordPress.Files.FileName.InvalidClassFileName
/**
 * Applications REST endpoint — submit, view, update status, candidate history.
 *
 * @package WP_Career_Board
 * @since   1.0.0
 */

declare( strict_types=1 );

namespace WCB\Api\Endpoints;

use WCB\Api\RestController;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Handles /wcb/v1/jobs/{id}/apply and /wcb/v1/applications/* REST routes.
 *
 * Enforces the Abilities API for all permission checks — no raw
 * current_user_can() except the wcb_manage_settings fallback provided by
 * RestController::check_ability().
 *
 * @since 1.0.0
 */
final class ApplicationsEndpoint extends RestController {

	/**
	 * Register all application routes.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function register_routes(): void {
		// Submit application to a job.
		register_rest_route(
			$this->namespace,
			'/jobs/(?P<id>\d+)/apply',
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'submit_application' ),
				'permission_callback' => array( $this, 'submit_permissions_check' ),
			)
		);

		// Single application — candidate or employer owning the job.
		register_rest_route(
			$this->namespace,
			'/applications/(?P<id>\d+)',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_item' ),
					'permission_callback' => array( $this, 'get_item_permissions_check' ),
				),
				array(
					'methods'             => \WP_REST_Server::DELETABLE,
					'callback'            => array( $this, 'withdraw_application' ),
					'permission_callback' => array( $this, 'withdraw_permissions_check' ),
				),
			)
		);

		// Update application status — employer or admin.
		register_rest_route(
			$this->namespace,
			'/applications/(?P<id>\d+)/status',
			array(
				'methods'             => \WP_REST_Server::EDITABLE,
				'callback'            => array( $this, 'update_status' ),
				'permission_callback' => array( $this, 'update_permissions_check' ),
			)
		);

		// All applications for a specific candidate.
		register_rest_route(
			$this->namespace,
			'/candidates/(?P<id>\d+)/applications',
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_candidate_applications' ),
				'permission_callback' => array( $this, 'candidate_permissions_check' ),
			)
		);

		// Upload a resume file (Free mode — no wcb_resume post). Requires login.
		register_rest_route(
			$this->namespace,
			'/candidates/resume-upload',
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'upload_resume_file' ),
				'permission_callback' => static function (): bool {
					return is_user_logged_in();
				},
			)
		);
	}

	// --- Route callbacks --------------------------------------------------------

	/**
	 * Submit a new application to a job.
	 *
	 * Supports both authenticated candidates and unauthenticated guests.
	 * Guests must supply guest_name + guest_email; a 24-hour duplicate guard
	 * prevents the same email address from applying twice per job.
	 *
	 * @since 1.0.0
	 *
	 * @param \WP_REST_Request $request Full request object.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function submit_application( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$wcb_spam = apply_filters( 'wcb_pre_application_submit', null, $request );
		if ( is_wp_error( $wcb_spam ) ) {
			return $wcb_spam;
		}

		$job_id   = (int) $request['id'];
		$is_guest = ! is_user_logged_in();

		$job = get_post( $job_id );
		if ( ! $job || 'wcb_job' !== $job->post_type || 'publish' !== $job->post_status ) {
			return new \WP_Error(
				'wcb_job_unavailable',
				__( 'This job is not available.', 'wp-career-board' ),
				array( 'status' => 400 )
			);
		}

		if ( $is_guest ) {
			// Guest submission: require name + valid email.
			$guest_name  = sanitize_text_field( (string) ( $request->get_param( 'guest_name' ) ?? '' ) );
			$guest_email = sanitize_email( (string) ( $request->get_param( 'guest_email' ) ?? '' ) );

			if ( ! $guest_name ) {
				return new \WP_Error( 'wcb_guest_name_required', __( 'Name is required.', 'wp-career-board' ), array( 'status' => 400 ) );
			}
			if ( ! is_email( $guest_email ) ) {
				return new \WP_Error( 'wcb_guest_email_invalid', __( 'A valid email address is required.', 'wp-career-board' ), array( 'status' => 400 ) );
			}

			// Duplicate guard: one pending application per guest email + job within 24 h.
			$cutoff   = gmdate( 'Y-m-d H:i:s', time() - DAY_IN_SECONDS );
			$existing = get_posts(
				array(
					'post_type'      => 'wcb_application',
					'post_status'    => 'any',
					'posts_per_page' => 1,
					'date_query'     => array( array( 'after' => $cutoff ) ),
					'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
						'relation' => 'AND',
						array(
							'key'   => '_wcb_job_id',
							'value' => $job_id,
						),
						array(
							'key'   => '_wcb_guest_email',
							'value' => $guest_email,
						),
					),
				)
			);

			if ( $existing ) {
				return new \WP_Error(
					'wcb_already_applied',
					__( 'You have already applied to this job recently.', 'wp-career-board' ),
					array( 'status' => 409 )
				);
			}

			/* translators: 1: guest name, 2: job post ID */
			$post_title = sprintf( __( 'Application: %1$s → Job %2$d', 'wp-career-board' ), $guest_name, $job_id );
		} else {
			$candidate_id = get_current_user_id();

			// Prevent duplicate applications for logged-in candidates.
			$existing = get_posts(
				array(
					'post_type'      => 'wcb_application',
					'post_status'    => 'any',
					'posts_per_page' => 1,
					'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
						'relation' => 'AND',
						array(
							'key'   => '_wcb_job_id',
							'value' => $job_id,
						),
						array(
							'key'   => '_wcb_candidate_id',
							'value' => $candidate_id,
						),
					),
				)
			);

			if ( $existing ) {
				return new \WP_Error(
					'wcb_already_applied',
					__( 'You have already applied to this job.', 'wp-career-board' ),
					array( 'status' => 409 )
				);
			}

			/* translators: 1: candidate user ID, 2: job post ID */
			$post_title = sprintf( __( 'Application: User %1$d → Job %2$d', 'wp-career-board' ), $candidate_id, $job_id );
		}

		$app_id = wp_insert_post(
			array(
				'post_type'   => 'wcb_application',
				'post_title'  => $post_title,
				'post_status' => 'publish',
				'post_author' => $is_guest ? 0 : $candidate_id,
			),
			true
		);

		if ( is_wp_error( $app_id ) ) {
			return $app_id;
		}

		update_post_meta( $app_id, '_wcb_job_id', $job_id );
		update_post_meta( $app_id, '_wcb_candidate_id', $is_guest ? 0 : $candidate_id );
		update_post_meta(
			$app_id,
			'_wcb_cover_letter',
			sanitize_textarea_field( (string) ( $request->get_param( 'cover_letter' ) ?? '' ) )
		);

		if ( $is_guest ) {
			update_post_meta( $app_id, '_wcb_guest_name', $guest_name );
			update_post_meta( $app_id, '_wcb_guest_email', $guest_email );
		} else {
			// Validate resume belongs to the current candidate before storing.
			$resume_id = (int) $request->get_param( 'resume_id' );
			if ( $resume_id > 0 ) {
				$resume = get_post( $resume_id );
				if ( ! $resume || 'wcb_resume' !== $resume->post_type || $candidate_id !== (int) $resume->post_author ) {
					wp_delete_post( $app_id, true );
					return new \WP_Error(
						'wcb_invalid_resume',
						__( 'Invalid resume.', 'wp-career-board' ),
						array( 'status' => 400 )
					);
				}
			}
			update_post_meta( $app_id, '_wcb_resume_id', $resume_id );

			// Store uploaded resume file attachment (Free mode — no wcb_resume post).
			$attachment_id = (int) $request->get_param( 'resume_attachment_id' );
			if ( $attachment_id > 0 ) {
				update_post_meta( $app_id, '_wcb_resume_attachment_id', $attachment_id );
			}
		}

		update_post_meta( $app_id, '_wcb_status', 'submitted' );

		do_action( 'wcb_application_submitted', $app_id, $job_id, $is_guest ? 0 : $candidate_id );

		return rest_ensure_response(
			array(
				'id'     => $app_id,
				'job_id' => $job_id,
				'status' => 'submitted',
			)
		);
	}

	/**
	 * Retrieve a single application.
	 *
	 * @since 1.0.0
	 *
	 * @param \WP_REST_Request $request Full request object.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function get_item( $request ): \WP_REST_Response|\WP_Error {
		$post = get_post( (int) $request['id'] );
		if ( ! $post || 'wcb_application' !== $post->post_type ) {
			return new \WP_Error(
				'wcb_not_found',
				__( 'Application not found.', 'wp-career-board' ),
				array( 'status' => 404 )
			);
		}
		return rest_ensure_response( $this->prepare_application( $post ) );
	}

	/**
	 * Update the status of an application.
	 *
	 * @since 1.0.0
	 *
	 * @param \WP_REST_Request $request Full request object.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function update_status( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$post = get_post( (int) $request['id'] );
		if ( ! $post || 'wcb_application' !== $post->post_type ) {
			return new \WP_Error(
				'wcb_not_found',
				__( 'Application not found.', 'wp-career-board' ),
				array( 'status' => 404 )
			);
		}

		$allowed    = array( 'submitted', 'reviewing', 'shortlisted', 'rejected', 'hired' );
		$new_status = sanitize_text_field( (string) $request->get_param( 'status' ) );
		if ( ! in_array( $new_status, $allowed, true ) ) {
			return new \WP_Error(
				'wcb_invalid_status',
				__( 'Invalid status.', 'wp-career-board' ),
				array( 'status' => 400 )
			);
		}

		$old_status = (string) get_post_meta( $post->ID, '_wcb_status', true );
		update_post_meta( $post->ID, '_wcb_status', $new_status );

		$log   = (array) get_post_meta( $post->ID, '_wcb_status_log', true );
		$log[] = array(
			'from' => $old_status,
			'to'   => $new_status,
			'by'   => get_current_user_id(),
			'at'   => gmdate( 'Y-m-d H:i:s' ),
		);
		update_post_meta( $post->ID, '_wcb_status_log', $log );

		do_action( 'wcb_application_status_changed', $post->ID, $old_status, $new_status );

		return rest_ensure_response(
			array(
				'id'     => $post->ID,
				'status' => $new_status,
			)
		);
	}

	/**
	 * List all applications for a specific candidate.
	 *
	 * Returns a frontend-friendly shape: id, jobTitle, jobPermalink, status, date.
	 *
	 * @since 1.0.0
	 *
	 * @param \WP_REST_Request $request Full request object.
	 * @return \WP_REST_Response
	 */
	public function get_candidate_applications( \WP_REST_Request $request ): \WP_REST_Response {
		$candidate_id = (int) $request['id'];
		$per_page     = min( (int) ( $request->get_param( 'per_page' ) ?? 20 ), 100 );
		$paged        = max( (int) ( $request->get_param( 'page' ) ?? 1 ), 1 );

		$query = new \WP_Query(
			array(
				'post_type'      => 'wcb_application',
				'post_status'    => 'any',
				'posts_per_page' => $per_page,
				'paged'          => $paged,
				'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
					array(
						'key'   => '_wcb_candidate_id',
						'value' => $candidate_id,
					),
				),
			)
		);

		$items = array();
		foreach ( $query->posts as $app ) {
			$job_id  = (int) get_post_meta( $app->ID, '_wcb_job_id', true );
			$job     = $job_id ? get_post( $job_id ) : null;
			$status  = (string) get_post_meta( $app->ID, '_wcb_status', true );
			$items[] = array(
				'id'           => $app->ID,
				'jobTitle'     => $job instanceof \WP_Post ? $job->post_title : '',
				'jobPermalink' => $job instanceof \WP_Post ? (string) get_permalink( $job_id ) : '',
				'company'      => $job instanceof \WP_Post ? (string) get_post_meta( $job_id, '_wcb_company_name', true ) : '',
				'status'       => $status ? $status : 'submitted',
				'date'         => get_the_date( 'Y-m-d', $app ),
			);
		}

		$response = rest_ensure_response( $items );
		$response->header( 'X-WCB-Total', (string) $query->found_posts );
		$response->header( 'X-WCB-TotalPages', (string) $query->max_num_pages );
		return $response;
	}

	/**
	 * Withdraw (delete) an application — candidate owner only.
	 *
	 * Respects the allow_withdraw site setting. Fires wcb_application_withdrawn
	 * so other modules (e.g. notifications) can react.
	 *
	 * @since 1.0.0
	 *
	 * @param \WP_REST_Request $request Full request object.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function withdraw_application( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		$post = get_post( (int) $request['id'] );
		if ( ! $post || 'wcb_application' !== $post->post_type ) {
			return new \WP_Error(
				'wcb_not_found',
				__( 'Application not found.', 'wp-career-board' ),
				array( 'status' => 404 )
			);
		}

		$app_id       = $post->ID;
		$candidate_id = (int) get_post_meta( $app_id, '_wcb_candidate_id', true );
		$job_id       = (int) get_post_meta( $app_id, '_wcb_job_id', true );

		wp_delete_post( $app_id, true );

		do_action( 'wcb_application_withdrawn', $app_id, $job_id, $candidate_id );

		return rest_ensure_response(
			array(
				'deleted' => true,
				'id'      => $app_id,
			)
		);
	}

	/**
	 * Upload a resume file (PDF/DOC/DOCX) and return the attachment ID.
	 *
	 * @since 1.0.0
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function upload_resume_file(): \WP_REST_Response|\WP_Error {
		if ( empty( $_FILES['resume_file'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce verified by WP REST infrastructure via X-WP-Nonce header.
			return new \WP_Error(
				'wcb_no_file',
				__( 'No file provided.', 'wp-career-board' ),
				array( 'status' => 400 )
			);
		}

		$file     = $_FILES['resume_file']; // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- media_handle_upload() sanitizes internally.
		$allowed  = array( 'application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' );
		$max_size = 5 * MB_IN_BYTES;

		if ( ! in_array( $file['type'], $allowed, true ) ) {
			return new \WP_Error(
				'wcb_invalid_file_type',
				__( 'Only PDF, DOC, and DOCX files are allowed.', 'wp-career-board' ),
				array( 'status' => 400 )
			);
		}

		if ( $file['size'] > $max_size ) {
			return new \WP_Error(
				'wcb_file_too_large',
				__( 'File must be under 5 MB.', 'wp-career-board' ),
				array( 'status' => 400 )
			);
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$attachment_id = media_handle_upload( 'resume_file', 0 );

		if ( is_wp_error( $attachment_id ) ) {
			return $attachment_id;
		}

		return rest_ensure_response( array( 'attachment_id' => $attachment_id ) );
	}

	// --- Permission callbacks ---------------------------------------------------

	/**
	 * Check if the current user can submit an application.
	 *
	 * Guests (unauthenticated) are permitted — guest field validation happens
	 * in submit_application() after the auth check passes.
	 *
	 * @since 1.0.0
	 *
	 * @param \WP_REST_Request $request Full request object.
	 * @return bool
	 */
	public function submit_permissions_check( \WP_REST_Request $request ): bool {
		return true;
	}

	/**
	 * Check if the current user can view the given application.
	 *
	 * Allows: the candidate who submitted, the employer who owns the job, or an admin.
	 *
	 * @since 1.0.0
	 *
	 * @param \WP_REST_Request $request Full request object.
	 * @return bool|\WP_Error
	 */
	public function get_item_permissions_check( $request ): bool|\WP_Error {
		$post = get_post( (int) $request['id'] );
		if ( ! $post ) {
			return $this->permission_error();
		}
		$is_candidate = (int) get_post_meta( $post->ID, '_wcb_candidate_id', true ) === get_current_user_id();
		$job_id       = (int) get_post_meta( $post->ID, '_wcb_job_id', true );
		$job          = get_post( $job_id );
		$is_employer  = $job instanceof \WP_Post && get_current_user_id() === (int) $job->post_author;
		$is_admin     = $this->check_ability( 'wcb_manage_settings' );
		return ( $is_candidate || $is_employer || $is_admin ) ? true : $this->permission_error();
	}

	/**
	 * Check if the current user can update an application status.
	 *
	 * Requires wcb_view_applications ability AND that the current user authored
	 * the job the application belongs to (prevents IDOR), or is an admin.
	 *
	 * @since 1.0.0
	 *
	 * @param \WP_REST_Request $request Full request object.
	 * @return bool|\WP_Error
	 */
	public function update_permissions_check( \WP_REST_Request $request ): bool|\WP_Error {
		if ( ! $this->check_ability( 'wcb_view_applications' ) ) {
			return $this->permission_error();
		}
		// Admins may update any application.
		if ( $this->check_ability( 'wcb_manage_settings' ) ) {
			return true;
		}
		// Employers may only update applications belonging to their own jobs.
		$app = get_post( (int) $request['id'] );
		if ( ! $app ) {
			return $this->permission_error();
		}
		$job_id   = (int) get_post_meta( $app->ID, '_wcb_job_id', true );
		$job      = get_post( $job_id );
		$is_owner = $job instanceof \WP_Post && get_current_user_id() === (int) $job->post_author;
		return $is_owner ? true : $this->permission_error();
	}

	/**
	 * Check if the current user can withdraw the given application.
	 *
	 * Requires the allow_withdraw setting to be enabled and the current user
	 * to be the candidate who submitted the application.
	 *
	 * @since 1.0.0
	 *
	 * @param \WP_REST_Request $request Full request object.
	 * @return bool|\WP_Error
	 */
	public function withdraw_permissions_check( \WP_REST_Request $request ): bool|\WP_Error {
		$settings = (array) get_option( 'wcb_settings', array() );
		if ( empty( $settings['allow_withdraw'] ) ) {
			return new \WP_Error(
				'wcb_withdraw_disabled',
				__( 'Application withdrawal is not enabled on this site.', 'wp-career-board' ),
				array( 'status' => 403 )
			);
		}

		$post = get_post( (int) $request['id'] );
		if ( ! $post ) {
			return $this->permission_error();
		}

		$is_owner = (int) get_post_meta( $post->ID, '_wcb_candidate_id', true ) === get_current_user_id();
		$is_admin = $this->check_ability( 'wcb_manage_settings' );
		return ( $is_owner || $is_admin ) ? true : $this->permission_error();
	}

	/**
	 * Check if the current user can list a candidate's applications.
	 *
	 * Allows the candidate themselves or an admin.
	 *
	 * @since 1.0.0
	 *
	 * @param \WP_REST_Request $request Full request object.
	 * @return bool|\WP_Error
	 */
	public function candidate_permissions_check( \WP_REST_Request $request ): bool|\WP_Error {
		$same_user = get_current_user_id() === (int) $request['id'];
		$is_admin  = $this->check_ability( 'wcb_manage_settings' );
		return ( $same_user || $is_admin ) ? true : $this->permission_error();
	}

	// --- Helpers ----------------------------------------------------------------

	/**
	 * Shape a WP_Post (wcb_application) into the REST response array.
	 *
	 * @since 1.0.0
	 *
	 * @param \WP_Post $post Application post object.
	 * @return array<string, mixed>
	 */
	private function prepare_application( \WP_Post $post ): array {
		$status = (string) get_post_meta( $post->ID, '_wcb_status', true );
		return array(
			'id'           => $post->ID,
			'job_id'       => (int) get_post_meta( $post->ID, '_wcb_job_id', true ),
			'candidate_id' => (int) get_post_meta( $post->ID, '_wcb_candidate_id', true ),
			'cover_letter' => (string) get_post_meta( $post->ID, '_wcb_cover_letter', true ),
			'resume_id'    => (int) get_post_meta( $post->ID, '_wcb_resume_id', true ),
			'status'       => $status ? $status : 'submitted',
			'submitted_at' => $post->post_date,
		);
	}
}
